/**
 * OnboardingManager - Handles first-time user onboarding tutorial
 * Provides interactive guidance for new users
 */

export class OnboardingManager {
    constructor() {
        this.currentStep = 0;
        this.isActive = false;
        this.steps = [
            {
                target: '.voice-btn',
                title: '🎤 Voice Commands',
                content: 'Click this button or press Space to start voice recognition. Try saying "Add milk" or "Buy 2 apples".',
                position: 'bottom'
            },
            {
                target: '.language-select',
                title: '🌐 Language Support',
                content: 'Choose your preferred language for voice recognition and audio feedback.',
                position: 'bottom'
            },
            {
                target: '.shopping-list',
                title: '📝 Shopping List',
                content: 'Your items will appear here, organized by category. Click the buttons to complete, edit, or remove items.',
                position: 'top'
            },
            {
                target: '.suggestions',
                title: '💡 Smart Suggestions',
                content: 'Get personalized recommendations based on your shopping history and seasonal items.',
                position: 'top'
            },
            {
                target: '.fallback-input',
                title: '⌨️ Text Input',
                content: 'If voice recognition isn\'t available, you can type commands here as a fallback.',
                position: 'top'
            }
        ];
        
        this.overlay = null;
        this.tooltip = null;
        this.highlightedElement = null;
        
        this.init();
    }
    
    /**
     * Initialize the onboarding manager
     */
    init() {
        this.createOverlay();
        this.createTooltip();
        this.setupEventListeners();
        
        // Check if user has completed onboarding
        if (!this.hasCompletedOnboarding()) {
            // Delay onboarding to allow app to fully load
            setTimeout(() => {
                this.start();
            }, 1500);
        }
    }
    
    /**
     * Check if user has completed onboarding
     * @returns {boolean} True if onboarding was completed
     */
    hasCompletedOnboarding() {
        return localStorage.getItem('voice-shopping-onboarding-completed') === 'true';
    }
    
    /**
     * Mark onboarding as completed
     */
    markCompleted() {
        localStorage.setItem('voice-shopping-onboarding-completed', 'true');
    }
    
    /**
     * Create the overlay element
     */
    createOverlay() {
        this.overlay = document.createElement('div');
        this.overlay.className = 'onboarding-overlay';
        this.overlay.addEventListener('click', (e) => {
            if (e.target === this.overlay) {
                this.skip();
            }
        });
        document.body.appendChild(this.overlay);
    }
    
    /**
     * Create the tooltip element
     */
    createTooltip() {
        this.tooltip = document.createElement('div');
        this.tooltip.className = 'onboarding-tooltip';
        this.tooltip.style.display = 'none';
        document.body.appendChild(this.tooltip);
    }
    
    /**
     * Set up event listeners
     */
    setupEventListeners() {
        // Listen for escape key to close onboarding
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isActive) {
                this.skip();
            }
        });
        
        // Listen for window resize to reposition tooltip
        window.addEventListener('resize', () => {
            if (this.isActive) {
                this.positionTooltip();
            }
        });
        
        // Clean up on page unload
        window.addEventListener('beforeunload', () => {
            this.cleanup();
        });
    }
    
    /**
     * Start the onboarding tutorial
     */
    start() {
        if (this.isActive) return;
        
        this.isActive = true;
        this.currentStep = 0;
        this.overlay.classList.add('show');
        this.showStep(this.currentStep);
        
        // Announce to screen readers
        this.announceToScreenReader('Onboarding tutorial started. Press Escape to skip.');
    }
    
    /**
     * Show a specific step
     * @param {number} stepIndex - Index of the step to show
     */
    showStep(stepIndex) {
        if (stepIndex < 0 || stepIndex >= this.steps.length) {
            this.complete();
            return;
        }
        
        const step = this.steps[stepIndex];
        const targetElement = document.querySelector(step.target);
        
        if (!targetElement) {
            console.warn(`Onboarding target not found: ${step.target}`);
            this.next();
            return;
        }
        
        // Remove previous highlight
        this.removeHighlight();
        
        // Highlight current element
        this.highlightElement(targetElement);
        
        // Update tooltip content
        this.updateTooltip(step);
        
        // Show and position tooltip
        this.showTooltip();
        this.positionTooltip(targetElement, step.position);
        
        // Announce to screen readers
        this.announceToScreenReader(`Step ${stepIndex + 1} of ${this.steps.length}: ${step.title}. ${step.content}`);
    }
    
    /**
     * Highlight an element
     * @param {HTMLElement} element - Element to highlight
     */
    highlightElement(element) {
        this.highlightedElement = element;
        element.classList.add('onboarding-highlight');
        
        // Scroll element into view
        element.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });
    }
    
    /**
     * Remove highlight from current element
     */
    removeHighlight() {
        if (this.highlightedElement) {
            this.highlightedElement.classList.remove('onboarding-highlight');
            this.highlightedElement = null;
        }
    }
    
    /**
     * Hide the tooltip
     */
    hideTooltip() {
        if (this.tooltip) {
            this.tooltip.classList.remove('show');
            this.tooltip.style.display = 'none';
        }
    }
    
    /**
     * Show the tooltip
     */
    showTooltip() {
        if (this.tooltip) {
            this.tooltip.style.display = 'block';
            // Force reflow to ensure display change takes effect
            this.tooltip.offsetHeight;
            this.tooltip.classList.add('show');
        }
    }
    
    /**
     * Update tooltip content
     * @param {Object} step - Step configuration
     */
    updateTooltip(step) {
        this.tooltip.innerHTML = `
            <div class="onboarding-header">
                <span class="onboarding-icon">${step.title.split(' ')[0]}</span>
                <h3 class="onboarding-title">${step.title.substring(2)}</h3>
            </div>
            <div class="onboarding-progress">
                ${this.steps.map((_, index) => `
                    <div class="onboarding-progress-dot ${
                        index < this.currentStep ? 'completed' : 
                        index === this.currentStep ? 'active' : ''
                    }"></div>
                `).join('')}
            </div>
            <div class="onboarding-content">
                ${step.content}
            </div>
            <div class="onboarding-actions">
                <button class="onboarding-btn secondary" onclick="window.onboardingManager.skip()">
                    Skip Tutorial
                </button>
                ${this.currentStep > 0 ? `
                    <button class="onboarding-btn secondary" onclick="window.onboardingManager.previous()">
                        Previous
                    </button>
                ` : ''}
                <button class="onboarding-btn primary" onclick="window.onboardingManager.next()">
                    ${this.currentStep === this.steps.length - 1 ? 'Finish' : 'Next'}
                </button>
            </div>
        `;
    }
    
    /**
     * Position tooltip relative to target element
     * @param {HTMLElement} targetElement - Target element
     * @param {string} position - Preferred position (top, bottom, left, right)
     */
    positionTooltip(targetElement, position = 'bottom') {
        if (!targetElement) return;
        
        const targetRect = targetElement.getBoundingClientRect();
        const tooltipRect = this.tooltip.getBoundingClientRect();
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        
        let left, top;
        
        // Reset position classes
        this.tooltip.className = 'onboarding-tooltip';
        
        switch (position) {
            case 'top':
                left = targetRect.left + (targetRect.width / 2) - (tooltipRect.width / 2);
                top = targetRect.top - tooltipRect.height - 20;
                this.tooltip.classList.add('top');
                break;
            case 'bottom':
                left = targetRect.left + (targetRect.width / 2) - (tooltipRect.width / 2);
                top = targetRect.bottom + 20;
                this.tooltip.classList.add('bottom');
                break;
            case 'left':
                left = targetRect.left - tooltipRect.width - 20;
                top = targetRect.top + (targetRect.height / 2) - (tooltipRect.height / 2);
                this.tooltip.classList.add('left');
                break;
            case 'right':
                left = targetRect.right + 20;
                top = targetRect.top + (targetRect.height / 2) - (tooltipRect.height / 2);
                this.tooltip.classList.add('right');
                break;
        }
        
        // Ensure tooltip stays within viewport
        left = Math.max(20, Math.min(left, viewportWidth - tooltipRect.width - 20));
        top = Math.max(20, Math.min(top, viewportHeight - tooltipRect.height - 20));
        
        this.tooltip.style.left = `${left}px`;
        this.tooltip.style.top = `${top}px`;
    }
    
    /**
     * Go to next step
     */
    next() {
        this.currentStep++;
        this.showStep(this.currentStep);
    }
    
    /**
     * Go to previous step
     */
    previous() {
        if (this.currentStep > 0) {
            this.currentStep--;
            this.showStep(this.currentStep);
        }
    }
    
    /**
     * Skip the tutorial
     */
    skip() {
        if (confirm('Are you sure you want to skip the tutorial? You can restart it later from the help menu.')) {
            this.complete();
        }
    }
    
    /**
     * Force close the tutorial (for emergency cleanup)
     */
    forceClose() {
        this.isActive = false;
        this.overlay.classList.remove('show');
        this.removeHighlight();
        this.hideTooltip();
        
        // Don't mark as completed when force closing
        this.announceToScreenReader('Onboarding tutorial closed.');
    }
    
    /**
     * Complete the onboarding
     */
    complete() {
        this.isActive = false;
        this.overlay.classList.remove('show');
        this.removeHighlight();
        this.hideTooltip();
        this.markCompleted();
        
        // Show completion message
        this.showCompletionToast();
        
        // Announce to screen readers
        this.announceToScreenReader('Onboarding tutorial completed. You can now use the Voice Shopping Assistant.');
    }
    
    /**
     * Show completion toast
     */
    showCompletionToast() {
        const toast = this.createToast('success', 'Tutorial Complete!', 'You\'re ready to start using voice commands. Press Space or click the microphone to begin.');
        this.showToast(toast);
    }
    
    /**
     * Restart the onboarding tutorial
     */
    restart() {
        localStorage.removeItem('voice-shopping-onboarding-completed');
        this.start();
    }
    
    /**
     * Create a toast notification
     * @param {string} type - Toast type (success, error, warning, info)
     * @param {string} title - Toast title
     * @param {string} message - Toast message
     * @returns {HTMLElement} Toast element
     */
    createToast(type, title, message) {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        const icons = {
            success: '✅',
            error: '❌',
            warning: '⚠️',
            info: 'ℹ️'
        };
        
        toast.innerHTML = `
            <div class="toast-icon">${icons[type] || icons.info}</div>
            <div class="toast-content">
                <div class="toast-title">${title}</div>
                <div class="toast-message">${message}</div>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">×</button>
        `;
        
        return toast;
    }
    
    /**
     * Show a toast notification
     * @param {HTMLElement} toast - Toast element
     */
    showToast(toast) {
        let container = document.querySelector('.toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'toast-container';
            document.body.appendChild(container);
        }
        
        container.appendChild(toast);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.classList.add('removing');
                setTimeout(() => {
                    toast.remove();
                }, 300);
            }
        }, 5000);
    }
    
    /**
     * Clean up onboarding elements
     */
    cleanup() {
        if (this.overlay && this.overlay.parentNode) {
            this.overlay.remove();
        }
        if (this.tooltip && this.tooltip.parentNode) {
            this.tooltip.remove();
        }
        this.removeHighlight();
        this.isActive = false;
    }
    
    /**
     * Announce message to screen readers
     * @param {string} message - Message to announce
     */
    announceToScreenReader(message) {
        const announcement = document.getElementById('sr-announcements');
        if (announcement) {
            announcement.textContent = message;
        }
    }
}

// Make onboarding manager globally available for button callbacks
window.onboardingManager = null;