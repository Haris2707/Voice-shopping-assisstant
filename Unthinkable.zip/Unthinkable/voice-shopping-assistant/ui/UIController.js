/**
 * UIController - Manages the visual interface and user interactions
 * Handles shopping list display, category grouping, and UI updates
 */

import { AccessibilityManager } from '../models/AccessibilityManager.js';

export class UIController {
    /**
     * Create a new UI controller
     * @param {ShoppingListManager} listManager - Shopping list manager instance
     */
    constructor(listManager) {
        this.listManager = listManager;
        
        // Initialize accessibility manager
        this.accessibilityManager = new AccessibilityManager();
        
        // DOM elements
        this.elements = {
            shoppingList: document.getElementById('shopping-list'),
            emptyState: document.getElementById('empty-state'),
            suggestions: document.getElementById('suggestions')
        };
        
        // Mobile detection
        this.isMobile = this.detectMobile();
        
        // Touch interaction state
        this.touchState = {
            startX: 0,
            startY: 0,
            currentX: 0,
            currentY: 0,
            isDragging: false,
            swipeThreshold: 80
        };
        
        // Set up event listeners
        this.setupEventListeners();
        
        // Set up mobile-specific features
        if (this.isMobile) {
            this.setupMobileFeatures();
        }
        
        // Initial render
        this.updateShoppingList();
    }
    
    /**
     * Set up event listeners for list changes
     */
    setupEventListeners() {
        // Listen for shopping list changes
        this.listManager.addEventListener('itemAdded', () => this.updateShoppingList());
        this.listManager.addEventListener('itemRemoved', () => this.updateShoppingList());
        this.listManager.addEventListener('itemUpdated', () => this.updateShoppingList());
        this.listManager.addEventListener('listCleared', () => this.updateShoppingList());
        
        // Set up click handlers for list interactions
        this.elements.shoppingList.addEventListener('click', (e) => {
            this.handleListClick(e);
        });
        
        // Set up touch handlers for mobile
        if (this.isMobile) {
            this.elements.shoppingList.addEventListener('touchstart', (e) => {
                this.handleTouchStart(e);
            }, { passive: false });
            
            this.elements.shoppingList.addEventListener('touchmove', (e) => {
                this.handleTouchMove(e);
            }, { passive: false });
            
            this.elements.shoppingList.addEventListener('touchend', (e) => {
                this.handleTouchEnd(e);
            }, { passive: false });
        }
    }
    
    /**
     * Detect if the device is mobile
     * @returns {boolean} True if mobile device
     */
    detectMobile() {
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
               (window.innerWidth <= 768) ||
               ('ontouchstart' in window);
    }
    
    /**
     * Set up mobile-specific features
     */
    setupMobileFeatures() {
        // Add mobile class to body
        document.body.classList.add('mobile-device');
        
        // Prevent zoom on double tap
        let lastTouchEnd = 0;
        document.addEventListener('touchend', (event) => {
            const now = (new Date()).getTime();
            if (now - lastTouchEnd <= 300) {
                event.preventDefault();
            }
            lastTouchEnd = now;
        }, false);
        
        // Handle orientation changes
        window.addEventListener('orientationchange', () => {
            setTimeout(() => {
                this.handleOrientationChange();
            }, 100);
        });
        
        // Handle viewport changes for mobile keyboards
        this.setupViewportHandler();
    }
    
    /**
     * Handle touch start events for swipe gestures
     * @param {TouchEvent} event - Touch event
     */
    handleTouchStart(event) {
        const touch = event.touches[0];
        const target = event.target.closest('.shopping-item');
        
        if (!target) return;
        
        this.touchState.startX = touch.clientX;
        this.touchState.startY = touch.clientY;
        this.touchState.isDragging = false;
        this.touchState.currentTarget = target;
    }
    
    /**
     * Handle touch move events for swipe gestures
     * @param {TouchEvent} event - Touch event
     */
    handleTouchMove(event) {
        if (!this.touchState.currentTarget) return;
        
        const touch = event.touches[0];
        this.touchState.currentX = touch.clientX;
        this.touchState.currentY = touch.clientY;
        
        const deltaX = this.touchState.startX - this.touchState.currentX;
        const deltaY = Math.abs(this.touchState.startY - this.touchState.currentY);
        
        // Only handle horizontal swipes
        if (Math.abs(deltaX) > 10 && deltaY < 50) {
            this.touchState.isDragging = true;
            event.preventDefault();
            
            // Apply swipe transform
            if (deltaX > 0 && deltaX < this.touchState.swipeThreshold) {
                this.touchState.currentTarget.style.transform = `translateX(-${deltaX}px)`;
            }
        }
    }
    
    /**
     * Handle touch end events for swipe gestures
     * @param {TouchEvent} event - Touch event
     */
    handleTouchEnd(event) {
        if (!this.touchState.currentTarget) return;
        
        const deltaX = this.touchState.startX - this.touchState.currentX;
        
        if (this.touchState.isDragging) {
            if (deltaX > this.touchState.swipeThreshold) {
                // Swipe threshold reached - show delete action
                this.showSwipeActions(this.touchState.currentTarget);
            } else {
                // Reset position
                this.resetSwipePosition(this.touchState.currentTarget);
            }
        }
        
        // Reset touch state
        this.touchState.currentTarget = null;
        this.touchState.isDragging = false;
    }
    
    /**
     * Show swipe actions for an item
     * @param {HTMLElement} itemElement - Item element
     */
    showSwipeActions(itemElement) {
        itemElement.classList.add('swiping');
        
        // Add swipe actions if not already present
        if (!itemElement.querySelector('.swipe-actions')) {
            const swipeActions = document.createElement('div');
            swipeActions.className = 'swipe-actions';
            swipeActions.innerHTML = '🗑️';
            swipeActions.addEventListener('click', () => {
                const itemName = itemElement.getAttribute('data-item-name');
                this.removeItem(itemName);
            });
            itemElement.appendChild(swipeActions);
        }
        
        // Auto-hide after 3 seconds
        setTimeout(() => {
            this.resetSwipePosition(itemElement);
        }, 3000);
    }
    
    /**
     * Reset swipe position for an item
     * @param {HTMLElement} itemElement - Item element
     */
    resetSwipePosition(itemElement) {
        itemElement.classList.remove('swiping');
        itemElement.style.transform = '';
        
        // Remove swipe actions
        const swipeActions = itemElement.querySelector('.swipe-actions');
        if (swipeActions) {
            setTimeout(() => {
                swipeActions.remove();
            }, 300);
        }
    }
    
    /**
     * Handle orientation changes
     */
    handleOrientationChange() {
        // Force a layout recalculation
        this.updateShoppingList();
        
        // Adjust viewport if needed
        if (window.orientation !== undefined) {
            const isLandscape = Math.abs(window.orientation) === 90;
            document.body.classList.toggle('landscape', isLandscape);
            document.body.classList.toggle('portrait', !isLandscape);
        }
    }
    
    /**
     * Set up viewport handler for mobile keyboards
     */
    setupViewportHandler() {
        let initialViewportHeight = window.innerHeight;
        
        window.addEventListener('resize', () => {
            const currentHeight = window.innerHeight;
            const heightDifference = initialViewportHeight - currentHeight;
            
            // If height decreased significantly, keyboard is likely open
            if (heightDifference > 150) {
                document.body.classList.add('keyboard-open');
            } else {
                document.body.classList.remove('keyboard-open');
            }
        });
    }
    
    /**
     * Update the shopping list display
     */
    updateShoppingList() {
        const items = this.listManager.getItems();
        
        if (items.length === 0) {
            this.showEmptyState();
        } else {
            this.hideEmptyState();
            this.renderShoppingList();
        }
        
        // Update accessibility
        this.accessibilityManager.updateShoppingListAccessibility(items.length);
    }
    
    /**
     * Show the empty state message
     */
    showEmptyState() {
        this.elements.emptyState.style.display = 'block';
        this.clearShoppingListContent();
    }
    
    /**
     * Hide the empty state message
     */
    hideEmptyState() {
        this.elements.emptyState.style.display = 'none';
    }
    
    /**
     * Clear the shopping list content
     */
    clearShoppingListContent() {
        // Remove all children except the empty state
        const children = Array.from(this.elements.shoppingList.children);
        children.forEach(child => {
            if (child.id !== 'empty-state') {
                child.remove();
            }
        });
    }
    
    /**
     * Render the shopping list with category grouping
     */
    renderShoppingList() {
        this.clearShoppingListContent();
        
        const groupedItems = this.listManager.getItemsGroupedByCategory();
        const categories = Object.keys(groupedItems).sort();
        
        // Create category sections
        categories.forEach(category => {
            const categorySection = this.createCategorySection(category, groupedItems[category]);
            this.elements.shoppingList.appendChild(categorySection);
        });
    }
    
    /**
     * Create a category section with items
     * @param {string} category - Category name
     * @param {ShoppingItem[]} items - Items in the category
     * @returns {HTMLElement} Category section element
     */
    createCategorySection(category, items) {
        const section = document.createElement('div');
        section.className = 'category-section';
        section.setAttribute('data-category', category);
        
        // Category header
        const header = document.createElement('div');
        header.className = 'category-header';
        header.innerHTML = `
            <h3 class="category-title">${this.formatCategoryName(category)}</h3>
            <span class="category-count">${items.length} item${items.length !== 1 ? 's' : ''}</span>
        `;
        section.appendChild(header);
        
        // Category items
        const itemsContainer = document.createElement('div');
        itemsContainer.className = 'category-items';
        
        items.forEach(item => {
            const itemElement = this.createItemElement(item);
            itemsContainer.appendChild(itemElement);
        });
        
        section.appendChild(itemsContainer);
        
        return section;
    }
    
    /**
     * Create an individual item element
     * @param {ShoppingItem} item - Shopping item
     * @returns {HTMLElement} Item element
     */
    createItemElement(item) {
        const itemDiv = document.createElement('div');
        itemDiv.className = `shopping-item ${item.completed ? 'completed' : ''}`;
        itemDiv.setAttribute('data-item-id', item.id);
        itemDiv.setAttribute('data-item-name', item.name);
        
        itemDiv.innerHTML = `
            <div class="item-info">
                <div class="item-name">${this.escapeHtml(item.name)}</div>
                <div class="item-quantity">${this.escapeHtml(item.quantity)}</div>
            </div>
            <div class="item-actions" role="group" aria-label="Actions for ${this.escapeHtml(item.name)}">
                <button class="item-action-btn complete-btn" 
                        title="${item.completed ? 'Mark as incomplete' : 'Mark as complete'}"
                        aria-label="${item.completed ? 'Mark as incomplete' : 'Mark as complete'}">
                    <span aria-hidden="true">${item.completed ? '↩️' : '✅'}</span>
                    <span class="sr-only">${item.completed ? 'Mark as incomplete' : 'Mark as complete'}</span>
                </button>
                <button class="item-action-btn edit-btn" 
                        title="Edit quantity"
                        aria-label="Edit quantity for ${this.escapeHtml(item.name)}">
                    <span aria-hidden="true">✏️</span>
                    <span class="sr-only">Edit quantity</span>
                </button>
                <button class="item-action-btn remove-btn" 
                        title="Remove item"
                        aria-label="Remove ${this.escapeHtml(item.name)} from shopping list">
                    <span aria-hidden="true">🗑️</span>
                    <span class="sr-only">Remove item</span>
                </button>
            </div>
        `;
        
        // Set up accessibility attributes
        this.accessibilityManager.setupItemAccessibility(itemDiv, item);
        
        return itemDiv;
    }
    
    /**
     * Handle clicks on the shopping list
     * @param {Event} event - Click event
     */
    handleListClick(event) {
        const target = event.target;
        const itemElement = target.closest('.shopping-item');
        
        if (!itemElement) return;
        
        const itemId = itemElement.getAttribute('data-item-id');
        const itemName = itemElement.getAttribute('data-item-name');
        
        if (target.classList.contains('complete-btn')) {
            this.toggleItemCompletion(itemName);
        } else if (target.classList.contains('edit-btn')) {
            this.editItemQuantity(itemName);
        } else if (target.classList.contains('remove-btn')) {
            this.removeItem(itemName);
        }
    }
    
    /**
     * Toggle item completion status
     * @param {string} itemName - Name of the item
     */
    toggleItemCompletion(itemName) {
        const item = this.listManager.findItem(itemName);
        if (item) {
            const wasCompleted = item.completed;
            this.listManager.markItemCompleted(itemName, !item.completed);
            
            // Announce the change to screen readers
            this.accessibilityManager.announceListChange(
                wasCompleted ? 'uncompleted' : 'completed', 
                itemName
            );
        }
    }
    
    /**
     * Edit item quantity with a prompt
     * @param {string} itemName - Name of the item
     */
    editItemQuantity(itemName) {
        const item = this.listManager.findItem(itemName);
        if (!item) return;
        
        const newQuantity = prompt(`Enter new quantity for ${item.name}:`, item.quantity);
        
        if (newQuantity !== null && newQuantity.trim() !== '') {
            this.listManager.updateQuantity(itemName, newQuantity.trim());
        }
    }
    
    /**
     * Remove an item with confirmation
     * @param {string} itemName - Name of the item
     */
    removeItem(itemName) {
        const item = this.listManager.findItem(itemName);
        if (!item) return;
        
        if (confirm(`Remove "${item.name}" from your shopping list?`)) {
            this.listManager.removeItem(itemName);
        }
    }
    
    /**
     * Display error message to user
     * @param {string} message - Error message
     */
    displayError(message) {
        // Create or update error display
        let errorDiv = document.getElementById('error-message');
        
        if (!errorDiv) {
            errorDiv = document.createElement('div');
            errorDiv.id = 'error-message';
            errorDiv.className = 'error-message';
            errorDiv.setAttribute('role', 'alert');
            errorDiv.setAttribute('aria-live', 'assertive');
            this.elements.shoppingList.parentNode.insertBefore(errorDiv, this.elements.shoppingList);
        }
        
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';
        
        // Announce to screen readers
        this.accessibilityManager.announceError(message);
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            errorDiv.style.display = 'none';
        }, 5000);
    }
    
    /**
     * Display success message to user
     * @param {string} message - Success message
     */
    displaySuccess(message) {
        // Create or update success display
        let successDiv = document.getElementById('success-message');
        
        if (!successDiv) {
            successDiv = document.createElement('div');
            successDiv.id = 'success-message';
            successDiv.className = 'success-message';
            successDiv.setAttribute('role', 'status');
            successDiv.setAttribute('aria-live', 'polite');
            this.elements.shoppingList.parentNode.insertBefore(successDiv, this.elements.shoppingList);
        }
        
        successDiv.textContent = message;
        successDiv.style.display = 'block';
        
        // Announce to screen readers
        this.accessibilityManager.announceSuccess(message);
        
        // Auto-hide after 3 seconds
        setTimeout(() => {
            successDiv.style.display = 'none';
        }, 3000);
    }
    
    /**
     * Show suggestions in the suggestions area
     * @param {Array} suggestions - Array of suggestion objects or strings
     */
    showSuggestions(suggestions) {
        if (!this.elements.suggestions) {
            console.warn('Suggestions element not found');
            return;
        }
        
        if (!suggestions || suggestions.length === 0) {
            this.elements.suggestions.innerHTML = '<p class="no-suggestions">No suggestions available</p>';
            this.elements.suggestions.style.display = 'none';
            this.accessibilityManager.updateSuggestionsAccessibility(0);
            return;
        }
        
        this.elements.suggestions.innerHTML = '';
        this.elements.suggestions.style.display = 'block';
        
        // Add suggestions header
        const header = document.createElement('div');
        header.className = 'suggestions-header';
        header.innerHTML = '<h3>Smart Suggestions</h3>';
        this.elements.suggestions.appendChild(header);
        
        const suggestionsContainer = document.createElement('div');
        suggestionsContainer.className = 'suggestions-container';
        suggestionsContainer.setAttribute('role', 'list');
        suggestionsContainer.setAttribute('aria-label', `${suggestions.length} suggestions available`);
        
        suggestions.forEach((suggestion, index) => {
            const suggestionElement = this.createSuggestionElement(suggestion, index + 1);
            suggestionsContainer.appendChild(suggestionElement);
        });
        
        this.elements.suggestions.appendChild(suggestionsContainer);
        
        // Add voice instructions
        const voiceInstructions = document.createElement('div');
        voiceInstructions.className = 'voice-instructions';
        voiceInstructions.setAttribute('role', 'note');
        voiceInstructions.innerHTML = '<p>💡 Say "add suggestion 1" or click to add items</p>';
        this.elements.suggestions.appendChild(voiceInstructions);
        
        // Update accessibility
        this.accessibilityManager.updateSuggestionsAccessibility(suggestions.length);
    }
    
    /**
     * Create a suggestion element
     * @param {Object|string} suggestion - Suggestion object or string
     * @param {number} index - Suggestion index for voice commands
     * @returns {HTMLElement} Suggestion element
     */
    createSuggestionElement(suggestion, index) {
        const suggestionDiv = document.createElement('div');
        suggestionDiv.className = 'suggestion-item';
        suggestionDiv.setAttribute('tabindex', '0');
        suggestionDiv.setAttribute('role', 'listitem');
        
        // Handle both object and string suggestions
        const itemName = typeof suggestion === 'string' ? suggestion : suggestion.itemName;
        const reason = typeof suggestion === 'object' ? suggestion.reason : '';
        const type = typeof suggestion === 'object' ? suggestion.type : 'general';
        const confidence = typeof suggestion === 'object' ? suggestion.confidence : 0.5;
        
        suggestionDiv.setAttribute('data-suggestion-index', index);
        suggestionDiv.setAttribute('data-item-name', itemName);
        
        // Set up accessibility attributes
        this.accessibilityManager.setupSuggestionAccessibility(suggestionDiv, suggestion, index);
        
        // Create suggestion content
        const content = document.createElement('div');
        content.className = 'suggestion-content';
        
        const itemInfo = document.createElement('div');
        itemInfo.className = 'suggestion-item-info';
        
        const itemNameEl = document.createElement('div');
        itemNameEl.className = 'suggestion-item-name';
        itemNameEl.textContent = itemName;
        
        const itemReason = document.createElement('div');
        itemReason.className = 'suggestion-reason';
        itemReason.textContent = reason || 'Recommended for you';
        
        itemInfo.appendChild(itemNameEl);
        itemInfo.appendChild(itemReason);
        
        const suggestionMeta = document.createElement('div');
        suggestionMeta.className = 'suggestion-meta';
        
        const typeIcon = this.getSuggestionTypeIcon(type);
        const typeEl = document.createElement('span');
        typeEl.className = 'suggestion-type';
        typeEl.innerHTML = `${typeIcon} ${this.formatSuggestionType(type)}`;
        
        const voiceIndex = document.createElement('span');
        voiceIndex.className = 'suggestion-voice-index';
        voiceIndex.textContent = index;
        
        suggestionMeta.appendChild(typeEl);
        suggestionMeta.appendChild(voiceIndex);
        
        content.appendChild(itemInfo);
        content.appendChild(suggestionMeta);
        
        suggestionDiv.appendChild(content);
        
        // Add confidence indicator
        if (confidence > 0) {
            const confidenceBar = document.createElement('div');
            confidenceBar.className = 'suggestion-confidence';
            confidenceBar.style.width = `${confidence * 100}%`;
            suggestionDiv.appendChild(confidenceBar);
        }
        
        // Add click handler
        suggestionDiv.addEventListener('click', () => {
            this.addSuggestionToList(itemName, suggestion);
        });
        
        // Add keyboard handler
        suggestionDiv.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.addSuggestionToList(itemName, suggestion);
            }
        });
        
        return suggestionDiv;
    }
    
    /**
     * Get icon for suggestion type
     * @param {string} type - Suggestion type
     * @returns {string} Icon emoji
     */
    getSuggestionTypeIcon(type) {
        const icons = {
            'frequent': '🔄',
            'seasonal': '🌟',
            'substitute': '🔄',
            'general': '💡'
        };
        return icons[type] || icons.general;
    }
    
    /**
     * Format suggestion type for display
     * @param {string} type - Suggestion type
     * @returns {string} Formatted type
     */
    formatSuggestionType(type) {
        const types = {
            'frequent': 'Frequent',
            'seasonal': 'Seasonal',
            'substitute': 'Alternative',
            'general': 'Suggested'
        };
        return types[type] || types.general;
    }
    
    /**
     * Add a suggestion to the shopping list
     * @param {string} itemName - Item name to add
     * @param {Object} suggestionData - Full suggestion object (optional)
     */
    addSuggestionToList(itemName, suggestionData = null) {
        try {
            this.listManager.addItem(itemName);
            this.displaySuccess(`Added "${itemName}" to your shopping list`);
            
            // Remove the suggestion from display
            this.removeSuggestionFromDisplay(itemName);
            
            // Trigger suggestion accepted event if callback exists
            if (this.onSuggestionAccepted && typeof this.onSuggestionAccepted === 'function') {
                this.onSuggestionAccepted(suggestionData || { itemName });
            }
        } catch (error) {
            this.displayError(`Failed to add "${itemName}": ${error.message}`);
        }
    }
    
    /**
     * Remove a suggestion from the display after it's been added
     * @param {string} itemName - Name of the item to remove from suggestions
     */
    removeSuggestionFromDisplay(itemName) {
        if (!this.elements.suggestions) return;
        
        const suggestionElement = this.elements.suggestions.querySelector(`[data-item-name="${itemName}"]`);
        if (suggestionElement) {
            suggestionElement.style.opacity = '0.5';
            suggestionElement.style.pointerEvents = 'none';
            
            setTimeout(() => {
                suggestionElement.remove();
                
                // Hide suggestions container if no suggestions left
                const remainingSuggestions = this.elements.suggestions.querySelectorAll('.suggestion-item');
                if (remainingSuggestions.length === 0) {
                    this.elements.suggestions.style.display = 'none';
                }
            }, 1000);
        }
    }
    
    /**
     * Set callback for when suggestions are accepted
     * @param {Function} callback - Callback function
     */
    setSuggestionAcceptedCallback(callback) {
        this.onSuggestionAccepted = callback;
    }
    
    /**
     * Update voice status for accessibility
     * @param {boolean} isListening - Whether voice recognition is active
     * @param {string} status - Current status message
     */
    updateVoiceStatus(isListening, status) {
        this.accessibilityManager.updateVoiceStatus(isListening, status);
    }
    
    /**
     * Show listening indicator with accessibility support
     */
    showListeningIndicator() {
        const indicator = document.getElementById('listening-indicator');
        if (indicator) {
            indicator.style.display = 'flex';
            indicator.setAttribute('aria-hidden', 'false');
        }
        this.updateVoiceStatus(true, 'Listening for voice commands');
    }
    
    /**
     * Hide listening indicator with accessibility support
     */
    hideListeningIndicator() {
        const indicator = document.getElementById('listening-indicator');
        if (indicator) {
            indicator.style.display = 'none';
            indicator.setAttribute('aria-hidden', 'true');
        }
        this.updateVoiceStatus(false, 'Ready');
    }
    
    /**
     * Show voice processing status
     * @param {string} transcript - What was heard
     */
    showVoiceProcessing(transcript) {
        this.accessibilityManager.announceToScreenReader(`Processing: ${transcript}`, 'polite');
    }
    
    /**
     * Show voice result with accessibility
     * @param {string} message - Result message
     * @param {boolean} success - Whether the operation was successful
     */
    showVoiceResult(message, success) {
        if (success) {
            this.displaySuccess(message);
        } else {
            this.displayError(message);
        }
    }
    
    /**
     * Hide suggestions display
     */
    hideSuggestions() {
        if (this.elements.suggestions) {
            this.elements.suggestions.style.display = 'none';
        }
    }
    
    /**
     * Show substitute suggestions for an item
     * @param {string} originalItem - Original item name
     * @param {Array} substitutes - Array of substitute suggestions
     */
    showSubstituteSuggestions(originalItem, substitutes) {
        if (!substitutes || substitutes.length === 0) {
            return;
        }
        
        // Create substitute suggestions modal or section
        let substituteDiv = document.getElementById('substitute-suggestions');
        
        if (!substituteDiv) {
            substituteDiv = document.createElement('div');
            substituteDiv.id = 'substitute-suggestions';
            substituteDiv.className = 'substitute-suggestions';
            this.elements.shoppingList.parentNode.insertBefore(substituteDiv, this.elements.shoppingList);
        }
        
        substituteDiv.innerHTML = `
            <div class="substitute-header">
                <h4>Alternatives for "${originalItem}"</h4>
                <button class="close-substitutes" aria-label="Close substitutes">×</button>
            </div>
            <div class="substitute-list"></div>
        `;
        
        const substituteList = substituteDiv.querySelector('.substitute-list');
        
        substitutes.forEach((substitute, index) => {
            const substituteElement = this.createSuggestionElement(substitute, index + 1);
            substituteElement.classList.add('substitute-item');
            substituteList.appendChild(substituteElement);
        });
        
        // Add close handler
        substituteDiv.querySelector('.close-substitutes').addEventListener('click', () => {
            substituteDiv.style.display = 'none';
        });
        
        substituteDiv.style.display = 'block';
        
        // Auto-hide after 10 seconds
        setTimeout(() => {
            substituteDiv.style.display = 'none';
        }, 10000);
    }
    
    /**
     * Format category name for display
     * @param {string} category - Raw category name
     * @returns {string} Formatted category name
     */
    formatCategoryName(category) {
        return category.charAt(0).toUpperCase() + category.slice(1);
    }
    
    /**
     * Escape HTML to prevent XSS
     * @param {string} text - Text to escape
     * @returns {string} Escaped text
     */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    /**
     * Get shopping list statistics for display
     * @returns {Object} Statistics object
     */
    getDisplayStatistics() {
        const stats = this.listManager.getStatistics();
        
        return {
            ...stats,
            completionPercentage: stats.totalItems > 0 
                ? Math.round((stats.completedItems / stats.totalItems) * 100) 
                : 0
        };
    }
    
    /**
     * Update the shopping list with animation
     */
    updateShoppingListAnimated() {
        // Add fade-out animation
        this.elements.shoppingList.style.opacity = '0.5';
        
        setTimeout(() => {
            this.updateShoppingList();
            
            // Add fade-in animation
            this.elements.shoppingList.style.opacity = '1';
        }, 150);
    }
    
    /**
     * Highlight a specific item (useful for voice feedback)
     * @param {string} itemName - Name of the item to highlight
     */
    highlightItem(itemName) {
        const itemElement = this.elements.shoppingList.querySelector(`[data-item-name="${itemName}"]`);
        
        if (itemElement) {
            itemElement.classList.add('highlighted');
            
            // Remove highlight after 2 seconds
            setTimeout(() => {
                itemElement.classList.remove('highlighted');
            }, 2000);
            
            // Scroll item into view
            itemElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }
    
    /**
     * Show loading state
     */
    showLoading() {
        let loadingDiv = document.getElementById('loading-indicator');
        
        if (!loadingDiv) {
            loadingDiv = document.createElement('div');
            loadingDiv.id = 'loading-indicator';
            loadingDiv.className = 'loading-indicator';
            loadingDiv.innerHTML = '<div class="spinner"></div><span>Processing...</span>';
            this.elements.shoppingList.parentNode.insertBefore(loadingDiv, this.elements.shoppingList);
        }
        
        loadingDiv.style.display = 'flex';
    }
    
    /**
     * Hide loading state
     */
    hideLoading() {
        const loadingDiv = document.getElementById('loading-indicator');
        if (loadingDiv) {
            loadingDiv.style.display = 'none';
        }
    }
    
    /**
     * Show listening state
     */
    showListeningIndicator() {
        // Create or update listening indicator
        let listeningDiv = document.getElementById('voice-listening');
        
        if (!listeningDiv) {
            listeningDiv = document.createElement('div');
            listeningDiv.id = 'voice-listening';
            listeningDiv.className = 'voice-listening-indicator';
            listeningDiv.innerHTML = '<div class="pulse"></div><span>Listening...</span>';
            this.elements.shoppingList.parentNode.insertBefore(listeningDiv, this.elements.shoppingList);
        }
        
        listeningDiv.style.display = 'flex';
    }
    
    /**
     * Hide listening state
     */
    hideListeningIndicator() {
        const listeningDiv = document.getElementById('voice-listening');
        if (listeningDiv) {
            listeningDiv.style.display = 'none';
        }
    }
    
    /**
     * Show voice processing feedback
     * @param {string} transcript - What was heard
     */
    showVoiceProcessing(transcript) {
        let processingDiv = document.getElementById('voice-processing');
        
        if (!processingDiv) {
            processingDiv = document.createElement('div');
            processingDiv.id = 'voice-processing';
            processingDiv.className = 'voice-processing-indicator';
            this.elements.shoppingList.parentNode.insertBefore(processingDiv, this.elements.shoppingList);
        }
        
        processingDiv.innerHTML = `<div class="processing-spinner"></div><span>Processing: "${transcript}"</span>`;
        processingDiv.style.display = 'flex';
        
        // Auto-hide after 3 seconds
        setTimeout(() => {
            processingDiv.style.display = 'none';
        }, 3000);
    }
    
    /**
     * Show voice command result
     * @param {string} result - Result message
     * @param {boolean} isSuccess - Whether the command was successful
     */
    showVoiceResult(result, isSuccess = true) {
        const resultDiv = document.createElement('div');
        resultDiv.className = `voice-result ${isSuccess ? 'success' : 'error'}`;
        resultDiv.innerHTML = `
            <div class="result-icon">${isSuccess ? '✅' : '❌'}</div>
            <span class="result-text">${result}</span>
        `;
        
        // Insert at the top of the shopping list area
        this.elements.shoppingList.parentNode.insertBefore(resultDiv, this.elements.shoppingList);
        
        // Animate in
        setTimeout(() => resultDiv.classList.add('show'), 10);
        
        // Remove after 4 seconds
        setTimeout(() => {
            resultDiv.classList.remove('show');
            setTimeout(() => resultDiv.remove(), 300);
        }, 4000);
    }
    
    /**
     * Display search results in the UI
     * @param {Object} displayData - Formatted search results data
     */
    displaySearchResults(displayData) {
        // Remove any existing search results
        this.clearSearchResults();
        
        // Create search results container
        const searchResultsDiv = document.createElement('div');
        searchResultsDiv.id = 'search-results';
        searchResultsDiv.className = 'search-results';
        
        // Add search summary
        const summaryDiv = document.createElement('div');
        summaryDiv.className = 'search-summary';
        summaryDiv.innerHTML = `
            <h3>🔍 Search Results</h3>
            <p>${this.escapeHtml(displayData.summary)}</p>
        `;
        searchResultsDiv.appendChild(summaryDiv);
        
        if (displayData.isEmpty) {
            // Show empty search state
            const emptyDiv = document.createElement('div');
            emptyDiv.className = 'search-empty';
            emptyDiv.innerHTML = `
                <p>Try searching with different terms or removing some filters.</p>
                <p>💡 You can search for things like:</p>
                <ul>
                    <li>"organic apples"</li>
                    <li>"milk under $4"</li>
                    <li>"chicken breast"</li>
                </ul>
            `;
            searchResultsDiv.appendChild(emptyDiv);
        } else {
            // Show search results
            const resultsDiv = document.createElement('div');
            resultsDiv.className = 'search-results-list';
            
            displayData.products.forEach((product, index) => {
                const productDiv = this.createSearchResultItem(product, index + 1);
                resultsDiv.appendChild(productDiv);
            });
            
            searchResultsDiv.appendChild(resultsDiv);
            
            if (displayData.hasMoreResults) {
                const moreDiv = document.createElement('div');
                moreDiv.className = 'search-more-results';
                moreDiv.innerHTML = '<p>... and more results available</p>';
                searchResultsDiv.appendChild(moreDiv);
            }
            
            // Add voice instructions
            const voiceInstructions = document.createElement('div');
            voiceInstructions.className = 'voice-instructions';
            voiceInstructions.innerHTML = '<p>💡 Say "add result 1" or click the + button to add items to your list</p>';
            searchResultsDiv.appendChild(voiceInstructions);
        }
        
        // Add close button
        const closeButton = document.createElement('button');
        closeButton.className = 'search-close-btn';
        closeButton.innerHTML = '✕ Close Search';
        closeButton.addEventListener('click', () => this.clearSearchResults());
        searchResultsDiv.appendChild(closeButton);
        
        // Insert search results before shopping list
        this.elements.shoppingList.parentNode.insertBefore(searchResultsDiv, this.elements.shoppingList);
        
        // Auto-hide after 30 seconds
        setTimeout(() => {
            this.clearSearchResults();
        }, 30000);
    }
    
    /**
     * Create a search result item element
     * @param {Object} product - Product data
     * @param {number} index - Result index for voice commands
     * @returns {HTMLElement} Product result element
     */
    createSearchResultItem(product, index) {
        const productDiv = document.createElement('div');
        productDiv.className = 'search-result-item';
        productDiv.dataset.productId = product.id;
        productDiv.dataset.resultIndex = index;
        
        productDiv.innerHTML = `
            <div class="search-result-content">
                <div class="search-result-main">
                    <span class="search-result-number">${index}</span>
                    <span class="search-result-name">${this.escapeHtml(product.displayName)}</span>
                    <span class="search-result-price">${product.priceDisplay}</span>
                </div>
                <div class="search-result-details">
                    <span class="search-result-category">${this.formatCategoryName(product.category)}</span>
                    ${product.organic ? '<span class="organic-badge">Organic</span>' : ''}
                </div>
            </div>
            <button class="search-result-add-btn" 
                    title="Add to shopping list"
                    aria-label="Add ${product.name} to shopping list">
                +
            </button>
        `;
        
        // Add click handler for add button
        const addButton = productDiv.querySelector('.search-result-add-btn');
        addButton.addEventListener('click', (e) => {
            e.preventDefault();
            this.addSearchResultToList(product);
        });
        
        return productDiv;
    }
    
    /**
     * Add a search result to the shopping list
     * @param {Object} product - Product data
     */
    addSearchResultToList(product) {
        try {
            const addedItem = this.listManager.addItem(product.name, '1');
            this.displaySuccess(`Added ${product.name} to your list`);
            this.highlightItem(product.name);
            
            // Remove the search result item with animation
            const resultItem = document.querySelector(`[data-product-id="${product.id}"]`);
            if (resultItem) {
                resultItem.style.opacity = '0.5';
                resultItem.style.transform = 'translateX(20px)';
                setTimeout(() => {
                    if (resultItem.parentNode) {
                        resultItem.remove();
                    }
                }, 500);
            }
        } catch (error) {
            this.displayError(`Failed to add "${product.name}": ${error.message}`);
        }
    }
    
    /**
     * Clear search results from the UI
     */
    clearSearchResults() {
        const existingResults = document.getElementById('search-results');
        if (existingResults) {
            existingResults.remove();
        }
    }
    
    /**
     * Highlight an item in the shopping list
     * @param {string} itemName - Name of item to highlight
     */
    highlightItem(itemName) {
        const itemElement = this.elements.shoppingList.querySelector(`[data-item-name="${itemName}"]`);
        if (itemElement) {
            itemElement.classList.add('highlighted');
            
            // Scroll item into view
            itemElement.scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
            
            // Remove highlight after animation
            setTimeout(() => {
                itemElement.classList.remove('highlighted');
            }, 2000);
        }
    }
    
    /**
     * Add success animation to an element
     * @param {HTMLElement} element - Element to animate
     */
    addSuccessAnimation(element) {
        element.classList.add('success-animation');
        setTimeout(() => {
            element.classList.remove('success-animation');
        }, 600);
    }
    
    /**
     * Add error animation to an element
     * @param {HTMLElement} element - Element to animate
     */
    addErrorAnimation(element) {
        element.classList.add('error-animation');
        setTimeout(() => {
            element.classList.remove('error-animation');
        }, 500);
    }
}