/**
 * LoadingManager - Handles loading states and progress indicators
 * Provides visual feedback during async operations
 */

export class LoadingManager {
    constructor() {
        this.activeLoaders = new Map();
        this.loadingContainer = null;
        this.init();
    }
    
    /**
     * Initialize the loading manager
     */
    init() {
        this.createLoadingContainer();
    }
    
    /**
     * Create the main loading container
     */
    createLoadingContainer() {
        this.loadingContainer = document.createElement('div');
        this.loadingContainer.id = 'loading-container';
        this.loadingContainer.className = 'loading-container';
        document.body.appendChild(this.loadingContainer);
    }
    
    /**
     * Show loading indicator
     * @param {string} id - Unique identifier for this loading operation
     * @param {Object} options - Loading options
     * @param {string} options.message - Loading message
     * @param {string} options.type - Loading type (spinner, dots, progress)
     * @param {HTMLElement} options.target - Target element to show loading in
     * @param {boolean} options.overlay - Whether to show overlay
     */
    show(id, options = {}) {
        const {
            message = 'Loading...',
            type = 'spinner',
            target = null,
            overlay = false
        } = options;
        
        // Remove existing loader with same ID
        this.hide(id);
        
        const loader = this.createLoader(id, message, type, overlay);
        this.activeLoaders.set(id, loader);
        
        if (target) {
            target.appendChild(loader.element);
        } else {
            this.loadingContainer.appendChild(loader.element);
        }
        
        // Show with animation
        requestAnimationFrame(() => {
            loader.element.classList.add('show');
        });
        
        return loader;
    }
    
    /**
     * Hide loading indicator
     * @param {string} id - Loader identifier
     */
    hide(id) {
        const loader = this.activeLoaders.get(id);
        if (!loader) return;
        
        loader.element.classList.remove('show');
        
        setTimeout(() => {
            if (loader.element.parentNode) {
                loader.element.remove();
            }
            this.activeLoaders.delete(id);
        }, 300);
    }
    
    /**
     * Update loading progress
     * @param {string} id - Loader identifier
     * @param {number} progress - Progress percentage (0-100)
     * @param {string} message - Optional message update
     */
    updateProgress(id, progress, message = null) {
        const loader = this.activeLoaders.get(id);
        if (!loader) return;
        
        if (loader.progressBar) {
            loader.progressBar.style.width = `${Math.max(0, Math.min(100, progress))}%`;
        }
        
        if (message && loader.messageElement) {
            loader.messageElement.textContent = message;
        }
    }
    
    /**
     * Create a loader element
     * @param {string} id - Loader identifier
     * @param {string} message - Loading message
     * @param {string} type - Loader type
     * @param {boolean} overlay - Whether to show overlay
     * @returns {Object} Loader object
     */
    createLoader(id, message, type, overlay) {
        const element = document.createElement('div');
        element.className = `loading-indicator ${type}`;
        element.setAttribute('data-loader-id', id);
        element.setAttribute('role', 'status');
        element.setAttribute('aria-live', 'polite');
        element.setAttribute('aria-label', message);
        
        if (overlay) {
            element.classList.add('overlay');
        }
        
        let spinner = null;
        let progressBar = null;
        let messageElement = null;
        
        // Create spinner based on type
        switch (type) {
            case 'spinner':
                spinner = this.createSpinner();
                break;
            case 'dots':
                spinner = this.createDotsSpinner();
                break;
            case 'progress':
                const progressContainer = this.createProgressBar();
                spinner = progressContainer.container;
                progressBar = progressContainer.bar;
                break;
            case 'skeleton':
                spinner = this.createSkeletonLoader();
                break;
        }
        
        // Create message element
        messageElement = document.createElement('span');
        messageElement.className = 'loading-message';
        messageElement.textContent = message;
        
        // Assemble loader
        if (spinner) {
            element.appendChild(spinner);
        }
        element.appendChild(messageElement);
        
        return {
            element,
            spinner,
            progressBar,
            messageElement,
            id,
            type
        };
    }
    
    /**
     * Create spinning loader
     * @returns {HTMLElement} Spinner element
     */
    createSpinner() {
        const spinner = document.createElement('div');
        spinner.className = 'spinner';
        return spinner;
    }
    
    /**
     * Create dots spinner
     * @returns {HTMLElement} Dots spinner element
     */
    createDotsSpinner() {
        const container = document.createElement('div');
        container.className = 'spinner-dots';
        
        for (let i = 0; i < 3; i++) {
            const dot = document.createElement('div');
            dot.className = 'dot';
            container.appendChild(dot);
        }
        
        return container;
    }
    
    /**
     * Create progress bar
     * @returns {Object} Progress bar container and bar elements
     */
    createProgressBar() {
        const container = document.createElement('div');
        container.className = 'progress-bar';
        
        const bar = document.createElement('div');
        bar.className = 'progress-bar-fill';
        bar.style.width = '0%';
        
        container.appendChild(bar);
        
        return { container, bar };
    }
    
    /**
     * Create skeleton loader
     * @returns {HTMLElement} Skeleton loader element
     */
    createSkeletonLoader() {
        const skeleton = document.createElement('div');
        skeleton.className = 'skeleton-loader';
        skeleton.style.width = '200px';
        skeleton.style.height = '20px';
        return skeleton;
    }
    
    /**
     * Show voice processing indicator
     * @param {string} transcript - What is being processed
     */
    showVoiceProcessing(transcript) {
        this.show('voice-processing', {
            message: `Processing: "${transcript}"`,
            type: 'dots',
            overlay: false
        });
    }
    
    /**
     * Hide voice processing indicator
     */
    hideVoiceProcessing() {
        this.hide('voice-processing');
    }
    
    /**
     * Show voice listening indicator
     */
    showVoiceListening() {
        this.show('voice-listening', {
            message: 'Listening for voice commands...',
            type: 'dots',
            overlay: false
        });
    }
    
    /**
     * Hide voice listening indicator
     */
    hideVoiceListening() {
        this.hide('voice-listening');
    }
    
    /**
     * Show search loading
     * @param {string} query - Search query
     */
    showSearchLoading(query) {
        this.show('search', {
            message: `Searching for "${query}"...`,
            type: 'spinner',
            overlay: false
        });
    }
    
    /**
     * Hide search loading
     */
    hideSearchLoading() {
        this.hide('search');
    }
    
    /**
     * Show suggestions loading
     */
    showSuggestionsLoading() {
        this.show('suggestions', {
            message: 'Loading smart suggestions...',
            type: 'skeleton',
            overlay: false
        });
    }
    
    /**
     * Hide suggestions loading
     */
    hideSuggestionsLoading() {
        this.hide('suggestions');
    }
    
    /**
     * Show app initialization loading
     */
    showAppLoading() {
        this.show('app-init', {
            message: 'Initializing Voice Shopping Assistant...',
            type: 'progress',
            overlay: true
        });
    }
    
    /**
     * Update app loading progress
     * @param {number} progress - Progress percentage
     * @param {string} message - Progress message
     */
    updateAppLoading(progress, message) {
        this.updateProgress('app-init', progress, message);
    }
    
    /**
     * Hide app loading
     */
    hideAppLoading() {
        this.hide('app-init');
    }
    
    /**
     * Show microphone permission loading
     */
    showMicrophonePermissionLoading() {
        this.show('mic-permission', {
            message: 'Requesting microphone access...',
            type: 'dots',
            overlay: false
        });
    }
    
    /**
     * Hide microphone permission loading
     */
    hideMicrophonePermissionLoading() {
        this.hide('mic-permission');
    }
    
    /**
     * Show language switching loading
     * @param {string} language - Target language
     */
    showLanguageSwitchLoading(language) {
        this.show('language-switch', {
            message: `Switching to ${language}...`,
            type: 'spinner',
            overlay: false
        });
    }
    
    /**
     * Hide language switching loading
     */
    hideLanguageSwitchLoading() {
        this.hide('language-switch');
    }
    
    /**
     * Show generic operation loading
     * @param {string} operation - Operation name
     */
    showOperationLoading(operation) {
        this.show('operation', {
            message: `${operation}...`,
            type: 'spinner',
            overlay: false
        });
    }
    
    /**
     * Hide generic operation loading
     */
    hideOperationLoading() {
        this.hide('operation');
    }
    
    /**
     * Hide all active loaders
     */
    hideAll() {
        const loaderIds = Array.from(this.activeLoaders.keys());
        loaderIds.forEach(id => this.hide(id));
    }
    
    /**
     * Check if any loaders are active
     * @returns {boolean} True if any loaders are active
     */
    hasActiveLoaders() {
        return this.activeLoaders.size > 0;
    }
    
    /**
     * Get active loader count
     * @returns {number} Number of active loaders
     */
    getActiveLoaderCount() {
        return this.activeLoaders.size;
    }
}