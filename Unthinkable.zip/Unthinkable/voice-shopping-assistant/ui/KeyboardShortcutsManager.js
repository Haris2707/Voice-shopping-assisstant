/**
 * KeyboardShortcutsManager - Handles keyboard shortcuts for power users
 * Provides quick access to common functions via keyboard
 */

export class KeyboardShortcutsManager {
    constructor(app) {
        this.app = app;
        this.isHelpVisible = false;
        this.shortcuts = [
            {
                keys: ['Space'],
                description: 'Toggle voice recording',
                action: () => this.app.toggleListening()
            },
            {
                keys: ['Ctrl', 'Enter'],
                description: 'Start voice recording',
                action: () => this.app.voiceProcessor.startListening()
            },
            {
                keys: ['Escape'],
                description: 'Stop voice recording',
                action: () => this.app.voiceProcessor.stopListening()
            },
            {
                keys: ['Ctrl', 'L'],
                description: 'Focus on text input',
                action: () => this.focusTextInput()
            },
            {
                keys: ['Ctrl', 'K'],
                description: 'Clear shopping list',
                action: () => this.clearListWithConfirmation()
            },
            {
                keys: ['Ctrl', 'S'],
                description: 'Show suggestions',
                action: () => this.app.showSmartSuggestions()
            },
            {
                keys: ['Ctrl', 'H'],
                description: 'Show keyboard shortcuts',
                action: () => this.toggleHelp()
            },
            {
                keys: ['Ctrl', 'T'],
                description: 'Restart onboarding tutorial',
                action: () => this.restartTutorial()
            },
            {
                keys: ['Ctrl', 'Shift', 'L'],
                description: 'Change language',
                action: () => this.focusLanguageSelector()
            },
            {
                keys: ['1', '2', '3', '4', '5'],
                description: 'Add suggestion by number (1-5)',
                action: (key) => this.addSuggestionByNumber(parseInt(key))
            },
            {
                keys: ['Delete'],
                description: 'Remove last added item',
                action: () => this.removeLastItem()
            },
            {
                keys: ['Ctrl', 'Z'],
                description: 'Undo last action',
                action: () => this.undoLastAction()
            }
        ];
        
        this.actionHistory = [];
        this.maxHistorySize = 10;
        
        this.init();
    }
    
    /**
     * Initialize keyboard shortcuts
     */
    init() {
        this.setupEventListeners();
        this.createHelpModal();
        this.addKeyboardNavigationClass();
    }
    
    /**
     * Set up event listeners for keyboard shortcuts
     */
    setupEventListeners() {
        document.addEventListener('keydown', (e) => {
            this.handleKeyDown(e);
        });
        
        // Track keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                document.body.classList.add('keyboard-navigation');
            }
        });
        
        document.addEventListener('mousedown', () => {
            document.body.classList.remove('keyboard-navigation');
        });
    }
    
    /**
     * Handle keydown events
     * @param {KeyboardEvent} event - Keyboard event
     */
    handleKeyDown(event) {
        // Don't handle shortcuts when typing in input fields
        if (this.isTypingInInput(event.target)) {
            return;
        }
        
        // Don't handle shortcuts when onboarding is active
        if (window.onboardingManager && window.onboardingManager.isActive) {
            return;
        }
        
        const key = event.key;
        const ctrl = event.ctrlKey || event.metaKey;
        const shift = event.shiftKey;
        const alt = event.altKey;
        
        // Find matching shortcut
        for (const shortcut of this.shortcuts) {
            if (this.matchesShortcut(shortcut, key, ctrl, shift, alt)) {
                event.preventDefault();
                event.stopPropagation();
                
                // Execute shortcut action
                if (typeof shortcut.action === 'function') {
                    if (shortcut.keys.includes('1') || shortcut.keys.includes('2') || 
                        shortcut.keys.includes('3') || shortcut.keys.includes('4') || 
                        shortcut.keys.includes('5')) {
                        shortcut.action(key);
                    } else {
                        shortcut.action();
                    }
                }
                
                // Provide audio feedback for voice-related shortcuts
                if (shortcut.keys.includes('Space') || shortcut.keys.includes('Ctrl')) {
                    this.provideShortcutFeedback(shortcut.description);
                }
                
                break;
            }
        }
    }
    
    /**
     * Check if a shortcut matches the current key combination
     * @param {Object} shortcut - Shortcut configuration
     * @param {string} key - Pressed key
     * @param {boolean} ctrl - Ctrl key pressed
     * @param {boolean} shift - Shift key pressed
     * @param {boolean} alt - Alt key pressed
     * @returns {boolean} True if shortcut matches
     */
    matchesShortcut(shortcut, key, ctrl, shift, alt) {
        const keys = shortcut.keys;
        
        // Handle single key shortcuts
        if (keys.length === 1) {
            const shortcutKey = keys[0];
            
            // Number keys for suggestions
            if (['1', '2', '3', '4', '5'].includes(shortcutKey)) {
                return key === shortcutKey && !ctrl && !shift && !alt;
            }
            
            // Space key
            if (shortcutKey === 'Space') {
                return key === ' ' && !ctrl && !shift && !alt;
            }
            
            // Escape key
            if (shortcutKey === 'Escape') {
                return key === 'Escape' && !ctrl && !shift && !alt;
            }
            
            // Delete key
            if (shortcutKey === 'Delete') {
                return key === 'Delete' && !ctrl && !shift && !alt;
            }
        }
        
        // Handle multi-key shortcuts
        if (keys.includes('Ctrl') && keys.includes('Shift')) {
            return ctrl && shift && keys.includes(key);
        }
        
        if (keys.includes('Ctrl')) {
            return ctrl && !shift && keys.includes(key);
        }
        
        return false;
    }
    
    /**
     * Check if user is typing in an input field
     * @param {HTMLElement} target - Event target
     * @returns {boolean} True if typing in input
     */
    isTypingInInput(target) {
        const inputTypes = ['INPUT', 'TEXTAREA', 'SELECT'];
        return inputTypes.includes(target.tagName) || target.contentEditable === 'true';
    }
    
    /**
     * Focus on text input
     */
    focusTextInput() {
        const textInput = document.getElementById('text-input');
        if (textInput) {
            // Show fallback input if hidden
            const fallbackInput = document.getElementById('fallback-input');
            if (fallbackInput && fallbackInput.style.display === 'none') {
                fallbackInput.style.display = 'flex';
            }
            
            textInput.focus();
            this.announceToScreenReader('Text input focused');
        }
    }
    
    /**
     * Clear shopping list with confirmation
     */
    clearListWithConfirmation() {
        if (this.app.listManager.getItems().length === 0) {
            this.showToast('info', 'List Empty', 'Your shopping list is already empty.');
            return;
        }
        
        if (confirm('Are you sure you want to clear your entire shopping list?')) {
            this.recordAction('clear_list', this.app.listManager.getItems());
            this.app.listManager.clearList();
            this.showToast('success', 'List Cleared', 'Your shopping list has been cleared.');
            this.announceToScreenReader('Shopping list cleared');
        }
    }
    
    /**
     * Focus on language selector
     */
    focusLanguageSelector() {
        const languageSelect = document.getElementById('language-select');
        if (languageSelect) {
            languageSelect.focus();
            this.announceToScreenReader('Language selector focused');
        }
    }
    
    /**
     * Add suggestion by number
     * @param {number} number - Suggestion number (1-5)
     */
    addSuggestionByNumber(number) {
        const suggestions = this.app.getCurrentSuggestions();
        if (!suggestions || suggestions.length === 0) {
            this.showToast('warning', 'No Suggestions', 'No suggestions are currently available.');
            return;
        }
        
        if (number < 1 || number > suggestions.length) {
            this.showToast('error', 'Invalid Number', `Please choose a number between 1 and ${suggestions.length}.`);
            return;
        }
        
        const suggestion = suggestions[number - 1];
        const itemName = typeof suggestion === 'string' ? suggestion : suggestion.itemName;
        
        try {
            this.recordAction('add_item', { name: itemName, quantity: '1' });
            this.app.listManager.addItem(itemName);
            this.showToast('success', 'Item Added', `Added "${itemName}" to your shopping list.`);
            this.announceToScreenReader(`Added ${itemName} to shopping list`);
            
            // Remove suggestion from display
            if (this.app.uiController) {
                this.app.uiController.removeSuggestionFromDisplay(itemName);
            }
        } catch (error) {
            this.showToast('error', 'Error', `Failed to add "${itemName}": ${error.message}`);
        }
    }
    
    /**
     * Remove last added item
     */
    removeLastItem() {
        const items = this.app.listManager.getItems();
        if (items.length === 0) {
            this.showToast('info', 'List Empty', 'Your shopping list is empty.');
            return;
        }
        
        // Get the most recently added item
        const lastItem = items.reduce((latest, item) => {
            return new Date(item.dateAdded) > new Date(latest.dateAdded) ? item : latest;
        });
        
        this.recordAction('remove_item', lastItem);
        this.app.listManager.removeItem(lastItem.name);
        this.showToast('success', 'Item Removed', `Removed "${lastItem.name}" from your shopping list.`);
        this.announceToScreenReader(`Removed ${lastItem.name} from shopping list`);
    }
    
    /**
     * Undo last action
     */
    undoLastAction() {
        if (this.actionHistory.length === 0) {
            this.showToast('info', 'Nothing to Undo', 'No actions to undo.');
            return;
        }
        
        const lastAction = this.actionHistory.pop();
        
        try {
            switch (lastAction.type) {
                case 'add_item':
                    this.app.listManager.removeItem(lastAction.data.name);
                    this.showToast('success', 'Undone', `Removed "${lastAction.data.name}" from your list.`);
                    break;
                case 'remove_item':
                    this.app.listManager.addItem(lastAction.data.name, lastAction.data.quantity);
                    this.showToast('success', 'Undone', `Added "${lastAction.data.name}" back to your list.`);
                    break;
                case 'clear_list':
                    lastAction.data.forEach(item => {
                        this.app.listManager.addItem(item.name, item.quantity);
                    });
                    this.showToast('success', 'Undone', 'Restored your shopping list.');
                    break;
            }
            
            this.announceToScreenReader('Last action undone');
        } catch (error) {
            this.showToast('error', 'Undo Failed', `Failed to undo action: ${error.message}`);
        }
    }
    
    /**
     * Record an action for undo functionality
     * @param {string} type - Action type
     * @param {*} data - Action data
     */
    recordAction(type, data) {
        this.actionHistory.push({
            type,
            data: JSON.parse(JSON.stringify(data)), // Deep clone
            timestamp: new Date()
        });
        
        // Limit history size
        if (this.actionHistory.length > this.maxHistorySize) {
            this.actionHistory.shift();
        }
    }
    
    /**
     * Restart tutorial
     */
    restartTutorial() {
        if (window.onboardingManager) {
            window.onboardingManager.restart();
        } else {
            this.showToast('warning', 'Tutorial Unavailable', 'Onboarding tutorial is not available.');
        }
    }
    
    /**
     * Toggle keyboard shortcuts help
     */
    toggleHelp() {
        this.isHelpVisible = !this.isHelpVisible;
        const helpModal = document.getElementById('keyboard-shortcuts-help');
        
        if (this.isHelpVisible) {
            helpModal.classList.add('show');
            this.announceToScreenReader('Keyboard shortcuts help opened');
        } else {
            helpModal.classList.remove('show');
            this.announceToScreenReader('Keyboard shortcuts help closed');
        }
    }
    
    /**
     * Create keyboard shortcuts help modal
     */
    createHelpModal() {
        const modal = document.createElement('div');
        modal.id = 'keyboard-shortcuts-help';
        modal.className = 'keyboard-shortcuts-help';
        
        modal.innerHTML = `
            <div class="shortcuts-header">
                <h2 class="shortcuts-title">⌨️ Keyboard Shortcuts</h2>
                <button class="shortcuts-close" onclick="window.keyboardManager.toggleHelp()">×</button>
            </div>
            <div class="shortcuts-list">
                ${this.shortcuts.map(shortcut => `
                    <div class="shortcut-item">
                        <span class="shortcut-description">${shortcut.description}</span>
                        <div class="shortcut-keys">
                            ${shortcut.keys.map(key => `
                                <span class="shortcut-key">${this.formatKey(key)}</span>
                            `).join('')}
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Close on escape key
        modal.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.toggleHelp();
            }
        });
        
        // Close on outside click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                this.toggleHelp();
            }
        });
    }
    
    /**
     * Format key name for display
     * @param {string} key - Key name
     * @returns {string} Formatted key name
     */
    formatKey(key) {
        const keyMap = {
            'Ctrl': '⌃',
            'Shift': '⇧',
            'Alt': '⌥',
            'Space': '␣',
            'Enter': '↵',
            'Escape': '⎋',
            'Delete': '⌫'
        };
        
        return keyMap[key] || key;
    }
    
    /**
     * Add keyboard navigation class to body
     */
    addKeyboardNavigationClass() {
        // Add class when tab is used
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                document.body.classList.add('keyboard-navigation');
            }
        });
        
        // Remove class when mouse is used
        document.addEventListener('mousedown', () => {
            document.body.classList.remove('keyboard-navigation');
        });
    }
    
    /**
     * Provide audio feedback for shortcuts
     * @param {string} description - Shortcut description
     */
    provideShortcutFeedback(description) {
        if (this.app.speechSynthesizer && this.app.speechSynthesizer.isSupported) {
            // Only provide feedback for voice-related shortcuts to avoid spam
            if (description.includes('voice') || description.includes('recording')) {
                this.app.speechSynthesizer.speak(description);
            }
        }
    }
    
    /**
     * Show toast notification
     * @param {string} type - Toast type
     * @param {string} title - Toast title
     * @param {string} message - Toast message
     */
    showToast(type, title, message) {
        if (window.onboardingManager) {
            const toast = window.onboardingManager.createToast(type, title, message);
            window.onboardingManager.showToast(toast);
        }
    }
    
    /**
     * Announce to screen readers
     * @param {string} message - Message to announce
     */
    announceToScreenReader(message) {
        const announcement = document.getElementById('sr-announcements');
        if (announcement) {
            announcement.textContent = message;
        }
    }
}

// Make keyboard manager globally available
window.keyboardManager = null;