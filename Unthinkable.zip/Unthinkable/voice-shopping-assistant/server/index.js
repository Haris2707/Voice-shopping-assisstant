// server/index.js
const express = require('express');
const cors = require('cors');
const path = require('path');
const { Low } = require('lowdb');
const { JSONFile } = require('lowdb/node'); // correct path for CommonJS

const { nanoid } = require('nanoid');
const { parseCommand, SUBSTITUTES } = require('./utils_nlp');

const app = express();
app.use(express.json());
app.use(cors());

const file = path.join(__dirname, 'db.json');
const adapter = new JSONFile(file);
const db = new Low(adapter, { products: [], users: [] });

async function initDB() {
  await db.read();
  db.data = db.data || { items: [], history: [] };
  await db.write();
}
initDB();

app.get('/api/items', async (req, res) => {
  await db.read();
  res.json(db.data.items);
});

app.post('/api/items', async (req, res) => {
  await db.read();
  const { name, qty = 1, category = 'other', note = '' } = req.body;
  const item = { id: nanoid(8), name, qty, category, note, createdAt: Date.now() };
  db.data.items.push(item);
  db.data.history.push({ type: 'add', name, at: Date.now() });
  await db.write();
  res.json(item);
});

app.put('/api/items/:id', async (req, res) => {
  await db.read();
  const id = req.params.id;
  const it = db.data.items.find(i => i.id === id);
  if (!it) return res.status(404).json({ error: 'not found' });
  Object.assign(it, req.body);
  await db.write();
  res.json(it);
});

app.delete('/api/items/:id', async (req, res) => {
  await db.read();
  const id = req.params.id;
  db.data.items = db.data.items.filter(i => i.id !== id);
  await db.write();
  res.json({ success: true });
});

app.post('/api/parse', async (req, res) => {
  const { text } = req.body;
  const parsed = parseCommand(text || '');
  res.json(parsed);
});

app.get('/api/suggestions', async (req, res) => {
  await db.read();
  const freq = {};
  for (const h of db.data.history) {
    if (h.type === 'add') {
      const n = h.name.toLowerCase();
      freq[n] = (freq[n] || 0) + 1;
    }
  }
  const top = Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,6).map(x=>x[0]);
  const seasonal = ['mango', 'watermelon', 'tomato', 'cucumber'];
  const suggestions = [...new Set([...top, ...seasonal, ...Object.keys(SUBSTITUTES)])].slice(0,8);
  res.json({ suggestions });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log(`Server running on http://localhost:${PORT}`));
