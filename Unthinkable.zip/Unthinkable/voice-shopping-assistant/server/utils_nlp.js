// server/utils_nlp.js
const CATEGORIES = {
  dairy: ['milk', 'cheese', 'butter', 'yogurt'],
  produce: ['apple', 'banana', 'orange', 'tomato', 'onion', 'garlic'],
  drinks: ['water', 'juice', 'soda', 'tea', 'coffee'],
  bakery: ['bread', 'bagel', 'bun'],
  snacks: ['chips', 'chocolate', 'cookies'],
};

const SUBSTITUTES = {
  milk: ['almond milk', 'soy milk', 'oat milk'],
  bread: ['baguette', 'wrap'],
  sugar: ['honey', 'maple syrup']
};

function detectQuantity(text) {
  const qMatch = text.match(/(\d+)\s*(kg|g|liters?|bottles?|pcs|pieces|packs?)?/i);
  if (qMatch) return qMatch[1];
  const words = { one:1,two:2,three:3,four:4,five:5 };
  for (const w in words) {
    if (new RegExp(`\\b${w}\\b`).test(text)) return words[w];
  }
  return 1;
}

function categorizeItem(name) {
  name = name.toLowerCase();
  for (const [cat, arr] of Object.entries(CATEGORIES)) {
    for (const kw of arr) if (name.includes(kw)) return cat;
  }
  return 'other';
}

function parseCommand(text) {
  text = text.toLowerCase().trim();
  const result = { action: null, item: null, qty: 1, raw: text, filters: {} };

  if (/^\s*(add|i need|i want|buy|please add)\b/.test(text)) {
    result.action = 'add';
    result.qty = detectQuantity(text);
    const cleaned = text.replace(/(add|i need|i want to buy|i want|please add|buy)/i, '')
                        .replace(/\b(to my list|to the list|please)\b/ig, '')
                        .replace(/(\d+\s*(kg|g|liters?|bottles?|pcs|pieces|packs?))/i, '')
                        .replace(/\b(of|some|a|an)\b/ig, '')
                        .trim();
    result.item = cleaned;
    result.category = categorizeItem(cleaned);
    return result;
  }

  if (/^\s*(remove|delete)\b/.test(text)) {
    result.action = 'remove';
    result.item = text.replace(/(remove|delete|from)\b/ig, '').trim();
    return result;
  }

  if (/^\s*(find|search|show me|show)\b/.test(text)) {
    result.action = 'search';
    const priceMatch = text.match(/under\s*\$?(\d+)/);
    if (priceMatch) result.filters.priceMax = Number(priceMatch[1]);
    result.item = text.replace(/(find|search for|show me|show)/ig, '').trim();
    return result;
  }

  const maybeAdd = text.match(/\b(milk|bread|apple|banana|water|eggs|cheese|toothpaste|soap|rice|sugar|coffee)\b/i);
  if (maybeAdd) {
    result.action = 'add';
    result.qty = detectQuantity(text);
    result.item = text;
    result.category = categorizeItem(text);
    return result;
  }

  result.action = 'unknown';
  return result;
}

module.exports = { parseCommand, categorizeItem, SUBSTITUTES };
