/**
 * SpeechSynthesizer - Handles speech synthesis for audio feedback
 * Provides voice confirmations, error announcements, and user guidance
 */

export class SpeechSynthesizer {
    constructor(language = 'en-US') {
        this.isSupported = false;
        this.voices = [];
        this.currentVoice = null;
        this.currentLanguage = language;
        this.settings = {
            rate: 1.0,
            pitch: 1.0,
            volume: 0.8,
            language: language
        };
        
        this.init();
    }
    
    /**
     * Initialize the speech synthesizer
     */
    init() {
        console.log('Initializing SpeechSynthesizer...');
        
        // Check browser support
        if ('speechSynthesis' in window) {
            this.isSupported = true;
            this.loadVoices();
            
            // Listen for voices changed event (some browsers load voices asynchronously)
            if (speechSynthesis.onvoiceschanged !== undefined) {
                speechSynthesis.onvoiceschanged = () => {
                    this.loadVoices();
                };
            }
            
            console.log('Speech synthesis supported');
        } else {
            console.warn('Speech synthesis not supported in this browser');
            this.isSupported = false;
        }
    }
    
    /**
     * Load available voices
     */
    loadVoices() {
        this.voices = speechSynthesis.getVoices();
        
        if (this.voices.length > 0) {
            // Try to find a voice that matches the current language
            this.currentVoice = this.findBestVoice(this.settings.language);
            console.log(`Loaded ${this.voices.length} voices, selected:`, this.currentVoice?.name || 'default');
        }
    }
    
    /**
     * Find the best voice for a given language
     * @param {string} language - Language code (e.g., 'en-US')
     * @returns {SpeechSynthesisVoice|null} Best matching voice
     */
    findBestVoice(language) {
        if (!this.voices.length) return null;
        
        // First, try to find exact language match
        let voice = this.voices.find(v => v.lang === language);
        
        // If no exact match, try language prefix (e.g., 'en' for 'en-US')
        if (!voice) {
            const langPrefix = language.split('-')[0];
            voice = this.voices.find(v => v.lang.startsWith(langPrefix));
        }
        
        // If still no match, try to find any English voice as fallback
        if (!voice && !language.startsWith('en')) {
            voice = this.voices.find(v => v.lang.startsWith('en'));
        }
        
        // If still no match, use the first available voice
        if (!voice) {
            voice = this.voices[0];
        }
        
        return voice;
    }
    
    /**
     * Speak text with audio feedback
     * @param {string} text - Text to speak
     * @param {Object} options - Speech options
     * @returns {Promise<boolean>} Promise that resolves when speech completes
     */
    speak(text, options = {}) {
        return new Promise((resolve, reject) => {
            if (!this.isSupported) {
                console.warn('Speech synthesis not supported');
                resolve(false);
                return;
            }
            
            if (!text || text.trim() === '') {
                console.warn('No text provided for speech synthesis');
                resolve(false);
                return;
            }
            
            // Cancel any ongoing speech
            speechSynthesis.cancel();
            
            // Create speech synthesis utterance
            const utterance = new SpeechSynthesisUtterance(text.trim());
            
            // Apply settings
            utterance.rate = options.rate || this.settings.rate;
            utterance.pitch = options.pitch || this.settings.pitch;
            utterance.volume = options.volume || this.settings.volume;
            utterance.voice = options.voice || this.currentVoice;
            
            // Set up event handlers
            utterance.onstart = () => {
                console.log('Speech started:', text);
            };
            
            utterance.onend = () => {
                console.log('Speech ended:', text);
                resolve(true);
            };
            
            utterance.onerror = (event) => {
                console.error('Speech synthesis error:', event.error);
                reject(new Error(`Speech synthesis failed: ${event.error}`));
            };
            
            utterance.onpause = () => {
                console.log('Speech paused');
            };
            
            utterance.onresume = () => {
                console.log('Speech resumed');
            };
            
            // Speak the text
            try {
                speechSynthesis.speak(utterance);
            } catch (error) {
                console.error('Error starting speech synthesis:', error);
                reject(error);
            }
        });
    }
    
    /**
     * Provide audio confirmation for successful actions
     * @param {string} action - Action that was performed
     * @param {string} item - Item that was affected (optional)
     * @param {string} quantity - Quantity that was affected (optional)
     */
    async confirmAction(action, item = '', quantity = '') {
        let message = '';
        
        switch (action.toLowerCase()) {
            case 'add':
            case 'added':
                if (quantity && quantity !== '1') {
                    message = this.getLocalizedMessage('addedWithQuantity', { quantity, item });
                } else {
                    message = this.getLocalizedMessage('added', { item });
                }
                break;
            case 'remove':
            case 'removed':
                message = this.getLocalizedMessage('removed', { item });
                break;
            case 'update':
            case 'updated':
                message = this.getLocalizedMessage('updated', { item, quantity });
                break;
            case 'complete':
            case 'completed':
                message = this.getLocalizedMessage('completed', { item });
                break;
            case 'clear':
            case 'cleared':
                message = this.getLocalizedMessage('cleared');
                break;
            default:
                message = `${action} completed`;
        }
        
        try {
            await this.speak(message, { rate: 1.1 });
            return true;
        } catch (error) {
            console.error('Error providing audio confirmation:', error);
            return false;
        }
    }
    
    /**
     * Announce error messages via voice
     * @param {string} errorType - Type of error
     * @param {string} details - Error details (optional)
     */
    async announceError(errorType, details = '') {
        let message = '';
        
        switch (errorType.toLowerCase()) {
            case 'not_found':
                message = this.getLocalizedMessage('notFound') + (details ? ` ${details}` : '');
                break;
            case 'already_exists':
                message = this.getLocalizedMessage('alreadyExists') + (details ? ` ${details}` : '');
                break;
            case 'invalid_command':
                message = this.getLocalizedMessage('invalidCommand') + (details ? ` ${details}` : '');
                break;
            case 'voice_error':
                message = this.getLocalizedMessage('voiceError') + (details ? ` ${details}` : '');
                break;
            case 'permission_denied':
                message = this.getLocalizedMessage('permissionDenied');
                break;
            case 'browser_not_supported':
                message = this.getLocalizedMessage('browserNotSupported');
                break;
            case 'network_error':
                message = this.getLocalizedMessage('networkError');
                break;
            default:
                message = `Error: ${details || errorType}`;
        }
        
        try {
            await this.speak(message, { rate: 0.9, pitch: 0.9 });
            return true;
        } catch (error) {
            console.error('Error announcing error:', error);
            return false;
        }
    }
    
    /**
     * Provide voice prompts for user guidance
     * @param {string} promptType - Type of prompt
     * @param {Object} context - Additional context for the prompt
     */
    async provideGuidance(promptType, context = {}) {
        let message = '';
        
        switch (promptType.toLowerCase()) {
            case 'welcome':
                message = this.getLocalizedMessage('welcome');
                break;
            case 'listening':
                message = this.getLocalizedMessage('listening');
                break;
            case 'repeat':
                message = this.getLocalizedMessage('repeat');
                break;
            case 'help':
                message = this.getLocalizedMessage('help');
                break;
            case 'empty_list':
                message = this.getLocalizedMessage('emptyList');
                break;
            case 'list_summary':
                const itemCount = context.itemCount || 0;
                if (itemCount === 0) {
                    message = this.getLocalizedMessage('listSummaryEmpty');
                } else if (itemCount === 1) {
                    message = this.getLocalizedMessage('listSummarySingle');
                } else {
                    message = this.getLocalizedMessage('listSummaryMultiple', { count: itemCount });
                }
                break;
            case 'suggestions':
                message = this.getLocalizedMessage('suggestions');
                break;
            case 'command_examples':
                message = this.getLocalizedMessage('commandExamples');
                break;
            default:
                message = context.message || 'How can I help you with your shopping list?';
        }
        
        try {
            await this.speak(message, { rate: 1.0 });
            return true;
        } catch (error) {
            console.error('Error providing guidance:', error);
            return false;
        }
    }
    
    /**
     * Read the shopping list aloud
     * @param {Array} items - Array of shopping list items
     */
    async readShoppingList(items) {
        if (!items || items.length === 0) {
            await this.provideGuidance('empty_list');
            return;
        }
        
        let message = '';
        
        if (items.length === 1) {
            const item = items[0];
            message = `You have ${item.quantity} ${item.name} on your shopping list.`;
        } else {
            message = `You have ${items.length} items on your shopping list: `;
            
            const itemDescriptions = items.map(item => {
                if (item.quantity && item.quantity !== '1') {
                    return `${item.quantity} ${item.name}`;
                } else {
                    return item.name;
                }
            });
            
            // Join items with commas and "and" before the last item
            if (itemDescriptions.length > 1) {
                const lastItem = itemDescriptions.pop();
                message += itemDescriptions.join(', ') + ', and ' + lastItem;
            } else {
                message += itemDescriptions[0];
            }
        }
        
        try {
            await this.speak(message, { rate: 0.95 });
            return true;
        } catch (error) {
            console.error('Error reading shopping list:', error);
            return false;
        }
    }
    
    /**
     * Stop any ongoing speech
     */
    stop() {
        if (this.isSupported) {
            speechSynthesis.cancel();
            console.log('Speech synthesis stopped');
        }
    }
    
    /**
     * Pause ongoing speech
     */
    pause() {
        if (this.isSupported) {
            speechSynthesis.pause();
            console.log('Speech synthesis paused');
        }
    }
    
    /**
     * Resume paused speech
     */
    resume() {
        if (this.isSupported) {
            speechSynthesis.resume();
            console.log('Speech synthesis resumed');
        }
    }
    
    /**
     * Check if speech synthesis is currently speaking
     * @returns {boolean} True if speaking
     */
    isSpeaking() {
        return this.isSupported && speechSynthesis.speaking;
    }
    
    /**
     * Check if speech synthesis is paused
     * @returns {boolean} True if paused
     */
    isPaused() {
        return this.isSupported && speechSynthesis.paused;
    }
    
    /**
     * Get available voices
     * @returns {Array} Array of available voices
     */
    getAvailableVoices() {
        return this.voices;
    }
    
    /**
     * Set the voice to use for speech synthesis
     * @param {SpeechSynthesisVoice|string} voice - Voice object or voice name
     */
    setVoice(voice) {
        if (typeof voice === 'string') {
            // Find voice by name
            const foundVoice = this.voices.find(v => v.name === voice);
            if (foundVoice) {
                this.currentVoice = foundVoice;
                console.log('Voice set to:', foundVoice.name);
            } else {
                console.warn('Voice not found:', voice);
            }
        } else if (voice && voice.name) {
            this.currentVoice = voice;
            console.log('Voice set to:', voice.name);
        }
    }
    
    /**
     * Set speech synthesis settings
     * @param {Object} settings - Settings object
     */
    setSettings(settings) {
        if (settings.rate !== undefined) {
            this.settings.rate = Math.max(0.1, Math.min(10, settings.rate));
        }
        if (settings.pitch !== undefined) {
            this.settings.pitch = Math.max(0, Math.min(2, settings.pitch));
        }
        if (settings.volume !== undefined) {
            this.settings.volume = Math.max(0, Math.min(1, settings.volume));
        }
        if (settings.language !== undefined) {
            this.settings.language = settings.language;
            this.currentVoice = this.findBestVoice(settings.language);
        }
        
        console.log('Speech settings updated:', this.settings);
    }
    
    /**
     * Set the language for speech synthesis
     * @param {string} language - Language code
     */
    setLanguage(language) {
        this.currentLanguage = language;
        this.settings.language = language;
        this.currentVoice = this.findBestVoice(language);
        console.log(`SpeechSynthesizer language set to: ${language}`);
    }
    
    /**
     * Get multilingual messages
     * @param {string} messageKey - Message key
     * @param {Object} params - Parameters for the message
     * @returns {string} Localized message
     */
    getLocalizedMessage(messageKey, params = {}) {
        const langCode = this.currentLanguage.split('-')[0];
        const messages = this.getLanguageMessages(langCode);
        
        let message = messages[messageKey] || this.getLanguageMessages('en')[messageKey] || messageKey;
        
        // Replace parameters in the message
        Object.keys(params).forEach(key => {
            message = message.replace(`{${key}}`, params[key]);
        });
        
        return message;
    }
    
    /**
     * Get language-specific messages
     * @param {string} langCode - Language code
     * @returns {Object} Messages object
     */
    getLanguageMessages(langCode) {
        const messages = {
            en: {
                added: 'Added {item} to your shopping list',
                addedWithQuantity: 'Added {quantity} {item} to your shopping list',
                removed: 'Removed {item} from your shopping list',
                updated: 'Updated {item} quantity to {quantity}',
                completed: 'Marked {item} as completed',
                cleared: 'Shopping list cleared',
                notFound: 'Item not found in your shopping list',
                alreadyExists: 'Item already exists in your shopping list',
                invalidCommand: 'I didn\'t understand that command',
                voiceError: 'Voice recognition error',
                permissionDenied: 'Microphone access denied. Please enable microphone permissions to use voice commands.',
                browserNotSupported: 'Voice features are not supported in this browser. Please use the text input instead.',
                networkError: 'Network error occurred. Please check your connection and try again.',
                welcome: 'Welcome to your voice shopping assistant. Say "add milk" or "buy 2 apples" to get started.',
                listening: 'I\'m listening. What would you like to add to your shopping list?',
                repeat: 'I didn\'t catch that. Please repeat your command.',
                help: 'You can say things like "add milk", "buy 2 apples", "remove bread", or "clear my list". What would you like to do?',
                emptyList: 'Your shopping list is empty. Try adding some items by saying "add" followed by the item name.',
                listSummaryEmpty: 'Your shopping list is empty.',
                listSummarySingle: 'You have 1 item in your shopping list.',
                listSummaryMultiple: 'You have {count} items in your shopping list.',
                suggestions: 'Here are some suggestions you might want to add to your list.',
                commandExamples: 'Try saying "add milk", "buy 2 bananas", "remove bread", or "what\'s on my list".'
            },
            es: {
                added: 'Agregué {item} a tu lista de compras',
                addedWithQuantity: 'Agregué {quantity} {item} a tu lista de compras',
                removed: 'Eliminé {item} de tu lista de compras',
                updated: 'Actualicé la cantidad de {item} a {quantity}',
                completed: 'Marqué {item} como completado',
                cleared: 'Lista de compras limpiada',
                notFound: 'Artículo no encontrado en tu lista de compras',
                alreadyExists: 'El artículo ya existe en tu lista de compras',
                invalidCommand: 'No entendí ese comando',
                voiceError: 'Error de reconocimiento de voz',
                permissionDenied: 'Acceso al micrófono denegado. Por favor habilita los permisos del micrófono para usar comandos de voz.',
                browserNotSupported: 'Las funciones de voz no son compatibles con este navegador. Por favor usa la entrada de texto.',
                networkError: 'Ocurrió un error de red. Por favor verifica tu conexión e intenta de nuevo.',
                welcome: 'Bienvenido a tu asistente de compras por voz. Di "añadir leche" o "comprar 2 manzanas" para comenzar.',
                listening: 'Estoy escuchando. ¿Qué te gustaría añadir a tu lista de compras?',
                repeat: 'No escuché eso. Por favor repite tu comando.',
                help: 'Puedes decir cosas como "añadir leche", "comprar 2 manzanas", "quitar pan", o "limpiar mi lista". ¿Qué te gustaría hacer?',
                emptyList: 'Tu lista de compras está vacía. Intenta añadir algunos artículos diciendo "añadir" seguido del nombre del artículo.',
                listSummaryEmpty: 'Tu lista de compras está vacía.',
                listSummarySingle: 'Tienes 1 artículo en tu lista de compras.',
                listSummaryMultiple: 'Tienes {count} artículos en tu lista de compras.',
                suggestions: 'Aquí tienes algunas sugerencias que podrías querer añadir a tu lista.',
                commandExamples: 'Intenta decir "añadir leche", "comprar 2 plátanos", "quitar pan", o "qué hay en mi lista".'
            },
            fr: {
                added: 'J\'ai ajouté {item} à votre liste de courses',
                addedWithQuantity: 'J\'ai ajouté {quantity} {item} à votre liste de courses',
                removed: 'J\'ai supprimé {item} de votre liste de courses',
                updated: 'J\'ai mis à jour la quantité de {item} à {quantity}',
                completed: 'J\'ai marqué {item} comme terminé',
                cleared: 'Liste de courses vidée',
                notFound: 'Article non trouvé dans votre liste de courses',
                alreadyExists: 'L\'article existe déjà dans votre liste de courses',
                invalidCommand: 'Je n\'ai pas compris cette commande',
                voiceError: 'Erreur de reconnaissance vocale',
                permissionDenied: 'Accès au microphone refusé. Veuillez activer les permissions du microphone pour utiliser les commandes vocales.',
                browserNotSupported: 'Les fonctionnalités vocales ne sont pas prises en charge dans ce navigateur. Veuillez utiliser la saisie de texte.',
                networkError: 'Une erreur réseau s\'est produite. Veuillez vérifier votre connexion et réessayer.',
                welcome: 'Bienvenue dans votre assistant de courses vocal. Dites "ajouter du lait" ou "acheter 2 pommes" pour commencer.',
                listening: 'J\'écoute. Que souhaitez-vous ajouter à votre liste de courses?',
                repeat: 'Je n\'ai pas saisi cela. Veuillez répéter votre commande.',
                help: 'Vous pouvez dire des choses comme "ajouter du lait", "acheter 2 pommes", "supprimer du pain", ou "vider ma liste". Que souhaitez-vous faire?',
                emptyList: 'Votre liste de courses est vide. Essayez d\'ajouter des articles en disant "ajouter" suivi du nom de l\'article.',
                listSummaryEmpty: 'Votre liste de courses est vide.',
                listSummarySingle: 'Vous avez 1 article dans votre liste de courses.',
                listSummaryMultiple: 'Vous avez {count} articles dans votre liste de courses.',
                suggestions: 'Voici quelques suggestions que vous pourriez vouloir ajouter à votre liste.',
                commandExamples: 'Essayez de dire "ajouter du lait", "acheter 2 bananes", "supprimer du pain", ou "qu\'est-ce qui est sur ma liste".'
            },
            de: {
                added: 'Ich habe {item} zu Ihrer Einkaufsliste hinzugefügt',
                addedWithQuantity: 'Ich habe {quantity} {item} zu Ihrer Einkaufsliste hinzugefügt',
                removed: 'Ich habe {item} von Ihrer Einkaufsliste entfernt',
                updated: 'Ich habe die Menge von {item} auf {quantity} aktualisiert',
                completed: 'Ich habe {item} als erledigt markiert',
                cleared: 'Einkaufsliste geleert',
                notFound: 'Artikel nicht in Ihrer Einkaufsliste gefunden',
                alreadyExists: 'Artikel existiert bereits in Ihrer Einkaufsliste',
                invalidCommand: 'Ich habe diesen Befehl nicht verstanden',
                voiceError: 'Spracherkennungsfehler',
                permissionDenied: 'Mikrofonzugriff verweigert. Bitte aktivieren Sie die Mikrofonberechtigungen, um Sprachbefehle zu verwenden.',
                browserNotSupported: 'Sprachfunktionen werden in diesem Browser nicht unterstützt. Bitte verwenden Sie die Texteingabe.',
                networkError: 'Ein Netzwerkfehler ist aufgetreten. Bitte überprüfen Sie Ihre Verbindung und versuchen Sie es erneut.',
                welcome: 'Willkommen bei Ihrem Sprach-Einkaufsassistenten. Sagen Sie "Milch hinzufügen" oder "2 Äpfel kaufen", um zu beginnen.',
                listening: 'Ich höre zu. Was möchten Sie zu Ihrer Einkaufsliste hinzufügen?',
                repeat: 'Das habe ich nicht verstanden. Bitte wiederholen Sie Ihren Befehl.',
                help: 'Sie können Dinge sagen wie "Milch hinzufügen", "2 Äpfel kaufen", "Brot entfernen" oder "meine Liste leeren". Was möchten Sie tun?',
                emptyList: 'Ihre Einkaufsliste ist leer. Versuchen Sie, Artikel hinzuzufügen, indem Sie "hinzufügen" gefolgt vom Artikelnamen sagen.',
                listSummaryEmpty: 'Ihre Einkaufsliste ist leer.',
                listSummarySingle: 'Sie haben 1 Artikel in Ihrer Einkaufsliste.',
                listSummaryMultiple: 'Sie haben {count} Artikel in Ihrer Einkaufsliste.',
                suggestions: 'Hier sind einige Vorschläge, die Sie zu Ihrer Liste hinzufügen möchten.',
                commandExamples: 'Versuchen Sie zu sagen "Milch hinzufügen", "2 Bananen kaufen", "Brot entfernen" oder "was ist auf meiner Liste".'
            }
        };
        
        return messages[langCode] || messages.en;
    }
    
    /**
     * Get current speech synthesis settings
     * @returns {Object} Current settings
     */
    getSettings() {
        return { ...this.settings };
    }
    
    /**
     * Check if speech synthesis is supported
     * @returns {boolean} True if supported
     */
    isSupported() {
        return this.isSupported;
    }
    
    /**
     * Test speech synthesis with a sample message
     */
    async test() {
        if (!this.isSupported) {
            console.warn('Speech synthesis not supported - cannot test');
            return false;
        }
        
        try {
            await this.speak('Speech synthesis is working correctly.');
            return true;
        } catch (error) {
            console.error('Speech synthesis test failed:', error);
            return false;
        }
    }
}