/**
 * ProductDatabase - Manages product data and search functionality
 * Provides product information, pricing, and search capabilities
 */

export class ProductDatabase {
    constructor() {
        this.products = this.initializeProducts();
        this.categories = this.initializeCategories();
    }
    
    /**
     * Initialize product database with sample products
     * @returns {Array} Array of product objects
     */
    initializeProducts() {
        return [
            // Dairy Products
            { id: 1, name: 'milk', category: 'dairy', brand: 'generic', type: 'whole', price: 3.99, organic: false },
            { id: 2, name: 'milk', category: 'dairy', brand: 'organic valley', type: 'whole', price: 5.99, organic: true },
            { id: 3, name: 'milk', category: 'dairy', brand: 'lactaid', type: 'lactose-free', price: 4.99, organic: false },
            { id: 4, name: 'almond milk', category: 'dairy', brand: 'almond breeze', type: 'unsweetened', price: 3.49, organic: false },
            { id: 5, name: 'soy milk', category: 'dairy', brand: 'silk', type: 'vanilla', price: 3.79, organic: false },
            { id: 6, name: 'oat milk', category: 'dairy', brand: 'oatly', type: 'original', price: 4.29, organic: false },
            { id: 7, name: 'cheese', category: 'dairy', brand: 'kraft', type: 'cheddar', price: 4.99, organic: false },
            { id: 8, name: 'cheese', category: 'dairy', brand: 'organic valley', type: 'cheddar', price: 6.99, organic: true },
            { id: 9, name: 'yogurt', category: 'dairy', brand: 'chobani', type: 'greek', price: 1.29, organic: false },
            { id: 10, name: 'butter', category: 'dairy', brand: 'land o lakes', type: 'salted', price: 4.49, organic: false },
            
            // Produce
            { id: 11, name: 'apples', category: 'produce', brand: 'generic', type: 'gala', price: 1.99, organic: false },
            { id: 12, name: 'apples', category: 'produce', brand: 'organic', type: 'gala', price: 2.99, organic: true },
            { id: 13, name: 'bananas', category: 'produce', brand: 'generic', type: 'yellow', price: 0.68, organic: false },
            { id: 14, name: 'bananas', category: 'produce', brand: 'organic', type: 'yellow', price: 0.98, organic: true },
            { id: 15, name: 'carrots', category: 'produce', brand: 'generic', type: 'baby', price: 1.49, organic: false },
            { id: 16, name: 'lettuce', category: 'produce', brand: 'generic', type: 'romaine', price: 2.49, organic: false },
            { id: 17, name: 'tomatoes', category: 'produce', brand: 'generic', type: 'roma', price: 2.99, organic: false },
            { id: 18, name: 'onions', category: 'produce', brand: 'generic', type: 'yellow', price: 1.99, organic: false },
            
            // Meat
            { id: 19, name: 'chicken', category: 'meat', brand: 'perdue', type: 'breast', price: 5.99, organic: false },
            { id: 20, name: 'chicken', category: 'meat', brand: 'organic', type: 'breast', price: 8.99, organic: true },
            { id: 21, name: 'beef', category: 'meat', brand: 'generic', type: 'ground', price: 4.99, organic: false },
            { id: 22, name: 'pork', category: 'meat', brand: 'generic', type: 'chops', price: 6.99, organic: false },
            { id: 23, name: 'fish', category: 'meat', brand: 'generic', type: 'salmon', price: 9.99, organic: false },
            
            // Pantry
            { id: 24, name: 'rice', category: 'pantry', brand: 'uncle bens', type: 'white', price: 2.99, organic: false },
            { id: 25, name: 'pasta', category: 'pantry', brand: 'barilla', type: 'spaghetti', price: 1.99, organic: false },
            { id: 26, name: 'flour', category: 'pantry', brand: 'king arthur', type: 'all-purpose', price: 3.49, organic: false },
            { id: 27, name: 'sugar', category: 'pantry', brand: 'domino', type: 'white', price: 2.49, organic: false },
            { id: 28, name: 'olive oil', category: 'pantry', brand: 'bertolli', type: 'extra virgin', price: 6.99, organic: false },
            
            // Snacks
            { id: 29, name: 'chips', category: 'snacks', brand: 'lays', type: 'classic', price: 3.99, organic: false },
            { id: 30, name: 'cookies', category: 'snacks', brand: 'oreo', type: 'original', price: 4.49, organic: false },
            { id: 31, name: 'crackers', category: 'snacks', brand: 'ritz', type: 'original', price: 3.29, organic: false },
            
            // Beverages
            { id: 32, name: 'water', category: 'beverages', brand: 'dasani', type: 'bottled', price: 4.99, organic: false },
            { id: 33, name: 'juice', category: 'beverages', brand: 'tropicana', type: 'orange', price: 3.99, organic: false },
            { id: 34, name: 'soda', category: 'beverages', brand: 'coca cola', type: 'classic', price: 5.99, organic: false },
            { id: 35, name: 'coffee', category: 'beverages', brand: 'folgers', type: 'ground', price: 7.99, organic: false },
            { id: 36, name: 'tea', category: 'beverages', brand: 'lipton', type: 'green', price: 3.49, organic: false }
        ];
    }
    
    /**
     * Initialize category mappings
     * @returns {Object} Category mappings
     */
    initializeCategories() {
        return {
            'dairy': ['milk', 'cheese', 'yogurt', 'butter', 'cream', 'almond milk', 'soy milk', 'oat milk'],
            'produce': ['apples', 'bananas', 'carrots', 'lettuce', 'tomatoes', 'onions', 'potatoes', 'broccoli'],
            'meat': ['chicken', 'beef', 'pork', 'fish', 'turkey', 'lamb'],
            'pantry': ['rice', 'pasta', 'flour', 'sugar', 'salt', 'pepper', 'olive oil', 'vinegar'],
            'snacks': ['chips', 'cookies', 'crackers', 'nuts', 'candy'],
            'beverages': ['water', 'juice', 'soda', 'coffee', 'tea', 'beer', 'wine'],
            'miscellaneous': []
        };
    }
    
    /**
     * Search for products based on criteria
     * @param {Object} criteria - Search criteria object
     * @returns {Array} Array of matching products
     */
    searchProducts(criteria) {
        let results = [...this.products];
        
        // Filter by query (product name)
        if (criteria.query) {
            const query = criteria.query.toLowerCase().trim();
            results = results.filter(product => 
                product.name.toLowerCase().includes(query) ||
                product.type.toLowerCase().includes(query) ||
                product.brand.toLowerCase().includes(query)
            );
        }
        
        // Apply filters
        if (criteria.filters) {
            // Price filter
            if (criteria.filters.maxPrice) {
                results = results.filter(product => product.price <= criteria.filters.maxPrice);
            }
            
            if (criteria.filters.minPrice) {
                results = results.filter(product => product.price >= criteria.filters.minPrice);
            }
            
            // Type filter (organic, fresh, etc.)
            if (criteria.filters.type) {
                const type = criteria.filters.type.toLowerCase();
                results = results.filter(product => 
                    product.type.toLowerCase().includes(type) ||
                    (type === 'organic' && product.organic)
                );
            }
            
            // Brand filter
            if (criteria.filters.brand) {
                const brand = criteria.filters.brand.toLowerCase();
                results = results.filter(product => 
                    product.brand.toLowerCase().includes(brand)
                );
            }
            
            // Category filter
            if (criteria.filters.category) {
                const category = criteria.filters.category.toLowerCase();
                results = results.filter(product => 
                    product.category.toLowerCase() === category
                );
            }
        }
        
        // Sort results by relevance (exact name matches first, then by price)
        results.sort((a, b) => {
            if (criteria.query) {
                const query = criteria.query.toLowerCase();
                const aExact = a.name.toLowerCase() === query;
                const bExact = b.name.toLowerCase() === query;
                
                if (aExact && !bExact) return -1;
                if (!aExact && bExact) return 1;
            }
            
            // Sort by price (ascending)
            return a.price - b.price;
        });
        
        return results;
    }
    
    /**
     * Get product by ID
     * @param {number} id - Product ID
     * @returns {Object|null} Product object or null if not found
     */
    getProductById(id) {
        return this.products.find(product => product.id === id) || null;
    }
    
    /**
     * Get products by category
     * @param {string} category - Category name
     * @returns {Array} Array of products in the category
     */
    getProductsByCategory(category) {
        return this.products.filter(product => 
            product.category.toLowerCase() === category.toLowerCase()
        );
    }
    
    /**
     * Get all available brands for a product
     * @param {string} productName - Product name
     * @returns {Array} Array of available brands
     */
    getBrandsForProduct(productName) {
        const products = this.products.filter(product => 
            product.name.toLowerCase() === productName.toLowerCase()
        );
        
        return [...new Set(products.map(product => product.brand))];
    }
    
    /**
     * Get price range for a product
     * @param {string} productName - Product name
     * @returns {Object} Object with min and max prices
     */
    getPriceRangeForProduct(productName) {
        const products = this.products.filter(product => 
            product.name.toLowerCase() === productName.toLowerCase()
        );
        
        if (products.length === 0) {
            return { min: 0, max: 0 };
        }
        
        const prices = products.map(product => product.price);
        return {
            min: Math.min(...prices),
            max: Math.max(...prices)
        };
    }
}