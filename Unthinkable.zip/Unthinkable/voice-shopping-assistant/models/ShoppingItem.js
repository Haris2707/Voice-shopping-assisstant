/**
 * ShoppingItem - Data model for individual shopping list items
 * Handles item creation, validation, and serialization
 */

export class ShoppingItem {
    /**
     * Create a new shopping item
     * @param {string} name - The name of the item
     * @param {string} quantity - The quantity (e.g., "2", "1 gallon", "3 bottles")
     * @param {string} category - The category (e.g., "dairy", "produce")
     * @param {string} id - Optional unique identifier
     */
    constructor(name, quantity = "1", category = "miscellaneous", id = null) {
        this.id = id || this.generateId();
        this.name = this.sanitizeName(name);
        this.quantity = this.sanitizeQuantity(quantity);
        this.category = this.sanitizeCategory(category);
        this.dateAdded = new Date();
        this.completed = false;
        
        this.validate();
    }
    
    /**
     * Generate a unique ID for the item
     * @returns {string} Unique identifier
     */
    generateId() {
        return `item_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    
    /**
     * Sanitize and validate item name
     * @param {string} name - Raw item name
     * @returns {string} Sanitized name
     */
    sanitizeName(name) {
        if (typeof name !== 'string') {
            throw new Error('Item name must be a string');
        }
        
        // Remove extra whitespace and convert to lowercase for consistency
        const sanitized = name.trim().toLowerCase();
        
        if (sanitized.length === 0) {
            throw new Error('Item name cannot be empty');
        }
        
        if (sanitized.length > 100) {
            throw new Error('Item name cannot exceed 100 characters');
        }
        
        // Remove potentially harmful characters but keep basic punctuation
        return sanitized.replace(/[<>\"'&]/g, '');
    }
    
    /**
     * Sanitize and validate quantity
     * @param {string|number} quantity - Raw quantity
     * @returns {string} Sanitized quantity
     */
    sanitizeQuantity(quantity) {
        if (quantity === null || quantity === undefined) {
            return "1";
        }
        
        const sanitized = String(quantity).trim();
        
        if (sanitized.length === 0) {
            return "1";
        }
        
        if (sanitized.length > 50) {
            throw new Error('Quantity cannot exceed 50 characters');
        }
        
        // Remove potentially harmful characters
        return sanitized.replace(/[<>\"'&]/g, '');
    }
    
    /**
     * Sanitize and validate category
     * @param {string} category - Raw category
     * @returns {string} Sanitized category
     */
    sanitizeCategory(category) {
        if (typeof category !== 'string') {
            return 'miscellaneous';
        }
        
        const sanitized = category.trim().toLowerCase();
        
        if (sanitized.length === 0) {
            return 'miscellaneous';
        }
        
        if (sanitized.length > 30) {
            return 'miscellaneous';
        }
        
        // Remove potentially harmful characters
        return sanitized.replace(/[<>\"'&]/g, '');
    }
    
    /**
     * Validate the shopping item
     * @throws {Error} If validation fails
     */
    validate() {
        if (!this.id || typeof this.id !== 'string') {
            throw new Error('Item must have a valid ID');
        }
        
        if (!this.name || typeof this.name !== 'string') {
            throw new Error('Item must have a valid name');
        }
        
        if (!this.quantity || typeof this.quantity !== 'string') {
            throw new Error('Item must have a valid quantity');
        }
        
        if (!this.category || typeof this.category !== 'string') {
            throw new Error('Item must have a valid category');
        }
        
        if (!(this.dateAdded instanceof Date)) {
            throw new Error('Item must have a valid date');
        }
        
        if (typeof this.completed !== 'boolean') {
            throw new Error('Item completed status must be a boolean');
        }
    }
    
    /**
     * Update the quantity of this item
     * @param {string|number} newQuantity - New quantity value
     */
    updateQuantity(newQuantity) {
        this.quantity = this.sanitizeQuantity(newQuantity);
        this.validate();
    }
    
    /**
     * Mark item as completed or uncompleted
     * @param {boolean} completed - Completion status
     */
    setCompleted(completed) {
        this.completed = Boolean(completed);
    }
    
    /**
     * Update the category of this item
     * @param {string} newCategory - New category
     */
    updateCategory(newCategory) {
        this.category = this.sanitizeCategory(newCategory);
        this.validate();
    }
    
    /**
     * Convert item to plain object for storage
     * @returns {Object} Plain object representation
     */
    toJSON() {
        return {
            id: this.id,
            name: this.name,
            quantity: this.quantity,
            category: this.category,
            dateAdded: this.dateAdded.toISOString(),
            completed: this.completed
        };
    }
    
    /**
     * Create ShoppingItem from plain object
     * @param {Object} data - Plain object data
     * @returns {ShoppingItem} New ShoppingItem instance
     */
    static fromJSON(data) {
        if (!data || typeof data !== 'object') {
            throw new Error('Invalid data for ShoppingItem creation');
        }
        
        const item = new ShoppingItem(
            data.name,
            data.quantity,
            data.category,
            data.id
        );
        
        if (data.dateAdded) {
            item.dateAdded = new Date(data.dateAdded);
        }
        
        if (typeof data.completed === 'boolean') {
            item.completed = data.completed;
        }
        
        return item;
    }
    
    /**
     * Create a copy of this item
     * @returns {ShoppingItem} New ShoppingItem instance
     */
    clone() {
        return ShoppingItem.fromJSON(this.toJSON());
    }
    
    /**
     * Check if this item matches another item (by name)
     * @param {ShoppingItem|string} other - Other item or item name
     * @returns {boolean} True if items match
     */
    matches(other) {
        const otherName = typeof other === 'string' ? other : other.name;
        return this.name.toLowerCase() === otherName.toLowerCase();
    }
    
    /**
     * Get a display-friendly version of the item
     * @returns {string} Formatted item string
     */
    toString() {
        return `${this.quantity} ${this.name}`;
    }
}