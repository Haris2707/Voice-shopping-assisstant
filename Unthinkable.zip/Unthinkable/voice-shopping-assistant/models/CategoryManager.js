/**
 * CategoryManager - Handles automatic categorization of shopping items
 * Provides fuzzy matching and category management functionality
 */

export class CategoryManager {
    constructor() {
        // Predefined category mappings with comprehensive item lists
        this.categories = {
            'dairy': [
                'milk', 'cheese', 'yogurt', 'butter', 'cream', 'sour cream', 
                'cottage cheese', 'mozzarella', 'cheddar', 'parmesan', 'feta',
                'ricotta', 'cream cheese', 'half and half', 'heavy cream',
                'whipped cream', 'ice cream', 'frozen yogurt'
            ],
            'produce': [
                'apple', 'banana', 'orange', 'carrot', 'lettuce', 'tomato', 
                'onion', 'potato', 'broccoli', 'spinach', 'cucumber', 'bell pepper',
                'celery', 'garlic', 'ginger', 'lemon', 'lime', 'strawberry',
                'blueberry', 'grape', 'avocado', 'mushroom', 'zucchini',
                'sweet potato', 'corn', 'peas', 'green beans', 'cabbage',
                'cauliflower', 'kale', 'arugula', 'basil', 'cilantro', 'parsley'
            ],
            'meat': [
                'chicken', 'beef', 'pork', 'fish', 'turkey', 'ham', 'bacon', 
                'sausage', 'ground beef', 'chicken breast', 'salmon', 'tuna',
                'shrimp', 'crab', 'lobster', 'lamb', 'duck', 'steak',
                'ground turkey', 'hot dogs', 'deli meat', 'pepperoni'
            ],
            'pantry': [
                'rice', 'pasta', 'flour', 'sugar', 'salt', 'pepper', 'oil', 
                'vinegar', 'bread', 'cereal', 'oats', 'quinoa', 'beans',
                'lentils', 'canned tomatoes', 'tomato sauce', 'olive oil',
                'vegetable oil', 'baking soda', 'baking powder', 'vanilla',
                'spices', 'herbs', 'honey', 'maple syrup', 'peanut butter',
                'jam', 'jelly', 'crackers', 'tortillas', 'bagels'
            ],
            'snacks': [
                'chips', 'cookies', 'crackers', 'nuts', 'candy', 'chocolate',
                'pretzels', 'popcorn', 'granola bars', 'trail mix', 'almonds',
                'peanuts', 'cashews', 'walnuts', 'raisins', 'dried fruit',
                'fruit snacks', 'gum', 'mints'
            ],
            'beverages': [
                'water', 'juice', 'soda', 'coffee', 'tea', 'beer', 'wine',
                'energy drink', 'sports drink', 'milk', 'almond milk',
                'soy milk', 'coconut milk', 'orange juice', 'apple juice',
                'sparkling water', 'kombucha', 'smoothie'
            ],
            'frozen': [
                'ice cream', 'frozen vegetables', 'frozen fruit', 'frozen meals',
                'frozen pizza', 'frozen chicken', 'frozen fish', 'frozen berries',
                'frozen peas', 'frozen corn', 'frozen broccoli', 'ice',
                'popsicles', 'frozen yogurt', 'frozen waffles'
            ],
            'household': [
                'soap', 'shampoo', 'toothpaste', 'toilet paper', 'paper towels',
                'detergent', 'dish soap', 'cleaning supplies', 'trash bags',
                'aluminum foil', 'plastic wrap', 'tissues', 'cotton balls',
                'q-tips', 'deodorant', 'lotion', 'sunscreen'
            ],
            'health': [
                'vitamins', 'medicine', 'bandages', 'aspirin', 'ibuprofen',
                'cough drops', 'cold medicine', 'allergy medicine',
                'first aid', 'thermometer', 'hand sanitizer', 'masks'
            ],
            'bakery': [
                'bread', 'bagels', 'muffins', 'croissants', 'donuts',
                'cake', 'pie', 'cookies', 'rolls', 'baguette'
            ],
            'deli': [
                'deli meat', 'sliced cheese', 'ham', 'turkey', 'salami',
                'roast beef', 'pastrami', 'bologna', 'swiss cheese',
                'provolone', 'hummus', 'olives'
            ]
        };
        
        // Common synonyms and variations for fuzzy matching
        this.synonyms = {
            'soda': ['pop', 'soft drink', 'cola', 'pepsi', 'coke'],
            'ground beef': ['hamburger', 'ground meat'],
            'bell pepper': ['pepper', 'capsicum'],
            'green beans': ['string beans'],
            'sweet potato': ['yam'],
            'aluminum foil': ['foil', 'tin foil'],
            'plastic wrap': ['saran wrap', 'cling wrap'],
            'paper towels': ['paper towel'],
            'toilet paper': ['tp', 'bathroom tissue'],
            'dish soap': ['dishwashing liquid', 'dish detergent']
        };
    }
    
    /**
     * Categorize an item using fuzzy matching
     * @param {string} itemName - Name of the item to categorize
     * @returns {string} Category name
     */
    categorizeItem(itemName) {
        if (!itemName || typeof itemName !== 'string') {
            return 'miscellaneous';
        }
        
        const normalizedName = itemName.toLowerCase().trim();
        
        // First, try exact matching
        const exactMatch = this.findExactMatch(normalizedName);
        if (exactMatch) {
            return exactMatch;
        }
        
        // Then try fuzzy matching
        const fuzzyMatch = this.findFuzzyMatch(normalizedName);
        if (fuzzyMatch) {
            return fuzzyMatch;
        }
        
        // Finally, try synonym matching
        const synonymMatch = this.findSynonymMatch(normalizedName);
        if (synonymMatch) {
            return synonymMatch;
        }
        
        return 'miscellaneous';
    }
    
    /**
     * Find exact match in categories
     * @param {string} normalizedName - Normalized item name
     * @returns {string|null} Category name or null
     */
    findExactMatch(normalizedName) {
        for (const [category, items] of Object.entries(this.categories)) {
            if (items.includes(normalizedName)) {
                return category;
            }
        }
        return null;
    }
    
    /**
     * Find fuzzy match using substring matching and similarity
     * @param {string} normalizedName - Normalized item name
     * @returns {string|null} Category name or null
     */
    findFuzzyMatch(normalizedName) {
        let bestMatch = null;
        let bestScore = 0;
        
        for (const [category, items] of Object.entries(this.categories)) {
            for (const item of items) {
                const score = this.calculateSimilarity(normalizedName, item);
                
                // Consider it a match if similarity is high enough
                if (score > bestScore && score >= 0.6) {
                    bestScore = score;
                    bestMatch = category;
                }
            }
        }
        
        return bestMatch;
    }
    
    /**
     * Find match using synonyms
     * @param {string} normalizedName - Normalized item name
     * @returns {string|null} Category name or null
     */
    findSynonymMatch(normalizedName) {
        // Check if the item name is a synonym
        for (const [mainTerm, synonymList] of Object.entries(this.synonyms)) {
            if (synonymList.some(synonym => 
                normalizedName.includes(synonym) || synonym.includes(normalizedName)
            )) {
                // Find the category for the main term
                return this.findExactMatch(mainTerm) || this.findFuzzyMatch(mainTerm);
            }
        }
        
        return null;
    }
    
    /**
     * Calculate similarity between two strings using multiple methods
     * @param {string} str1 - First string
     * @param {string} str2 - Second string
     * @returns {number} Similarity score between 0 and 1
     */
    calculateSimilarity(str1, str2) {
        // Substring matching (highest priority)
        if (str1.includes(str2) || str2.includes(str1)) {
            return 0.9;
        }
        
        // Word boundary matching
        const words1 = str1.split(/\s+/);
        const words2 = str2.split(/\s+/);
        
        for (const word1 of words1) {
            for (const word2 of words2) {
                if (word1 === word2 && word1.length > 2) {
                    return 0.8;
                }
                if ((word1.includes(word2) || word2.includes(word1)) && 
                    Math.min(word1.length, word2.length) > 3) {
                    return 0.7;
                }
            }
        }
        
        // Levenshtein distance for close matches
        const distance = this.levenshteinDistance(str1, str2);
        const maxLength = Math.max(str1.length, str2.length);
        const similarity = 1 - (distance / maxLength);
        
        // Only consider it a match if similarity is reasonably high
        return similarity > 0.6 ? similarity : 0;
    }
    
    /**
     * Calculate Levenshtein distance between two strings
     * @param {string} str1 - First string
     * @param {string} str2 - Second string
     * @returns {number} Edit distance
     */
    levenshteinDistance(str1, str2) {
        const matrix = [];
        
        // Initialize matrix
        for (let i = 0; i <= str2.length; i++) {
            matrix[i] = [i];
        }
        
        for (let j = 0; j <= str1.length; j++) {
            matrix[0][j] = j;
        }
        
        // Fill matrix
        for (let i = 1; i <= str2.length; i++) {
            for (let j = 1; j <= str1.length; j++) {
                if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j - 1] + 1, // substitution
                        matrix[i][j - 1] + 1,     // insertion
                        matrix[i - 1][j] + 1      // deletion
                    );
                }
            }
        }
        
        return matrix[str2.length][str1.length];
    }
    
    /**
     * Get all available categories
     * @returns {string[]} Array of category names
     */
    getCategories() {
        return Object.keys(this.categories).concat(['miscellaneous']);
    }
    
    /**
     * Add a custom category with items
     * @param {string} categoryName - Name of the new category
     * @param {string[]} items - Items that belong to this category
     */
    addCustomCategory(categoryName, items = []) {
        if (categoryName && typeof categoryName === 'string') {
            const normalizedCategory = categoryName.toLowerCase().trim();
            const normalizedItems = items.map(item => 
                typeof item === 'string' ? item.toLowerCase().trim() : ''
            ).filter(item => item.length > 0);
            
            this.categories[normalizedCategory] = normalizedItems;
        }
    }
    
    /**
     * Add items to an existing category
     * @param {string} categoryName - Name of the category
     * @param {string[]} items - Items to add
     */
    addItemsToCategory(categoryName, items) {
        if (!categoryName || !Array.isArray(items)) {
            return;
        }
        
        const normalizedCategory = categoryName.toLowerCase().trim();
        
        if (this.categories[normalizedCategory]) {
            const normalizedItems = items.map(item => 
                typeof item === 'string' ? item.toLowerCase().trim() : ''
            ).filter(item => item.length > 0);
            
            // Add items that don't already exist
            normalizedItems.forEach(item => {
                if (!this.categories[normalizedCategory].includes(item)) {
                    this.categories[normalizedCategory].push(item);
                }
            });
        }
    }
    
    /**
     * Get items in a specific category
     * @param {string} categoryName - Name of the category
     * @returns {string[]} Array of items in the category
     */
    getItemsInCategory(categoryName) {
        if (!categoryName || typeof categoryName !== 'string') {
            return [];
        }
        
        const normalizedCategory = categoryName.toLowerCase().trim();
        return this.categories[normalizedCategory] || [];
    }
    
    /**
     * Remove a category
     * @param {string} categoryName - Name of the category to remove
     * @returns {boolean} True if category was removed
     */
    removeCategory(categoryName) {
        if (!categoryName || typeof categoryName !== 'string') {
            return false;
        }
        
        const normalizedCategory = categoryName.toLowerCase().trim();
        
        if (this.categories[normalizedCategory]) {
            delete this.categories[normalizedCategory];
            return true;
        }
        
        return false;
    }
    
    /**
     * Get category statistics
     * @returns {Object} Statistics about categories and items
     */
    getCategoryStatistics() {
        const stats = {
            totalCategories: Object.keys(this.categories).length,
            totalItems: 0,
            categoryBreakdown: {}
        };
        
        for (const [category, items] of Object.entries(this.categories)) {
            stats.categoryBreakdown[category] = items.length;
            stats.totalItems += items.length;
        }
        
        return stats;
    }
    
    /**
     * Export categories as JSON
     * @returns {Object} Categories data
     */
    exportCategories() {
        return {
            categories: { ...this.categories },
            synonyms: { ...this.synonyms }
        };
    }
    
    /**
     * Import categories from JSON
     * @param {Object} data - Categories data
     * @returns {boolean} True if import was successful
     */
    importCategories(data) {
        try {
            if (data.categories && typeof data.categories === 'object') {
                this.categories = { ...data.categories };
            }
            
            if (data.synonyms && typeof data.synonyms === 'object') {
                this.synonyms = { ...data.synonyms };
            }
            
            return true;
        } catch (error) {
            console.error('Failed to import categories:', error);
            return false;
        }
    }
}