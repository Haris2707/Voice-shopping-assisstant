/**
 * SearchEngine - Handles product search functionality
 * Provides search capabilities with filtering and result presentation
 */

import { ProductDatabase } from './ProductDatabase.js';

export class SearchEngine {
    constructor() {
        this.productDatabase = new ProductDatabase();
        this.maxResults = 10; // Limit results for voice presentation
    }
    
    /**
     * Search for products based on criteria
     * @param {Object} criteria - Search criteria from NLP parser
     * @returns {Object} Search results with metadata
     */
    search(criteria) {
        console.log('Searching with criteria:', criteria);
        
        // Perform the search
        const results = this.productDatabase.searchProducts(criteria);
        
        // Limit results for better voice presentation
        const limitedResults = results.slice(0, this.maxResults);
        
        // Generate search summary
        const summary = this.generateSearchSummary(criteria, results.length, limitedResults.length);
        
        return {
            criteria: criteria,
            results: limitedResults,
            totalResults: results.length,
            displayedResults: limitedResults.length,
            summary: summary,
            hasMoreResults: results.length > this.maxResults
        };
    }
    
    /**
     * Generate a summary of search results for voice presentation
     * @param {Object} criteria - Search criteria
     * @param {number} totalResults - Total number of results found
     * @param {number} displayedResults - Number of results being displayed
     * @returns {string} Search summary text
     */
    generateSearchSummary(criteria, totalResults, displayedResults) {
        let summary = '';
        
        if (totalResults === 0) {
            summary = `No products found`;
            if (criteria.query) {
                summary += ` for "${criteria.query}"`;
            }
            if (criteria.filters.maxPrice) {
                summary += ` under $${criteria.filters.maxPrice}`;
            }
            if (criteria.filters.type) {
                summary += ` that are ${criteria.filters.type}`;
            }
            if (criteria.filters.brand) {
                summary += ` from ${criteria.filters.brand}`;
            }
        } else if (totalResults === 1) {
            summary = `Found 1 product`;
        } else {
            summary = `Found ${totalResults} products`;
            if (displayedResults < totalResults) {
                summary += `, showing top ${displayedResults}`;
            }
        }
        
        return summary;
    }
    
    /**
     * Format search results for voice presentation
     * @param {Object} searchResults - Results from search method
     * @returns {string} Formatted text for speech synthesis
     */
    formatResultsForVoice(searchResults) {
        const { results, summary } = searchResults;
        
        if (results.length === 0) {
            return `${summary}. You might want to try a different search term or remove some filters.`;
        }
        
        let voiceText = `${summary}. `;
        
        if (results.length === 1) {
            const product = results[0];
            voiceText += `I found ${product.name}`;
            if (product.brand !== 'generic') {
                voiceText += ` by ${product.brand}`;
            }
            if (product.type) {
                voiceText += `, ${product.type}`;
            }
            voiceText += ` for $${product.price.toFixed(2)}.`;
        } else {
            voiceText += 'Here are the options: ';
            
            // Present top 3 results in detail for voice
            const topResults = results.slice(0, 3);
            topResults.forEach((product, index) => {
                if (index > 0) voiceText += ', ';
                voiceText += `${product.name}`;
                if (product.brand !== 'generic') {
                    voiceText += ` by ${product.brand}`;
                }
                voiceText += ` for $${product.price.toFixed(2)}`;
            });
            
            if (results.length > 3) {
                voiceText += `, and ${results.length - 3} more options.`;
            }
        }
        
        return voiceText;
    }
    
    /**
     * Format search results for visual display
     * @param {Object} searchResults - Results from search method
     * @returns {Object} Formatted data for UI display
     */
    formatResultsForDisplay(searchResults) {
        const { results, summary, hasMoreResults } = searchResults;
        
        return {
            summary: summary,
            products: results.map(product => ({
                id: product.id,
                name: product.name,
                brand: product.brand,
                type: product.type,
                price: product.price,
                category: product.category,
                organic: product.organic,
                displayName: this.formatProductDisplayName(product),
                priceDisplay: `$${product.price.toFixed(2)}`
            })),
            hasMoreResults: hasMoreResults,
            isEmpty: results.length === 0
        };
    }
    
    /**
     * Format product name for display
     * @param {Object} product - Product object
     * @returns {string} Formatted display name
     */
    formatProductDisplayName(product) {
        let displayName = product.name;
        
        if (product.type && product.type !== 'generic') {
            displayName += ` (${product.type})`;
        }
        
        if (product.brand && product.brand !== 'generic') {
            displayName += ` - ${product.brand}`;
        }
        
        if (product.organic) {
            displayName += ' [Organic]';
        }
        
        return displayName;
    }
    
    /**
     * Get search suggestions based on partial query
     * @param {string} partialQuery - Partial search query
     * @returns {Array} Array of suggested search terms
     */
    getSearchSuggestions(partialQuery) {
        if (!partialQuery || partialQuery.length < 2) {
            return [];
        }
        
        const query = partialQuery.toLowerCase();
        const suggestions = new Set();
        
        // Get product name suggestions
        this.productDatabase.products.forEach(product => {
            if (product.name.toLowerCase().includes(query)) {
                suggestions.add(product.name);
            }
            if (product.type.toLowerCase().includes(query)) {
                suggestions.add(`${product.type} ${product.name}`);
            }
            if (product.brand.toLowerCase().includes(query) && product.brand !== 'generic') {
                suggestions.add(`${product.brand} ${product.name}`);
            }
        });
        
        return Array.from(suggestions).slice(0, 5);
    }
    
    /**
     * Get popular search terms
     * @returns {Array} Array of popular search terms
     */
    getPopularSearches() {
        return [
            'organic apples',
            'milk under $4',
            'chicken breast',
            'whole wheat bread',
            'greek yogurt',
            'olive oil',
            'fresh vegetables',
            'snacks under $3'
        ];
    }
    
    /**
     * Add a product to shopping list from search results
     * @param {number} productId - Product ID from search results
     * @param {string} quantity - Quantity to add (optional)
     * @returns {Object} Product information for adding to list
     */
    getProductForList(productId, quantity = '1') {
        const product = this.productDatabase.getProductById(productId);
        
        if (!product) {
            throw new Error('Product not found');
        }
        
        return {
            name: product.name,
            quantity: quantity,
            category: product.category,
            price: product.price,
            brand: product.brand,
            type: product.type
        };
    }
}