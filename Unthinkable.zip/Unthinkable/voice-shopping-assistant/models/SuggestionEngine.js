/**
 * SuggestionEngine - Provides smart recommendations based on history and context
 * Handles usage history tracking, seasonal suggestions, and substitute recommendations
 */

export class SuggestionEngine {
    constructor(storageManager = null) {
        this.storage = storageManager;
        this.history = this.loadHistory();
        
        // Seasonal item mappings
        this.seasonalItems = {
            spring: ['strawberries', 'asparagus', 'artichokes', 'peas', 'spring onions', 'lettuce'],
            summer: ['tomatoes', 'corn', 'watermelon', 'berries', 'zucchini', 'peaches', 'ice cream'],
            fall: ['pumpkins', 'apples', 'squash', 'sweet potatoes', 'cranberries', 'cinnamon'],
            winter: ['oranges', 'soup', 'hot chocolate', 'root vegetables', 'citrus fruits', 'warm spices']
        };
        
        // Common substitute mappings
        this.substitutes = {
            'milk': [
                { item: 'almond milk', reason: 'dairy-free alternative' },
                { item: 'soy milk', reason: 'plant-based protein' },
                { item: 'oat milk', reason: 'creamy texture, environmentally friendly' }
            ],
            'butter': [
                { item: 'olive oil', reason: 'healthier cooking option' },
                { item: 'margarine', reason: 'dairy-free alternative' },
                { item: 'coconut oil', reason: 'natural alternative' }
            ],
            'sugar': [
                { item: 'honey', reason: 'natural sweetener' },
                { item: 'maple syrup', reason: 'natural alternative' },
                { item: 'stevia', reason: 'zero-calorie option' }
            ],
            'bread': [
                { item: 'whole wheat bread', reason: 'more nutritious' },
                { item: 'gluten-free bread', reason: 'gluten-free option' },
                { item: 'rice cakes', reason: 'low-carb alternative' }
            ]
        };
        
        // Frequency thresholds for suggestions
        this.SUGGESTION_THRESHOLDS = {
            MIN_FREQUENCY: 2,
            DAYS_SINCE_LAST_PURCHASE: 7,
            MAX_SUGGESTIONS: 5
        };
    }
    
    /**
     * Get personalized recommendations based on usage history
     * @param {number} maxSuggestions - Maximum number of suggestions to return
     * @returns {Array} Array of recommendation objects
     */
    getRecommendations(maxSuggestions = 5) {
        const recommendations = [];
        const currentDate = new Date();
        
        // Get frequent items that haven't been purchased recently
        const frequentItems = this.history.frequentItems
            .filter(item => {
                const daysSinceLastPurchase = this.getDaysSince(item.lastPurchased);
                return item.frequency >= this.SUGGESTION_THRESHOLDS.MIN_FREQUENCY &&
                       daysSinceLastPurchase >= this.SUGGESTION_THRESHOLDS.DAYS_SINCE_LAST_PURCHASE;
            })
            .sort((a, b) => {
                // Sort by frequency and recency
                const aScore = a.frequency * (1 / Math.max(1, this.getDaysSince(a.lastPurchased)));
                const bScore = b.frequency * (1 / Math.max(1, this.getDaysSince(b.lastPurchased)));
                return bScore - aScore;
            })
            .slice(0, maxSuggestions);
        
        frequentItems.forEach(item => {
            recommendations.push({
                type: 'frequent',
                itemName: item.itemName,
                reason: `You buy this ${this.getFrequencyDescription(item.frequency)}`,
                confidence: this.calculateConfidence(item),
                frequency: item.frequency,
                lastPurchased: item.lastPurchased
            });
        });
        
        // Add seasonal suggestions if we have room
        const remainingSlots = maxSuggestions - recommendations.length;
        if (remainingSlots > 0) {
            const seasonalSuggestions = this.getSeasonalItems(remainingSlots);
            recommendations.push(...seasonalSuggestions);
        }
        
        return recommendations.slice(0, maxSuggestions);
    }
    
    /**
     * Get seasonal item recommendations
     * @param {number} maxSuggestions - Maximum number of suggestions to return
     * @returns {Array} Array of seasonal recommendation objects
     */
    getSeasonalItems(maxSuggestions = 3) {
        const currentSeason = this.getCurrentSeason();
        const seasonalItems = this.seasonalItems[currentSeason] || [];
        
        // Filter out items that are already frequently purchased
        const frequentItemNames = this.history.frequentItems.map(item => item.itemName.toLowerCase());
        const availableSeasonalItems = seasonalItems.filter(item => 
            !frequentItemNames.includes(item.toLowerCase())
        );
        
        // Randomly select seasonal items
        const shuffled = this.shuffleArray([...availableSeasonalItems]);
        const selectedItems = shuffled.slice(0, maxSuggestions);
        
        return selectedItems.map(item => ({
            type: 'seasonal',
            itemName: item,
            reason: `Popular ${currentSeason} item`,
            confidence: 0.6,
            season: currentSeason
        }));
    }
    
    /**
     * Get substitute recommendations for a given item
     * @param {string} itemName - Name of the item to find substitutes for
     * @returns {Array} Array of substitute recommendation objects
     */
    getSubstitutes(itemName) {
        if (!itemName || typeof itemName !== 'string') {
            return [];
        }
        
        const normalizedName = itemName.toLowerCase().trim();
        const substitutes = this.substitutes[normalizedName] || [];
        
        return substitutes.map(substitute => ({
            type: 'substitute',
            itemName: substitute.item,
            originalItem: itemName,
            reason: substitute.reason,
            confidence: 0.8
        }));
    }
    
    /**
     * Update usage history when an item is added to the list
     * @param {string} itemName - Name of the item that was added
     */
    updateHistory(itemName) {
        if (!itemName || typeof itemName !== 'string') {
            return;
        }
        
        const normalizedName = itemName.toLowerCase().trim();
        const currentDate = new Date().toISOString();
        
        // Find existing item in history
        const existingItem = this.history.frequentItems.find(
            item => item.itemName.toLowerCase() === normalizedName
        );
        
        if (existingItem) {
            // Update existing item
            existingItem.frequency += 1;
            existingItem.lastPurchased = currentDate;
        } else {
            // Add new item to history
            this.history.frequentItems.push({
                itemName: itemName,
                frequency: 1,
                lastPurchased: currentDate
            });
        }
        
        // Update last modified timestamp
        this.history.lastUpdated = currentDate;
        
        // Save to storage
        this.saveHistory();
        
        // Clean up old or infrequent items to prevent unlimited growth
        this.cleanupHistory();
    }
    
    /**
     * Get recommendations that can be accepted via voice commands
     * @param {number} maxSuggestions - Maximum number of suggestions
     * @returns {Array} Array of voice-ready recommendations
     */
    getVoiceRecommendations(maxSuggestions = 3) {
        const recommendations = this.getRecommendations(maxSuggestions);
        
        return recommendations.map((rec, index) => ({
            ...rec,
            voiceIndex: index + 1,
            voicePrompt: `Say "add suggestion ${index + 1}" to add ${rec.itemName}`,
            acceptCommand: `add suggestion ${index + 1}`,
            declineCommand: `skip suggestion ${index + 1}`
        }));
    }
    
    /**
     * Process voice command for accepting/declining suggestions
     * @param {string} command - Voice command text
     * @param {Array} currentSuggestions - Current suggestion list
     * @returns {Object|null} Accepted suggestion or null
     */
    processVoiceSuggestionCommand(command, currentSuggestions) {
        if (!command || !Array.isArray(currentSuggestions)) {
            return null;
        }
        
        const normalizedCommand = command.toLowerCase().trim();
        
        // Check for "add suggestion X" pattern
        const addMatch = normalizedCommand.match(/add suggestion (\d+)/);
        if (addMatch) {
            const suggestionIndex = parseInt(addMatch[1]) - 1;
            if (suggestionIndex >= 0 && suggestionIndex < currentSuggestions.length) {
                return {
                    action: 'accept',
                    suggestion: currentSuggestions[suggestionIndex]
                };
            }
        }
        
        // Check for "skip suggestion X" pattern
        const skipMatch = normalizedCommand.match(/skip suggestion (\d+)/);
        if (skipMatch) {
            const suggestionIndex = parseInt(skipMatch[1]) - 1;
            if (suggestionIndex >= 0 && suggestionIndex < currentSuggestions.length) {
                return {
                    action: 'decline',
                    suggestion: currentSuggestions[suggestionIndex]
                };
            }
        }
        
        return null;
    }
    
    /**
     * Get current season based on date
     * @returns {string} Current season name
     */
    getCurrentSeason() {
        const now = new Date();
        const month = now.getMonth() + 1; // getMonth() returns 0-11
        
        if (month >= 3 && month <= 5) return 'spring';
        if (month >= 6 && month <= 8) return 'summer';
        if (month >= 9 && month <= 11) return 'fall';
        return 'winter';
    }
    
    /**
     * Calculate confidence score for a recommendation
     * @param {Object} item - Frequent item object
     * @returns {number} Confidence score between 0 and 1
     */
    calculateConfidence(item) {
        const frequency = item.frequency;
        const daysSinceLastPurchase = this.getDaysSince(item.lastPurchased);
        
        // Higher frequency = higher confidence
        // More recent purchases = higher confidence
        const frequencyScore = Math.min(frequency / 10, 1); // Cap at 10 purchases
        const recencyScore = Math.max(0, 1 - (daysSinceLastPurchase / 30)); // Decay over 30 days
        
        return Math.round((frequencyScore * 0.7 + recencyScore * 0.3) * 100) / 100;
    }
    
    /**
     * Get human-readable frequency description
     * @param {number} frequency - Purchase frequency
     * @returns {string} Frequency description
     */
    getFrequencyDescription(frequency) {
        if (frequency >= 10) return 'very frequently';
        if (frequency >= 5) return 'frequently';
        if (frequency >= 3) return 'regularly';
        return 'occasionally';
    }
    
    /**
     * Calculate days since a given date
     * @param {string} dateString - ISO date string
     * @returns {number} Number of days since the date
     */
    getDaysSince(dateString) {
        try {
            const date = new Date(dateString);
            // Check if date is invalid
            if (isNaN(date.getTime())) {
                return 999; // Return large number for invalid dates
            }
            const now = new Date();
            const diffTime = Math.abs(now - date);
            return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        } catch (error) {
            return 999; // Return large number for invalid dates
        }
    }
    
    /**
     * Shuffle array using Fisher-Yates algorithm
     * @param {Array} array - Array to shuffle
     * @returns {Array} Shuffled array
     */
    shuffleArray(array) {
        const shuffled = [...array];
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
    }
    
    /**
     * Load usage history from storage
     * @returns {Object} Usage history object
     */
    loadHistory() {
        if (!this.storage) {
            return { frequentItems: [], lastUpdated: new Date().toISOString() };
        }
        
        try {
            return this.storage.loadHistory();
        } catch (error) {
            console.error('Failed to load suggestion history:', error);
            return { frequentItems: [], lastUpdated: new Date().toISOString() };
        }
    }
    
    /**
     * Save usage history to storage
     * @returns {boolean} True if save was successful
     */
    saveHistory() {
        if (!this.storage) {
            return false;
        }
        
        try {
            return this.storage.saveHistory(this.history);
        } catch (error) {
            console.error('Failed to save suggestion history:', error);
            return false;
        }
    }
    
    /**
     * Clean up old or infrequent items from history
     */
    cleanupHistory() {
        const maxHistoryItems = 100;
        const minFrequencyToKeep = 1;
        const maxDaysToKeep = 365;
        
        // Remove items that are too old or infrequent
        this.history.frequentItems = this.history.frequentItems.filter(item => {
            const daysSinceLastPurchase = this.getDaysSince(item.lastPurchased);
            return item.frequency >= minFrequencyToKeep && 
                   daysSinceLastPurchase <= maxDaysToKeep;
        });
        
        // Keep only the most frequent items if we exceed the limit
        if (this.history.frequentItems.length > maxHistoryItems) {
            this.history.frequentItems.sort((a, b) => b.frequency - a.frequency);
            this.history.frequentItems = this.history.frequentItems.slice(0, maxHistoryItems);
        }
    }
    
    /**
     * Clear all history data
     */
    clearHistory() {
        this.history = { frequentItems: [], lastUpdated: new Date().toISOString() };
        this.saveHistory();
    }
    
    /**
     * Get statistics about the suggestion engine
     * @returns {Object} Statistics object
     */
    getStatistics() {
        const totalItems = this.history.frequentItems.length;
        const totalPurchases = this.history.frequentItems.reduce((sum, item) => sum + item.frequency, 0);
        const averageFrequency = totalItems > 0 ? totalPurchases / totalItems : 0;
        
        return {
            totalTrackedItems: totalItems,
            totalPurchases: totalPurchases,
            averageFrequency: Math.round(averageFrequency * 100) / 100,
            lastUpdated: this.history.lastUpdated,
            currentSeason: this.getCurrentSeason()
        };
    }
}