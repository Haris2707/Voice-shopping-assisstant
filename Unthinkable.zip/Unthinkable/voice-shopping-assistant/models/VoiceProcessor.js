/**
 * VoiceProcessor - Handles Web Speech API integration
 * Manages voice recognition, browser compatibility, and error handling
 */

export class VoiceProcessor {
    constructor(onCommandReceived, onError, onStatusChange) {
        this.onCommandReceived = onCommandReceived || (() => {});
        this.onError = onError || (() => {});
        this.onStatusChange = onStatusChange || (() => {});
        
        this.isListening = false;
        this.hasPermissions = false;
        this.speechRecognition = null;
        this.currentLanguage = 'en-US';
        this.isSupported = false;
        
        this.init();
    }
    
    /**
     * Initialize the VoiceProcessor
     */
    init() {
        console.log('Initializing VoiceProcessor...');
        
        // Detect mobile device
        this.isMobile = this.detectMobile();
        
        this.checkBrowserSupport();
        this.checkMicrophonePermissions();
        
        // Set up mobile-specific optimizations
        if (this.isMobile) {
            this.setupMobileOptimizations();
        }
    }
    
    /**
     * Detect if the device is mobile
     * @returns {boolean} True if mobile device
     */
    detectMobile() {
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
               (window.innerWidth <= 768) ||
               ('ontouchstart' in window);
    }
    
    /**
     * Set up mobile-specific optimizations
     */
    setupMobileOptimizations() {
        console.log('Setting up mobile voice optimizations...');
        
        // Handle mobile browser focus/blur events
        window.addEventListener('focus', () => {
            if (this.isListening) {
                // Restart recognition if it was interrupted
                setTimeout(() => {
                    this.restartRecognition();
                }, 100);
            }
        });
        
        window.addEventListener('blur', () => {
            // Mobile browsers may pause recognition when app loses focus
            if (this.isListening) {
                this.onStatusChange('PAUSED', 'Voice recognition paused (app in background)');
            }
        });
        
        // Handle mobile-specific audio interruptions
        if ('mediaSession' in navigator) {
            navigator.mediaSession.setActionHandler('pause', () => {
                if (this.isListening) {
                    this.stopListening();
                }
            });
        }
        
        // Handle mobile keyboard events that might interfere
        document.addEventListener('focusin', (event) => {
            if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
                if (this.isListening) {
                    this.stopListening();
                    this.onStatusChange('PAUSED', 'Voice recognition paused for text input');
                }
            }
        });
    }
    
    /**
     * Check if the browser supports Web Speech API
     * @returns {boolean} True if supported, false otherwise
     */
    checkBrowserSupport() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        
        if (!SpeechRecognition) {
            console.warn('Web Speech API not supported in this browser');
            this.isSupported = false;
            this.onError('BROWSER_NOT_SUPPORTED', 'Web Speech API is not supported in this browser');
            return false;
        }
        
        this.isSupported = true;
        this.speechRecognition = new SpeechRecognition();
        this.setupSpeechRecognition();
        console.log('Web Speech API supported');
        return true;
    }
    
    /**
     * Set up speech recognition configuration and event handlers
     */
    setupSpeechRecognition() {
        if (!this.speechRecognition) return;
        
        // Configure speech recognition with mobile optimizations
        this.speechRecognition.continuous = false;
        this.speechRecognition.interimResults = true;
        this.speechRecognition.lang = this.currentLanguage;
        this.speechRecognition.maxAlternatives = this.isMobile ? 1 : 3; // Reduce alternatives on mobile for performance
        
        // Mobile-specific optimizations
        if (this.isMobile) {
            // Shorter timeout for mobile to handle interruptions better
            this.speechRecognition.grammars = null; // Disable grammars on mobile for better performance
        }
        
        // Event handlers
        this.speechRecognition.onstart = () => {
            console.log('Speech recognition started');
            this.isListening = true;
            this.onStatusChange('LISTENING', 'Listening... speak now');
        };
        
        this.speechRecognition.onend = () => {
            console.log('Speech recognition ended');
            this.isListening = false;
            this.onStatusChange('READY', 'Ready');
        };
        
        this.speechRecognition.onresult = (event) => {
            this.handleSpeechResult(event);
        };
        
        this.speechRecognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            this.handleSpeechError(event.error);
        };
        
        this.speechRecognition.onspeechend = () => {
            console.log('Speech ended');
        };
        
        this.speechRecognition.onnomatch = () => {
            console.log('No speech match');
            this.onStatusChange('ERROR', 'Could not understand - please try again');
        };
    }
    
    /**
     * Handle speech recognition results
     * @param {SpeechRecognitionEvent} event - The speech recognition event
     */
    handleSpeechResult(event) {
        let finalTranscript = '';
        let interimTranscript = '';
        
        // Process all results
        for (let i = event.resultIndex; i < event.results.length; i++) {
            const result = event.results[i];
            const transcript = result[0].transcript;
            
            if (result.isFinal) {
                finalTranscript += transcript;
            } else {
                interimTranscript += transcript;
            }
        }
        
        // Show interim results to user
        if (interimTranscript) {
            this.onStatusChange('INTERIM', `Hearing: "${interimTranscript}"`);
        }
        
        // Process final result
        if (finalTranscript) {
            console.log('Speech recognized:', finalTranscript);
            this.onCommandReceived(finalTranscript.trim());
        }
    }
    
    /**
     * Handle speech recognition errors
     * @param {string} error - The error type
     */
    handleSpeechError(error) {
        this.isListening = false;
        
        let errorCode = 'UNKNOWN_ERROR';
        let message = 'Voice recognition error';
        
        switch (error) {
            case 'no-speech':
                errorCode = 'NO_SPEECH';
                message = 'No speech detected - try again';
                break;
            case 'audio-capture':
                errorCode = 'AUDIO_CAPTURE';
                message = 'Microphone not available';
                break;
            case 'not-allowed':
                errorCode = 'PERMISSION_DENIED';
                message = 'Microphone access denied';
                this.hasPermissions = false;
                break;
            case 'network':
                errorCode = 'NETWORK_ERROR';
                message = 'Network error - check connection';
                break;
            case 'service-not-allowed':
                errorCode = 'SERVICE_NOT_ALLOWED';
                message = 'Speech service not allowed';
                break;
            case 'bad-grammar':
                errorCode = 'BAD_GRAMMAR';
                message = 'Grammar error in speech recognition';
                break;
            case 'language-not-supported':
                errorCode = 'LANGUAGE_NOT_SUPPORTED';
                message = 'Language not supported';
                break;
            default:
                errorCode = 'UNKNOWN_ERROR';
                message = `Voice error: ${error}`;
        }
        
        this.onError(errorCode, message);
        this.onStatusChange('ERROR', message);
    }
    
    /**
     * Check microphone permissions
     * @returns {Promise<boolean>} True if permissions granted
     */
    async checkMicrophonePermissions() {
        try {
            // Check if permissions API is available
            if ('permissions' in navigator) {
                const permission = await navigator.permissions.query({ name: 'microphone' });
                
                this.hasPermissions = permission.state === 'granted';
                
                if (permission.state === 'denied') {
                    this.onError('PERMISSION_DENIED', 'Microphone access denied');
                }
                
                // Listen for permission changes
                permission.onchange = () => {
                    this.hasPermissions = permission.state === 'granted';
                    this.onStatusChange('PERMISSION_CHANGED', 
                        this.hasPermissions ? 'Microphone access granted' : 'Microphone access denied');
                };
                
                return this.hasPermissions;
            } else {
                // Fallback for browsers without permissions API
                console.log('Permissions API not available, will request on first use');
                return true; // Assume permission will be requested when needed
            }
        } catch (error) {
            console.error('Error checking microphone permissions:', error);
            this.onError('PERMISSION_CHECK_FAILED', 'Could not check microphone permissions');
            return false;
        }
    }
    
    /**
     * Request microphone permissions
     * @returns {Promise<boolean>} True if permissions granted
     */
    async requestMicrophonePermissions() {
        try {
            // Request access by trying to get user media
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            
            // Stop the stream immediately as we only needed permission
            stream.getTracks().forEach(track => track.stop());
            
            this.hasPermissions = true;
            this.onStatusChange('PERMISSION_GRANTED', 'Microphone access granted');
            
            console.log('Microphone permissions granted');
            return true;
        } catch (error) {
            console.error('Microphone permission denied:', error);
            this.hasPermissions = false;
            this.onError('PERMISSION_DENIED', 'Microphone access denied');
            return false;
        }
    }
    
    /**
     * Start listening for voice commands
     * @returns {Promise<boolean>} True if started successfully
     */
    async startListening() {
        if (!this.isSupported) {
            this.onError('BROWSER_NOT_SUPPORTED', 'Voice recognition not supported');
            return false;
        }
        
        if (!this.speechRecognition) {
            this.onError('NOT_INITIALIZED', 'Speech recognition not initialized');
            return false;
        }
        
        // Check permissions first
        if (!this.hasPermissions) {
            const granted = await this.requestMicrophonePermissions();
            if (!granted) {
                return false;
            }
        }
        
        try {
            // Stop any existing recognition
            if (this.isListening) {
                this.speechRecognition.stop();
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            
            this.speechRecognition.start();
            console.log('Speech recognition started successfully');
            return true;
        } catch (error) {
            console.error('Error starting speech recognition:', error);
            
            if (error.name === 'InvalidStateError') {
                // Recognition is already running, stop and restart
                this.speechRecognition.stop();
                setTimeout(async () => {
                    try {
                        this.speechRecognition.start();
                    } catch (retryError) {
                        console.error('Retry failed:', retryError);
                        this.onError('START_FAILED', 'Could not start voice recognition');
                    }
                }, 100);
                return true;
            } else {
                this.onError('START_FAILED', 'Could not start voice recognition');
                return false;
            }
        }
    }
    
    /**
     * Stop listening for voice commands
     */
    stopListening() {
        if (this.speechRecognition && this.isListening) {
            this.speechRecognition.stop();
            console.log('Speech recognition stopped');
        }
    }
    
    /**
     * Restart voice recognition (useful for mobile interruptions)
     */
    restartRecognition() {
        if (!this.isSupported || !this.hasPermissions) {
            return;
        }
        
        console.log('Restarting voice recognition...');
        
        // Stop current recognition if running
        if (this.isListening) {
            this.stopListening();
        }
        
        // Wait a moment then restart
        setTimeout(() => {
            if (!this.isListening) { // Only restart if not already listening
                this.startListening();
            }
        }, 500);
    }
    
    /**
     * Set the language for speech recognition
     * @param {string} languageCode - Language code (e.g., 'en-US', 'es-ES')
     */
    setLanguage(languageCode) {
        this.currentLanguage = languageCode;
        
        if (this.speechRecognition) {
            this.speechRecognition.lang = languageCode;
            console.log(`Speech recognition language set to: ${languageCode}`);
        }
    }
    
    /**
     * Get the current language
     * @returns {string} Current language code
     */
    getLanguage() {
        return this.currentLanguage;
    }
    
    /**
     * Check if voice recognition is currently listening
     * @returns {boolean} True if listening
     */
    getIsListening() {
        return this.isListening;
    }
    
    /**
     * Check if microphone permissions are granted
     * @returns {boolean} True if permissions granted
     */
    getHasPermissions() {
        return this.hasPermissions;
    }
    
    /**
     * Check if Web Speech API is supported
     * @returns {boolean} True if supported
     */
    getIsSupported() {
        return this.isSupported;
    }
    
    /**
     * Get available languages (comprehensive list)
     * @returns {Array} Array of language objects
     */
    getAvailableLanguages() {
        return [
            { code: 'en-US', name: 'English (US)', flag: '🇺🇸' },
            { code: 'en-GB', name: 'English (UK)', flag: '🇬🇧' },
            { code: 'es-ES', name: 'Spanish (Spain)', flag: '🇪🇸' },
            { code: 'es-MX', name: 'Spanish (Mexico)', flag: '🇲🇽' },
            { code: 'fr-FR', name: 'French (France)', flag: '🇫🇷' },
            { code: 'fr-CA', name: 'French (Canada)', flag: '🇨🇦' },
            { code: 'de-DE', name: 'German (Germany)', flag: '🇩🇪' },
            { code: 'it-IT', name: 'Italian (Italy)', flag: '🇮🇹' },
            { code: 'pt-BR', name: 'Portuguese (Brazil)', flag: '🇧🇷' },
            { code: 'pt-PT', name: 'Portuguese (Portugal)', flag: '🇵🇹' },
            { code: 'zh-CN', name: 'Chinese (Simplified)', flag: '🇨🇳' },
            { code: 'zh-TW', name: 'Chinese (Traditional)', flag: '🇹🇼' },
            { code: 'ja-JP', name: 'Japanese', flag: '🇯🇵' },
            { code: 'ko-KR', name: 'Korean', flag: '🇰🇷' },
            { code: 'ru-RU', name: 'Russian', flag: '🇷🇺' },
            { code: 'ar-SA', name: 'Arabic', flag: '🇸🇦' },
            { code: 'hi-IN', name: 'Hindi', flag: '🇮🇳' },
            { code: 'nl-NL', name: 'Dutch', flag: '🇳🇱' },
            { code: 'sv-SE', name: 'Swedish', flag: '🇸🇪' },
            { code: 'da-DK', name: 'Danish', flag: '🇩🇰' },
            { code: 'no-NO', name: 'Norwegian', flag: '🇳🇴' },
            { code: 'fi-FI', name: 'Finnish', flag: '🇫🇮' }
        ];
    }
    
    /**
     * Detect language from speech recognition results
     * @param {string} transcript - The recognized text
     * @returns {string|null} Detected language code or null if uncertain
     */
    detectLanguageFromTranscript(transcript) {
        if (!transcript || transcript.trim().length === 0) {
            return null;
        }
        
        const text = transcript.toLowerCase().trim();
        
        // Simple language detection based on common words and patterns
        const languagePatterns = {
            'es': [
                /\b(añadir|agregar|comprar|necesito|quiero|lista|leche|pan|agua|huevos)\b/,
                /\b(eliminar|quitar|borrar|no necesito)\b/,
                /\b(mi lista|la lista)\b/
            ],
            'fr': [
                /\b(ajouter|acheter|j'ai besoin|je veux|liste|lait|pain|eau|œufs)\b/,
                /\b(supprimer|enlever|retirer|je n'ai pas besoin)\b/,
                /\b(ma liste|la liste)\b/
            ],
            'de': [
                /\b(hinzufügen|kaufen|ich brauche|ich möchte|liste|milch|brot|wasser|eier)\b/,
                /\b(entfernen|löschen|ich brauche nicht)\b/,
                /\b(meine liste|die liste)\b/
            ],
            'it': [
                /\b(aggiungere|comprare|ho bisogno|voglio|lista|latte|pane|acqua|uova)\b/,
                /\b(rimuovere|eliminare|cancellare|non ho bisogno)\b/,
                /\b(la mia lista|la lista)\b/
            ],
            'pt': [
                /\b(adicionar|comprar|preciso|quero|lista|leite|pão|água|ovos)\b/,
                /\b(remover|excluir|apagar|não preciso)\b/,
                /\b(minha lista|a lista)\b/
            ],
            'zh': [
                /[\u4e00-\u9fff]/,  // Chinese characters
                /\b(添加|购买|需要|想要|列表|牛奶|面包|水|鸡蛋)\b/
            ],
            'ja': [
                /[\u3040-\u309f\u30a0-\u30ff\u4e00-\u9fff]/,  // Hiragana, Katakana, Kanji
                /\b(追加|購入|必要|欲しい|リスト|牛乳|パン|水|卵)\b/
            ],
            'ko': [
                /[\uac00-\ud7af]/,  // Korean characters
                /\b(추가|구매|필요|원해|목록|우유|빵|물|계란)\b/
            ],
            'ru': [
                /[\u0400-\u04ff]/,  // Cyrillic characters
                /\b(добавить|купить|нужно|хочу|список|молоко|хлеб|вода|яйца)\b/
            ],
            'ar': [
                /[\u0600-\u06ff]/,  // Arabic characters
                /\b(إضافة|شراء|أحتاج|أريد|قائمة|حليب|خبز|ماء|بيض)\b/
            ],
            'hi': [
                /[\u0900-\u097f]/,  // Devanagari script
                /\b(जोड़ना|खरीदना|चाहिए|चाहता|सूची|दूध|रोटी|पानी|अंडे)\b/
            ]
        };
        
        // Check each language pattern
        for (const [langCode, patterns] of Object.entries(languagePatterns)) {
            for (const pattern of patterns) {
                if (pattern.test(text)) {
                    // Map language codes to full locale codes
                    const localeMap = {
                        'es': 'es-ES',
                        'fr': 'fr-FR',
                        'de': 'de-DE',
                        'it': 'it-IT',
                        'pt': 'pt-BR',
                        'zh': 'zh-CN',
                        'ja': 'ja-JP',
                        'ko': 'ko-KR',
                        'ru': 'ru-RU',
                        'ar': 'ar-SA',
                        'hi': 'hi-IN'
                    };
                    
                    return localeMap[langCode] || langCode;
                }
            }
        }
        
        // Default to current language if no pattern matches
        return null;
    }
    
    /**
     * Auto-switch language based on detected speech
     * @param {string} transcript - The recognized text
     * @returns {boolean} True if language was switched
     */
    autoSwitchLanguage(transcript) {
        const detectedLanguage = this.detectLanguageFromTranscript(transcript);
        
        if (detectedLanguage && detectedLanguage !== this.currentLanguage) {
            console.log(`Auto-switching language from ${this.currentLanguage} to ${detectedLanguage}`);
            this.setLanguage(detectedLanguage);
            return true;
        }
        
        return false;
    }
    
    /**
     * Destroy the VoiceProcessor and clean up resources
     */
    destroy() {
        if (this.speechRecognition) {
            this.stopListening();
            this.speechRecognition = null;
        }
        
        this.onCommandReceived = null;
        this.onError = null;
        this.onStatusChange = null;
        
        console.log('VoiceProcessor destroyed');
    }
}