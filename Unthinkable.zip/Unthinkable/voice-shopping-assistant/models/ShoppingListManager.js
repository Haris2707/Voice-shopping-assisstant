/**
 * ShoppingListManager - Core business logic for managing shopping list operations
 * Handles CRUD operations, categorization, and persistence
 */

import { ShoppingList } from './ShoppingList.js';
import { ShoppingItem } from './ShoppingItem.js';
import { StorageManager } from './StorageManager.js';
import { CategoryManager } from './CategoryManager.js';

export class ShoppingListManager {
    /**
     * Create a new shopping list manager
     * @param {StorageManager} storage - Storage manager instance
     * @param {Object} categoryManager - Category manager instance (optional)
     */
    constructor(storage = null, categoryManager = null) {
        this.storage = storage || new StorageManager();
        this.categoryManager = categoryManager || new CategoryManager();
        this.shoppingList = this.loadList();
        
        // Event listeners for list changes
        this.listeners = {
            itemAdded: [],
            itemRemoved: [],
            itemUpdated: [],
            listCleared: []
        };
    }
    
    /**
     * Add an item to the shopping list
     * @param {string} itemName - Name of the item to add
     * @param {string|number} quantity - Quantity of the item (default: "1")
     * @param {string} category - Category of the item (optional, will auto-categorize)
     * @returns {ShoppingItem} The added or updated item
     */
    addItem(itemName, quantity = "1", category = null) {
        if (!itemName || typeof itemName !== 'string') {
            throw new Error('Item name is required and must be a string');
        }
        
        const sanitizedName = itemName.trim();
        if (sanitizedName.length === 0) {
            throw new Error('Item name cannot be empty');
        }
        
        // Auto-categorize if no category provided
        const finalCategory = category || this.categorizeItem(sanitizedName);
        
        // Add item to the list
        const addedItem = this.shoppingList.addItem(sanitizedName, String(quantity), finalCategory);
        
        // Save to storage
        this.saveList();
        
        // Notify listeners
        this.notifyListeners('itemAdded', addedItem);
        
        return addedItem;
    }
    
    /**
     * Remove an item from the shopping list
     * @param {string} itemName - Name of the item to remove
     * @returns {boolean} True if item was removed, false if not found
     */
    removeItem(itemName) {
        if (!itemName || typeof itemName !== 'string') {
            throw new Error('Item name is required and must be a string');
        }
        
        const sanitizedName = itemName.trim();
        if (sanitizedName.length === 0) {
            throw new Error('Item name cannot be empty');
        }
        
        // Find the item before removing for notification
        const itemToRemove = this.shoppingList.findItemByName(sanitizedName);
        
        // Remove from list
        const wasRemoved = this.shoppingList.removeItem(sanitizedName);
        
        if (wasRemoved) {
            // Save to storage
            this.saveList();
            
            // Notify listeners
            this.notifyListeners('itemRemoved', itemToRemove);
        }
        
        return wasRemoved;
    }
    
    /**
     * Remove an item by its ID
     * @param {string} itemId - ID of the item to remove
     * @returns {boolean} True if item was removed, false if not found
     */
    removeItemById(itemId) {
        if (!itemId || typeof itemId !== 'string') {
            throw new Error('Item ID is required and must be a string');
        }
        
        // Find the item before removing for notification
        const itemToRemove = this.shoppingList.findItemById(itemId);
        
        // Remove from list
        const wasRemoved = this.shoppingList.removeItemById(itemId);
        
        if (wasRemoved) {
            // Save to storage
            this.saveList();
            
            // Notify listeners
            this.notifyListeners('itemRemoved', itemToRemove);
        }
        
        return wasRemoved;
    }
    
    /**
     * Update the quantity of an item
     * @param {string} itemName - Name of the item to update
     * @param {string|number} newQuantity - New quantity value
     * @returns {boolean} True if item was updated, false if not found
     */
    updateQuantity(itemName, newQuantity) {
        if (!itemName || typeof itemName !== 'string') {
            throw new Error('Item name is required and must be a string');
        }
        
        if (newQuantity === null || newQuantity === undefined) {
            throw new Error('New quantity is required');
        }
        
        const sanitizedName = itemName.trim();
        if (sanitizedName.length === 0) {
            throw new Error('Item name cannot be empty');
        }
        
        // Find the item for notification
        const item = this.shoppingList.findItemByName(sanitizedName);
        
        // Update quantity
        const wasUpdated = this.shoppingList.updateQuantity(sanitizedName, String(newQuantity));
        
        if (wasUpdated) {
            // Save to storage
            this.saveList();
            
            // Notify listeners
            this.notifyListeners('itemUpdated', item);
        }
        
        return wasUpdated;
    }
    
    /**
     * Mark an item as completed or uncompleted
     * @param {string} itemName - Name of the item
     * @param {boolean} completed - Completion status
     * @returns {boolean} True if item was updated, false if not found
     */
    markItemCompleted(itemName, completed = true) {
        if (!itemName || typeof itemName !== 'string') {
            throw new Error('Item name is required and must be a string');
        }
        
        const sanitizedName = itemName.trim();
        if (sanitizedName.length === 0) {
            throw new Error('Item name cannot be empty');
        }
        
        // Find the item for notification
        const item = this.shoppingList.findItemByName(sanitizedName);
        
        // Update completion status
        const wasUpdated = this.shoppingList.markItemCompleted(sanitizedName, completed);
        
        if (wasUpdated) {
            // Save to storage
            this.saveList();
            
            // Notify listeners
            this.notifyListeners('itemUpdated', item);
        }
        
        return wasUpdated;
    }
    
    /**
     * Get the current shopping list
     * @returns {ShoppingList} Current shopping list
     */
    getList() {
        return this.shoppingList;
    }
    
    /**
     * Get all items in the list
     * @returns {ShoppingItem[]} Array of shopping items
     */
    getItems() {
        return this.shoppingList.items;
    }
    
    /**
     * Get items grouped by category
     * @returns {Object} Object with categories as keys and item arrays as values
     */
    getItemsGroupedByCategory() {
        return this.shoppingList.getItemsGroupedByCategory();
    }
    
    /**
     * Get all unique categories in the list
     * @returns {string[]} Array of category names
     */
    getCategories() {
        return this.shoppingList.getCategories();
    }
    
    /**
     * Get the total number of items
     * @returns {number} Total item count
     */
    getItemCount() {
        return this.shoppingList.getItemCount();
    }
    
    /**
     * Get the number of completed items
     * @returns {number} Completed item count
     */
    getCompletedCount() {
        return this.shoppingList.getCompletedCount();
    }
    
    /**
     * Check if the list is empty
     * @returns {boolean} True if list is empty
     */
    isEmpty() {
        return this.shoppingList.isEmpty();
    }
    
    /**
     * Clear all items from the list
     */
    clearList() {
        this.shoppingList.clear();
        this.saveList();
        this.notifyListeners('listCleared', null);
    }
    
    /**
     * Find an item by name
     * @param {string} itemName - Name of the item to find
     * @returns {ShoppingItem|null} Found item or null
     */
    findItem(itemName) {
        if (!itemName || typeof itemName !== 'string') {
            return null;
        }
        
        return this.shoppingList.findItemByName(itemName.trim());
    }
    
    /**
     * Find an item by ID
     * @param {string} itemId - ID of the item to find
     * @returns {ShoppingItem|null} Found item or null
     */
    findItemById(itemId) {
        if (!itemId || typeof itemId !== 'string') {
            return null;
        }
        
        return this.shoppingList.findItemById(itemId);
    }
    
    /**
     * Categorize an item using the category manager
     * @param {string} itemName - Name of the item to categorize
     * @returns {string} Category name
     */
    categorizeItem(itemName) {
        if (!this.categoryManager || !itemName) {
            return 'miscellaneous';
        }
        
        return this.categoryManager.categorizeItem(itemName);
    }
    
    /**
     * Sort items by a given criteria
     * @param {string} criteria - Sort criteria ('name', 'category', 'dateAdded', 'quantity')
     * @param {boolean} ascending - Sort direction (default: true)
     */
    sortItems(criteria = 'name', ascending = true) {
        this.shoppingList.sortItems(criteria, ascending);
        this.saveList();
        this.notifyListeners('itemUpdated', null);
    }
    
    /**
     * Save the shopping list to storage
     * @returns {boolean} True if save was successful
     */
    saveList() {
        try {
            return this.storage.saveList(this.shoppingList);
        } catch (error) {
            console.error('Failed to save shopping list:', error);
            return false;
        }
    }
    
    /**
     * Load the shopping list from storage
     * @returns {ShoppingList} Loaded shopping list
     */
    loadList() {
        try {
            return this.storage.loadList();
        } catch (error) {
            console.error('Failed to load shopping list:', error);
            return new ShoppingList();
        }
    }
    
    /**
     * Add event listener for list changes
     * @param {string} event - Event type ('itemAdded', 'itemRemoved', 'itemUpdated', 'listCleared')
     * @param {Function} callback - Callback function
     */
    addEventListener(event, callback) {
        if (this.listeners[event] && typeof callback === 'function') {
            this.listeners[event].push(callback);
        }
    }
    
    /**
     * Remove event listener
     * @param {string} event - Event type
     * @param {Function} callback - Callback function to remove
     */
    removeEventListener(event, callback) {
        if (this.listeners[event]) {
            const index = this.listeners[event].indexOf(callback);
            if (index > -1) {
                this.listeners[event].splice(index, 1);
            }
        }
    }
    
    /**
     * Notify all listeners of an event
     * @param {string} event - Event type
     * @param {*} data - Event data
     */
    notifyListeners(event, data) {
        if (this.listeners[event]) {
            this.listeners[event].forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error('Error in event listener:', error);
                }
            });
        }
    }
    
    /**
     * Get statistics about the shopping list
     * @returns {Object} Statistics object
     */
    getStatistics() {
        const items = this.getItems();
        const categories = this.getCategories();
        
        return {
            totalItems: items.length,
            completedItems: this.getCompletedCount(),
            pendingItems: items.length - this.getCompletedCount(),
            categories: categories.length,
            categoryBreakdown: categories.reduce((breakdown, category) => {
                breakdown[category] = this.shoppingList.getItemsByCategory(category).length;
                return breakdown;
            }, {}),
            lastModified: this.shoppingList.lastModified
        };
    }
    
    /**
     * Export the shopping list as a plain object
     * @returns {Object} Plain object representation
     */
    exportList() {
        return this.shoppingList.toJSON();
    }
    
    /**
     * Import a shopping list from a plain object
     * @param {Object} data - Shopping list data
     * @returns {boolean} True if import was successful
     */
    importList(data) {
        try {
            this.shoppingList = ShoppingList.fromJSON(data);
            this.saveList();
            this.notifyListeners('listCleared', null); // Notify that list was replaced
            return true;
        } catch (error) {
            console.error('Failed to import shopping list:', error);
            return false;
        }
    }
}

