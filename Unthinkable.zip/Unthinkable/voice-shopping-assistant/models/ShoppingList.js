/**
 * ShoppingList - Data model for managing collections of shopping items
 * Handles list operations, categorization, and persistence
 */

import { ShoppingItem } from './ShoppingItem.js';

export class ShoppingList {
    /**
     * Create a new shopping list
     * @param {ShoppingItem[]} items - Initial items (optional)
     */
    constructor(items = []) {
        this.items = [];
        this.lastModified = new Date();
        this.categories = new Set();
        
        // Add initial items if provided
        if (Array.isArray(items)) {
            items.forEach(item => {
                if (item instanceof ShoppingItem) {
                    this.addItem(item);
                }
            });
        }
    }
    
    /**
     * Add an item to the shopping list
     * @param {ShoppingItem|string} item - Item to add or item name
     * @param {string} quantity - Quantity (if item is a string)
     * @param {string} category - Category (if item is a string)
     * @returns {ShoppingItem} The added item
     */
    addItem(item, quantity = "1", category = "miscellaneous") {
        let shoppingItem;
        
        if (item instanceof ShoppingItem) {
            shoppingItem = item;
        } else if (typeof item === 'string') {
            shoppingItem = new ShoppingItem(item, quantity, category);
        } else {
            throw new Error('Item must be a ShoppingItem instance or string');
        }
        
        // Check if item already exists
        const existingItem = this.findItemByName(shoppingItem.name);
        if (existingItem) {
            // Update quantity of existing item
            const currentQty = this.parseQuantity(existingItem.quantity);
            const addQty = this.parseQuantity(shoppingItem.quantity);
            const newQty = currentQty + addQty;
            existingItem.updateQuantity(newQty.toString());
            this.updateModified();
            return existingItem;
        }
        
        // Add new item
        this.items.push(shoppingItem);
        this.categories.add(shoppingItem.category);
        this.updateModified();
        
        return shoppingItem;
    }
    
    /**
     * Remove an item from the shopping list
     * @param {string|ShoppingItem} item - Item name or ShoppingItem instance
     * @returns {boolean} True if item was removed
     */
    removeItem(item) {
        const itemName = typeof item === 'string' ? item : item.name;
        const index = this.items.findIndex(listItem => 
            listItem.name.toLowerCase() === itemName.toLowerCase()
        );
        
        if (index === -1) {
            return false;
        }
        
        this.items.splice(index, 1);
        this.updateCategories();
        this.updateModified();
        return true;
    }
    
    /**
     * Remove an item by its ID
     * @param {string} id - Item ID
     * @returns {boolean} True if item was removed
     */
    removeItemById(id) {
        const index = this.items.findIndex(item => item.id === id);
        
        if (index === -1) {
            return false;
        }
        
        this.items.splice(index, 1);
        this.updateCategories();
        this.updateModified();
        return true;
    }
    
    /**
     * Update the quantity of an item
     * @param {string} itemName - Name of the item
     * @param {string|number} newQuantity - New quantity
     * @returns {boolean} True if item was updated
     */
    updateQuantity(itemName, newQuantity) {
        const item = this.findItemByName(itemName);
        if (!item) {
            return false;
        }
        
        item.updateQuantity(newQuantity);
        this.updateModified();
        return true;
    }
    
    /**
     * Find an item by name (case-insensitive)
     * @param {string} name - Item name to search for
     * @returns {ShoppingItem|null} Found item or null
     */
    findItemByName(name) {
        return this.items.find(item => 
            item.name.toLowerCase() === name.toLowerCase()
        ) || null;
    }
    
    /**
     * Find an item by ID
     * @param {string} id - Item ID to search for
     * @returns {ShoppingItem|null} Found item or null
     */
    findItemById(id) {
        return this.items.find(item => item.id === id) || null;
    }
    
    /**
     * Get all items in a specific category
     * @param {string} category - Category name
     * @returns {ShoppingItem[]} Items in the category
     */
    getItemsByCategory(category) {
        return this.items.filter(item => 
            item.category.toLowerCase() === category.toLowerCase()
        );
    }
    
    /**
     * Get items grouped by category
     * @returns {Object} Object with categories as keys and item arrays as values
     */
    getItemsGroupedByCategory() {
        const grouped = {};
        
        this.items.forEach(item => {
            if (!grouped[item.category]) {
                grouped[item.category] = [];
            }
            grouped[item.category].push(item);
        });
        
        return grouped;
    }
    
    /**
     * Get all unique categories in the list
     * @returns {string[]} Array of category names
     */
    getCategories() {
        return Array.from(this.categories).sort();
    }
    
    /**
     * Get the total number of items
     * @returns {number} Total item count
     */
    getItemCount() {
        return this.items.length;
    }
    
    /**
     * Get the number of completed items
     * @returns {number} Completed item count
     */
    getCompletedCount() {
        return this.items.filter(item => item.completed).length;
    }
    
    /**
     * Check if the list is empty
     * @returns {boolean} True if list is empty
     */
    isEmpty() {
        return this.items.length === 0;
    }
    
    /**
     * Clear all items from the list
     */
    clear() {
        this.items = [];
        this.categories.clear();
        this.updateModified();
    }
    
    /**
     * Mark an item as completed
     * @param {string} itemName - Name of the item
     * @param {boolean} completed - Completion status
     * @returns {boolean} True if item was updated
     */
    markItemCompleted(itemName, completed = true) {
        const item = this.findItemByName(itemName);
        if (!item) {
            return false;
        }
        
        item.setCompleted(completed);
        this.updateModified();
        return true;
    }
    
    /**
     * Get all completed items
     * @returns {ShoppingItem[]} Array of completed items
     */
    getCompletedItems() {
        return this.items.filter(item => item.completed);
    }
    
    /**
     * Get all uncompleted items
     * @returns {ShoppingItem[]} Array of uncompleted items
     */
    getUncompletedItems() {
        return this.items.filter(item => !item.completed);
    }
    
    /**
     * Parse quantity string to number (for arithmetic operations)
     * @param {string} quantity - Quantity string
     * @returns {number} Numeric quantity (defaults to 1 if can't parse)
     */
    parseQuantity(quantity) {
        const match = quantity.match(/^(\d+(?:\.\d+)?)/);
        return match ? parseFloat(match[1]) : 1;
    }
    
    /**
     * Update the categories set based on current items
     */
    updateCategories() {
        this.categories.clear();
        this.items.forEach(item => {
            this.categories.add(item.category);
        });
    }
    
    /**
     * Update the last modified timestamp
     */
    updateModified() {
        this.lastModified = new Date();
    }
    
    /**
     * Convert shopping list to plain object for storage
     * @returns {Object} Plain object representation
     */
    toJSON() {
        return {
            items: this.items.map(item => item.toJSON()),
            lastModified: this.lastModified.toISOString(),
            categories: Array.from(this.categories)
        };
    }
    
    /**
     * Create ShoppingList from plain object
     * @param {Object} data - Plain object data
     * @returns {ShoppingList} New ShoppingList instance
     */
    static fromJSON(data) {
        if (!data || typeof data !== 'object') {
            return new ShoppingList();
        }
        
        const items = [];
        if (Array.isArray(data.items)) {
            data.items.forEach(itemData => {
                try {
                    items.push(ShoppingItem.fromJSON(itemData));
                } catch (error) {
                    console.warn('Failed to load shopping item:', error);
                }
            });
        }
        
        const list = new ShoppingList(items);
        
        if (data.lastModified) {
            list.lastModified = new Date(data.lastModified);
        }
        
        return list;
    }
    
    /**
     * Create a copy of this shopping list
     * @returns {ShoppingList} New ShoppingList instance
     */
    clone() {
        return ShoppingList.fromJSON(this.toJSON());
    }
    
    /**
     * Sort items by a given criteria
     * @param {string} criteria - Sort criteria ('name', 'category', 'dateAdded', 'quantity')
     * @param {boolean} ascending - Sort direction (default: true)
     */
    sortItems(criteria = 'name', ascending = true) {
        this.items.sort((a, b) => {
            let valueA, valueB;
            
            switch (criteria) {
                case 'name':
                    valueA = a.name.toLowerCase();
                    valueB = b.name.toLowerCase();
                    break;
                case 'category':
                    valueA = a.category.toLowerCase();
                    valueB = b.category.toLowerCase();
                    break;
                case 'dateAdded':
                    valueA = a.dateAdded;
                    valueB = b.dateAdded;
                    break;
                case 'quantity':
                    valueA = this.parseQuantity(a.quantity);
                    valueB = this.parseQuantity(b.quantity);
                    break;
                default:
                    valueA = a.name.toLowerCase();
                    valueB = b.name.toLowerCase();
            }
            
            if (valueA < valueB) return ascending ? -1 : 1;
            if (valueA > valueB) return ascending ? 1 : -1;
            return 0;
        });
        
        this.updateModified();
    }
}