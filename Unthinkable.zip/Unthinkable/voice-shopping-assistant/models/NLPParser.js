/**
 * NLPParser - Natural Language Processing for Voice Commands
 * Extracts intent, items, and quantities from voice commands
 */

export class NLPParser {
    constructor(language = 'en-US') {
        this.currentLanguage = language;
        
        // Initialize unit mappings first
        this.initializeUnitMappings();
        
        // Then initialize patterns
        this.initializePatterns();
    }
    
    /**
     * Initialize unit mappings for normalization
     */
    initializeUnitMappings() {
        // Unit mappings for normalization (multilingual)
        this.unitMappings = {
            // English
            'bottle': 'bottles',
            'can': 'cans',
            'box': 'boxes',
            'bag': 'bags',
            'pound': 'pounds',
            'lb': 'pounds',
            'lbs': 'pounds',
            'ounce': 'ounces',
            'oz': 'ounces',
            'gallon': 'gallons',
            'liter': 'liters',
            'litre': 'liters',
            'kilo': 'kilos',
            'kg': 'kilos',
            'gram': 'grams',
            'g': 'grams',
            
            // French
            'bouteille': 'bouteilles',
            'bouteilles': 'bouteilles',
            'boîte': 'boîtes',
            'boîtes': 'boîtes',
            'sac': 'sacs',
            'sacs': 'sacs',
            'livre': 'livres',
            'livres': 'livres',
            'once': 'onces',
            'onces': 'onces',
            'gallon': 'gallons',
            'gallons': 'gallons',
            'litre': 'litres',
            'litres': 'litres',
            'kilo': 'kilos',
            'kilos': 'kilos',
            'gramme': 'grammes',
            'grammes': 'grammes',
            
            // Spanish
            'botella': 'botellas',
            'botellas': 'botellas',
            'lata': 'latas',
            'latas': 'latas',
            'caja': 'cajas',
            'cajas': 'cajas',
            'bolsa': 'bolsas',
            'bolsas': 'bolsas',
            'libra': 'libras',
            'libras': 'libras',
            'onza': 'onzas',
            'onzas': 'onzas',
            'galón': 'galones',
            'galones': 'galones',
            'litro': 'litros',
            'litros': 'litros',
            'gramo': 'gramos',
            'gramos': 'gramos',
            
            // German
            'flasche': 'flaschen',
            'flaschen': 'flaschen',
            'dose': 'dosen',
            'dosen': 'dosen',
            'schachtel': 'schachteln',
            'schachteln': 'schachteln',
            'tüte': 'tüten',
            'tüten': 'tüten',
            'pfund': 'pfund',
            'unze': 'unzen',
            'unzen': 'unzen',
            'gallone': 'gallonen',
            'gallonen': 'gallonen',
            'liter': 'liter',
            'gramm': 'gramm',
            
            // Italian
            'bottiglia': 'bottiglie',
            'bottiglie': 'bottiglie',
            'lattina': 'lattine',
            'lattine': 'lattine',
            'scatola': 'scatole',
            'scatole': 'scatole',
            'sacchetto': 'sacchetti',
            'sacchetti': 'sacchetti',
            'libbra': 'libbre',
            'libbre': 'libbre',
            'oncia': 'once',
            'once': 'once',
            'gallone': 'galloni',
            'galloni': 'galloni',
            'litro': 'litri',
            'litri': 'litri',
            'chilo': 'chili',
            'chili': 'chili',
            'grammo': 'grammi',
            'grammi': 'grammi',
            
            // Portuguese
            'garrafa': 'garrafas',
            'garrafas': 'garrafas',
            'lata': 'latas',
            'caixa': 'caixas',
            'caixas': 'caixas',
            'saco': 'sacos',
            'sacos': 'sacos',
            'libra': 'libras',
            'onça': 'onças',
            'onças': 'onças',
            'galão': 'galões',
            'galões': 'galões',
            'litro': 'litros',
            'quilo': 'quilos',
            'quilos': 'quilos',
            'grama': 'gramas',
            'gramas': 'gramas'
        };
    }
    
    /**
     * Initialize command patterns for the current language
     */
    initializePatterns() {
        const patterns = this.getLanguagePatterns(this.currentLanguage);
        
        this.addPatterns = patterns.add;
        this.removePatterns = patterns.remove;
        this.updatePatterns = patterns.update;
        this.searchPatterns = patterns.search;
        this.substitutePatterns = patterns.substitute || [];
        this.helpPatterns = patterns.help;
        this.listPatterns = patterns.list;
        this.clearPatterns = patterns.clear;
        this.quantityPatterns = patterns.quantity;
        this.quantityWords = patterns.quantityWords;
    }
    
    /**
     * Get language-specific patterns
     * @param {string} language - Language code
     * @returns {Object} Pattern object for the language
     */
    getLanguagePatterns(language) {
        const langCode = language.split('-')[0];
        
        switch (langCode) {
            case 'es': return this.getSpanishPatterns();
            case 'fr': return this.getFrenchPatterns();
            case 'de': return this.getGermanPatterns();
            case 'it': return this.getItalianPatterns();
            case 'pt': return this.getPortuguesePatterns();
            case 'zh': return this.getChinesePatterns();
            case 'ja': return this.getJapanesePatterns();
            case 'ko': return this.getKoreanPatterns();
            case 'ru': return this.getRussianPatterns();
            case 'ar': return this.getArabicPatterns();
            case 'hi': return this.getHindiPatterns();
            default: return this.getEnglishPatterns();
        }
    }
    
    /**
     * Get English patterns (default)
     * @returns {Object} English patterns
     */
    getEnglishPatterns() {
        return {
            add: [
                /^add\s+(.+)$/i,
                /^i\s+need\s+(.+)$/i,
                /^i\s+want\s+(.+)$/i,
                /^i\s+want\s+to\s+buy\s+(.+)$/i,
                /^buy\s+(.+)$/i,
                /^get\s+(.+)$/i,
                /^put\s+(.+)\s+on\s+(?:my\s+)?list$/i,
                /^(?:can\s+you\s+)?add\s+(.+)\s+to\s+(?:my\s+)?(?:shopping\s+)?list$/i,
                /^add\s+(?:search\s+)?result\s+(\d+)$/i,
                /^choose\s+(?:search\s+)?result\s+(\d+)$/i,
                /^select\s+(?:search\s+)?result\s+(\d+)$/i,
                /^(?:i\s+want\s+)?(?:search\s+)?result\s+(\d+)$/i
            ],
            remove: [
                /^remove\s+(.+)(?:\s+from\s+(?:my\s+)?list)?$/i,
                /^delete\s+(.+)(?:\s+from\s+(?:my\s+)?list)?$/i,
                /^take\s+(.+)\s+off\s+(?:my\s+)?list$/i,
                /^(?:can\s+you\s+)?remove\s+(.+)\s+from\s+(?:my\s+)?(?:shopping\s+)?list$/i,
                /^i\s+don'?t\s+need\s+(.+)(?:\s+anymore)?$/i
            ],
            update: [
                /^change\s+(.+)\s+to\s+(.+)$/i,
                /^update\s+(.+)\s+to\s+(.+)$/i,
                /^make\s+(.+)\s+(.+)$/i,
                /^set\s+(.+)\s+to\s+(.+)$/i
            ],
            search: [
                /^find\s+(?:me\s+)?(.+)$/i,
                /^search\s+for\s+(.+)$/i,
                /^look\s+for\s+(.+)$/i,
                /^show\s+me\s+(.+)$/i
            ],
            substitute: [
                /^(?:what\s+are\s+)?(?:the\s+)?(?:alternatives?|substitutes?)\s+for\s+(.+)$/i,
                /^find\s+(?:me\s+)?(?:alternatives?|substitutes?)\s+for\s+(.+)$/i,
                /^show\s+(?:me\s+)?(?:alternatives?|substitutes?)\s+for\s+(.+)$/i,
                /^(?:can\s+you\s+)?suggest\s+(?:alternatives?|substitutes?)\s+for\s+(.+)$/i,
                /^what\s+can\s+i\s+use\s+instead\s+of\s+(.+)$/i,
                /^replace\s+(.+)\s+with\s+(?:something\s+else|alternative)$/i,
                /^accept\s+(?:alternative|substitute)\s+(\d+)$/i,
                /^use\s+(?:alternative|substitute)\s+(\d+)$/i,
                /^add\s+(?:alternative|substitute)\s+(\d+)$/i,
                /^choose\s+(?:alternative|substitute)\s+(\d+)$/i,
                /^decline\s+(?:all\s+)?(?:alternatives?|substitutes?)$/i,
                /^skip\s+(?:all\s+)?(?:alternatives?|substitutes?)$/i,
                /^no\s+(?:alternatives?|substitutes?)$/i
            ],
            help: [
                /^help$/i,
                /^what\s+can\s+(?:you\s+)?(?:i\s+)?do$/i,
                /^how\s+do\s+(?:i\s+)?(?:you\s+)?(?:use\s+)?(?:this|work)$/i,
                /^(?:what\s+)?commands?$/i,
                /^instructions?$/i,
                /^guide$/i
            ],
            list: [
                /^(?:what'?s\s+)?(?:on\s+)?(?:my\s+)?(?:shopping\s+)?list$/i,
                /^read\s+(?:my\s+)?(?:shopping\s+)?list$/i,
                /^show\s+(?:me\s+)?(?:my\s+)?(?:shopping\s+)?list$/i,
                /^tell\s+me\s+what'?s\s+on\s+(?:my\s+)?list$/i,
                /^list\s+(?:my\s+)?items?$/i,
                /^what\s+do\s+i\s+have$/i
            ],
            clear: [
                /^clear\s+(?:my\s+)?(?:shopping\s+)?list$/i,
                /^delete\s+(?:my\s+)?(?:shopping\s+)?list$/i,
                /^empty\s+(?:my\s+)?(?:shopping\s+)?list$/i,
                /^remove\s+everything$/i,
                /^start\s+over$/i,
                /^reset\s+(?:my\s+)?list$/i
            ],
            quantity: [
                /^(\d+(?:\.\d+)?)\s+(bottles?|cans?|boxes?|bags?|pounds?|lbs?|ounces?|oz|gallons?|liters?|litres?|kilos?|kg|grams?|g)\s+of\s+(.+)$/i, // "2 bottles of water"
                /^(\d+(?:\.\d+)?)\s+(bottles?|cans?|boxes?|bags?|pounds?|lbs?|ounces?|oz|gallons?|liters?|litres?|kilos?|kg|grams?|g)\s+(.+)$/i, // "2 bottles water"
                /^(\d+(?:\.\d+)?)\s+(.+)$/i,                    // "2 apples"
                /^(a\s+dozen|dozen)\s+(.+)$/i,                  // "a dozen eggs"
                /^(a\s+couple\s+of|couple\s+of)\s+(bottles?|cans?|boxes?|bags?)\s+of\s+(.+)$/i, // "a couple of bottles of water"
                /^(a\s+couple\s+of|couple\s+of)\s+(.+)$/i,      // "a couple of bananas"
                /^(half\s+a|half)\s+(.+)$/i,                    // "half a gallon"
                /^(a\s+pound\s+of|pound\s+of)\s+(.+)$/i,        // "a pound of cheese"
                /^(a\s+bag\s+of|bag\s+of)\s+(.+)$/i,            // "a bag of chips"
                /^(a\s+bottle\s+of|bottle\s+of)\s+(.+)$/i,      // "a bottle of water"
                /^(a\s+can\s+of|can\s+of)\s+(.+)$/i,            // "a can of soup"
                /^(a\s+box\s+of|box\s+of)\s+(.+)$/i,            // "a box of cereal"
                /^(a|an|one)\s+(.+)$/i,                         // "a apple", "an orange"
                /^(some|more)\s+(.+)$/i,                        // "some milk", "more bread"
                /^(a\s+few|several|many)\s+(.+)$/i              // "a few apples"
            ],
            quantityWords: {
                'a': '1',
                'an': '1',
                'one': '1',
                'two': '2',
                'three': '3',
                'four': '4',
                'five': '5',
                'six': '6',
                'seven': '7',
                'eight': '8',
                'nine': '9',
                'ten': '10',
                'eleven': '11',
                'twelve': '12',
                'dozen': '12',
                'some': '1',
                'more': '1',
                'a few': '3',
                'several': '4',
                'many': '5',
                'a couple of': '2',
                'couple of': '2',
                'a dozen': '12',
                'half a': '0.5',
                'half': '0.5'
            }
        };
    }
    
    /**
     * Set the language for command parsing
     * @param {string} language - Language code
     */
    setLanguage(language) {
        this.currentLanguage = language;
        this.initializePatterns();
        console.log(`NLPParser language set to: ${language}`);
    }
    
    /**
     * Get Spanish patterns
     * @returns {Object} Spanish patterns
     */
    getSpanishPatterns() {
        return {
            add: [
                /^añadir\s+(.+)$/i,
                /^agregar\s+(.+)$/i,
                /^necesito\s+(.+)$/i,
                /^quiero\s+(.+)$/i,
                /^quiero\s+comprar\s+(.+)$/i,
                /^comprar\s+(.+)$/i,
                /^conseguir\s+(.+)$/i,
                /^poner\s+(.+)\s+en\s+(?:mi\s+)?lista$/i,
                /^(?:puedes\s+)?añadir\s+(.+)\s+a\s+(?:mi\s+)?(?:lista\s+de\s+)?compras?$/i
            ],
            remove: [
                /^quitar\s+(.+)(?:\s+de\s+(?:mi\s+)?lista)?$/i,
                /^eliminar\s+(.+)(?:\s+de\s+(?:mi\s+)?lista)?$/i,
                /^borrar\s+(.+)(?:\s+de\s+(?:mi\s+)?lista)?$/i,
                /^sacar\s+(.+)\s+de\s+(?:mi\s+)?lista$/i,
                /^no\s+necesito\s+(.+)(?:\s+más)?$/i
            ],
            update: [
                /^cambiar\s+(.+)\s+a\s+(.+)$/i,
                /^actualizar\s+(.+)\s+a\s+(.+)$/i,
                /^hacer\s+(.+)\s+(.+)$/i,
                /^poner\s+(.+)\s+como\s+(.+)$/i
            ],
            search: [
                /^buscar\s+(?:me\s+)?(.+)$/i,
                /^encontrar\s+(.+)$/i,
                /^mostrar\s+(?:me\s+)?(.+)$/i,
                /^ver\s+(.+)$/i
            ],
            substitute: [
                /^(?:cuáles\s+son\s+)?(?:las\s+)?(?:alternativas?|sustitutos?)\s+(?:para|de)\s+(.+)$/i,
                /^buscar\s+(?:me\s+)?(?:alternativas?|sustitutos?)\s+(?:para|de)\s+(.+)$/i,
                /^mostrar\s+(?:me\s+)?(?:alternativas?|sustitutos?)\s+(?:para|de)\s+(.+)$/i,
                /^(?:puedes\s+)?sugerir\s+(?:alternativas?|sustitutos?)\s+(?:para|de)\s+(.+)$/i,
                /^qué\s+puedo\s+usar\s+en\s+lugar\s+de\s+(.+)$/i,
                /^reemplazar\s+(.+)\s+con\s+(?:algo\s+más|alternativa)$/i,
                /^aceptar\s+(?:alternativa|sustituto)\s+(\d+)$/i,
                /^usar\s+(?:alternativa|sustituto)\s+(\d+)$/i,
                /^añadir\s+(?:alternativa|sustituto)\s+(\d+)$/i,
                /^elegir\s+(?:alternativa|sustituto)\s+(\d+)$/i,
                /^rechazar\s+(?:todas\s+las\s+)?(?:alternativas?|sustitutos?)$/i,
                /^saltar\s+(?:todas\s+las\s+)?(?:alternativas?|sustitutos?)$/i,
                /^no\s+(?:alternativas?|sustitutos?)$/i
            ],
            help: [
                /^ayuda$/i,
                /^qué\s+puedo\s+hacer$/i,
                /^cómo\s+funciona$/i,
                /^comandos$/i,
                /^instrucciones$/i,
                /^guía$/i
            ],
            list: [
                /^(?:qué\s+hay\s+)?(?:en\s+)?(?:mi\s+)?lista$/i,
                /^leer\s+(?:mi\s+)?lista$/i,
                /^mostrar\s+(?:me\s+)?(?:mi\s+)?lista$/i,
                /^decir\s+(?:me\s+)?qué\s+hay\s+en\s+(?:mi\s+)?lista$/i,
                /^listar\s+(?:mis\s+)?artículos$/i,
                /^qué\s+tengo$/i
            ],
            clear: [
                /^limpiar\s+(?:mi\s+)?lista$/i,
                /^borrar\s+(?:mi\s+)?lista$/i,
                /^vaciar\s+(?:mi\s+)?lista$/i,
                /^quitar\s+todo$/i,
                /^empezar\s+de\s+nuevo$/i,
                /^reiniciar\s+(?:mi\s+)?lista$/i
            ],
            quantity: [
                /^(\d+(?:\.\d+)?)\s+(botellas?|latas?|cajas?|bolsas?|libras?|onzas?|galones?|litros?|kilos?|gramos?)\s+de\s+(.+)$/i,
                /^(\d+(?:\.\d+)?)\s+(botellas?|latas?|cajas?|bolsas?|libras?|onzas?|galones?|litros?|kilos?|gramos?)\s+(.+)$/i,
                /^(\d+(?:\.\d+)?)\s+(.+)$/i,
                /^(una\s+docena|docena)\s+de\s+(.+)$/i,
                /^(un\s+par\s+de|par\s+de)\s+(.+)$/i,
                /^(media|medio)\s+(.+)$/i,
                /^(una?\s+libra\s+de|libra\s+de)\s+(.+)$/i,
                /^(una?\s+bolsa\s+de|bolsa\s+de)\s+(.+)$/i,
                /^(una?\s+botella\s+de|botella\s+de)\s+(.+)$/i,
                /^(una?\s+lata\s+de|lata\s+de)\s+(.+)$/i,
                /^(una?\s+caja\s+de|caja\s+de)\s+(.+)$/i,
                /^(un|una)\s+(.+)$/i,
                /^(algo\s+de|más)\s+(.+)$/i,
                /^(unos?\s+pocos?|varios?|muchos?)\s+(.+)$/i
            ],
            quantityWords: {
                'un': '1', 'una': '1', 'uno': '1',
                'dos': '2', 'tres': '3', 'cuatro': '4', 'cinco': '5',
                'seis': '6', 'siete': '7', 'ocho': '8', 'nueve': '9', 'diez': '10',
                'docena': '12', 'una docena': '12',
                'algo de': '1', 'más': '1',
                'unos pocos': '3', 'varios': '4', 'muchos': '5',
                'un par de': '2', 'par de': '2',
                'media': '0.5', 'medio': '0.5'
            }
        };
    }
    
    /**
     * Get French patterns
     * @returns {Object} French patterns
     */
    getFrenchPatterns() {
        return {
            add: [
                /^ajouter\s+(.+)$/i,
                /^j'ai\s+besoin\s+(?:de\s+)?(.+)$/i,
                /^je\s+veux\s+(.+)$/i,
                /^je\s+veux\s+acheter\s+(.+)$/i,
                /^acheter\s+(.+)$/i,
                /^prendre\s+(.+)$/i,
                /^mettre\s+(.+)\s+sur\s+(?:ma\s+)?liste$/i,
                /^(?:peux-tu\s+)?ajouter\s+(.+)\s+à\s+(?:ma\s+)?(?:liste\s+de\s+)?courses?$/i
            ],
            remove: [
                /^enlever\s+(.+)(?:\s+de\s+(?:ma\s+)?liste)?$/i,
                /^supprimer\s+(?:du\s+|de\s+la\s+|des\s+)?(.+)(?:\s+de\s+(?:ma\s+)?liste)?$/i,
                /^retirer\s+(.+)(?:\s+de\s+(?:ma\s+)?liste)?$/i,
                /^ôter\s+(.+)\s+de\s+(?:ma\s+)?liste$/i,
                /^je\s+n'ai\s+pas\s+besoin\s+(?:de\s+)?(.+)$/i
            ],
            update: [
                /^changer\s+(.+)\s+en\s+(.+)$/i,
                /^modifier\s+(.+)\s+en\s+(.+)$/i,
                /^mettre\s+(.+)\s+à\s+(.+)$/i,
                /^faire\s+(.+)\s+(.+)$/i
            ],
            search: [
                /^chercher\s+(.+)$/i,
                /^trouver\s+(.+)$/i,
                /^rechercher\s+(.+)$/i,
                /^montrer\s+(?:moi\s+)?(.+)$/i
            ],
            substitute: [
                /^(?:quelles\s+sont\s+)?(?:les\s+)?(?:alternatives?|substituts?)\s+(?:pour|de)\s+(.+)$/i,
                /^chercher\s+(?:des\s+)?(?:alternatives?|substituts?)\s+(?:pour|de)\s+(.+)$/i,
                /^montrer\s+(?:moi\s+)?(?:des\s+)?(?:alternatives?|substituts?)\s+(?:pour|de)\s+(.+)$/i,
                /^(?:peux-tu\s+)?suggérer\s+(?:des\s+)?(?:alternatives?|substituts?)\s+(?:pour|de)\s+(.+)$/i,
                /^que\s+puis-je\s+utiliser\s+à\s+la\s+place\s+de\s+(.+)$/i,
                /^remplacer\s+(.+)\s+par\s+(?:autre\s+chose|alternative)$/i,
                /^accepter\s+(?:alternative|substitut)\s+(\d+)$/i,
                /^utiliser\s+(?:alternative|substitut)\s+(\d+)$/i,
                /^ajouter\s+(?:alternative|substitut)\s+(\d+)$/i,
                /^choisir\s+(?:alternative|substitut)\s+(\d+)$/i,
                /^refuser\s+(?:toutes\s+les\s+)?(?:alternatives?|substituts?)$/i,
                /^passer\s+(?:toutes\s+les\s+)?(?:alternatives?|substituts?)$/i,
                /^pas\s+(?:d'alternatives?|de\s+substituts?)$/i
            ],
            help: [
                /^aide$/i,
                /^que\s+puis-je\s+faire$/i,
                /^comment\s+ça\s+marche$/i,
                /^commandes$/i,
                /^instructions$/i,
                /^guide$/i
            ],
            list: [
                /^(?:qu'est-ce\s+qui\s+est\s+)?(?:sur\s+)?(?:ma\s+)?liste$/i,
                /^lire\s+(?:ma\s+)?liste$/i,
                /^montrer\s+(?:moi\s+)?(?:ma\s+)?liste$/i,
                /^dire\s+(?:moi\s+)?ce\s+qui\s+est\s+sur\s+(?:ma\s+)?liste$/i,
                /^lister\s+(?:mes\s+)?articles$/i,
                /^qu'est-ce\s+que\s+j'ai$/i
            ],
            clear: [
                /^vider\s+(?:ma\s+)?liste$/i,
                /^effacer\s+(?:ma\s+)?liste$/i,
                /^supprimer\s+(?:ma\s+)?liste$/i,
                /^enlever\s+tout$/i,
                /^recommencer$/i,
                /^remettre\s+à\s+zéro\s+(?:ma\s+)?liste$/i
            ],
            quantity: [
                /^(\d+(?:\.\d+)?)\s+(bouteilles?|boîtes?|sacs?|livres?|onces?|gallons?|litres?|kilos?|grammes?)\s+de\s+(.+)$/i,
                /^(\d+(?:\.\d+)?)\s+(bouteilles?|boîtes?|sacs?|livres?|onces?|gallons?|litres?|kilos?|grammes?)\s+(.+)$/i,
                /^(\d+(?:\.\d+)?)\s+(.+)$/i,
                /^(une\s+douzaine|douzaine)\s+de\s+(.+)$/i,
                /^(quelques?|plusieurs)\s+(.+)$/i,
                /^(un\s+demi|demi)\s+(.+)$/i,
                /^(une?\s+livre\s+de|livre\s+de)\s+(.+)$/i,
                /^(un\s+sac\s+de|sac\s+de)\s+(.+)$/i,
                /^(une?\s+bouteille\s+de|bouteille\s+de)\s+(.+)$/i,
                /^(une?\s+boîte\s+de|boîte\s+de)\s+(.+)$/i,
                /^(un|une)\s+(.+)$/i,
                /^(du|de\s+la|des)\s+(.+)$/i,
                /^(quelques?|plusieurs|beaucoup\s+de)\s+(.+)$/i
            ],
            quantityWords: {
                'un': '1', 'une': '1',
                'deux': '2', 'trois': '3', 'quatre': '4', 'cinq': '5',
                'six': '6', 'sept': '7', 'huit': '8', 'neuf': '9', 'dix': '10',
                'douzaine': '12', 'une douzaine': '12',
                'du': '1', 'de la': '1', 'des': '1',
                'quelques': '3', 'plusieurs': '4', 'beaucoup de': '5',
                'un demi': '0.5', 'demi': '0.5'
            }
        };
    }
    
    /**
     * Get German patterns
     * @returns {Object} German patterns
     */
    getGermanPatterns() {
        return {
            add: [
                /^(.+)\s+hinzufügen$/i,
                /^hinzufügen\s+(.+)$/i,
                /^ich\s+brauche\s+(.+)$/i,
                /^ich\s+möchte\s+(.+)$/i,
                /^ich\s+will\s+(.+)\s+kaufen$/i,
                /^kaufen\s+(.+)$/i,
                /^holen\s+(.+)$/i,
                /^(.+)\s+auf\s+(?:meine\s+)?liste\s+setzen$/i,
                /^(?:kannst\s+du\s+)?(.+)\s+zu\s+(?:meiner\s+)?(?:einkaufs)?liste\s+hinzufügen$/i
            ],
            remove: [
                /^(.+)\s+entfernen(?:\s+von\s+(?:meiner\s+)?liste)?$/i,
                /^entfernen\s+(.+)(?:\s+von\s+(?:meiner\s+)?liste)?$/i,
                /^löschen\s+(.+)(?:\s+von\s+(?:meiner\s+)?liste)?$/i,
                /^streichen\s+(.+)(?:\s+von\s+(?:meiner\s+)?liste)?$/i,
                /^(.+)\s+von\s+(?:meiner\s+)?liste\s+nehmen$/i,
                /^ich\s+brauche\s+(.+)\s+nicht\s+mehr$/i
            ],
            update: [
                /^ändern\s+(.+)\s+zu\s+(.+)$/i,
                /^(.+)\s+zu\s+(.+)\s+ändern$/i,
                /^(.+)\s+auf\s+(.+)\s+setzen$/i,
                /^machen\s+(.+)\s+(.+)$/i
            ],
            search: [
                /^suchen\s+(.+)$/i,
                /^finden\s+(.+)$/i,
                /^zeigen\s+(?:mir\s+)?(.+)$/i,
                /^schauen\s+nach\s+(.+)$/i
            ],
            substitute: [
                /^(?:was\s+sind\s+)?(?:die\s+)?(?:alternativen?|ersatz)\s+(?:für|von)\s+(.+)$/i,
                /^finden\s+(?:mir\s+)?(?:alternativen?|ersatz)\s+(?:für|von)\s+(.+)$/i,
                /^zeigen\s+(?:mir\s+)?(?:alternativen?|ersatz)\s+(?:für|von)\s+(.+)$/i,
                /^(?:kannst\s+du\s+)?(?:alternativen?|ersatz)\s+(?:für|von)\s+(.+)\s+vorschlagen$/i,
                /^was\s+kann\s+ich\s+anstatt\s+(.+)\s+verwenden$/i,
                /^(.+)\s+durch\s+(?:etwas\s+anderes|alternative)\s+ersetzen$/i,
                /^(?:alternative|ersatz)\s+(\d+)\s+akzeptieren$/i,
                /^(?:alternative|ersatz)\s+(\d+)\s+verwenden$/i,
                /^(?:alternative|ersatz)\s+(\d+)\s+hinzufügen$/i,
                /^(?:alternative|ersatz)\s+(\d+)\s+wählen$/i,
                /^(?:alle\s+)?(?:alternativen?|ersatz)\s+ablehnen$/i,
                /^(?:alle\s+)?(?:alternativen?|ersatz)\s+überspringen$/i,
                /^keine\s+(?:alternativen?|ersatz)$/i
            ],
            help: [
                /^hilfe$/i,
                /^was\s+kann\s+ich\s+tun$/i,
                /^wie\s+funktioniert\s+das$/i,
                /^befehle$/i,
                /^anweisungen$/i,
                /^anleitung$/i
            ],
            list: [
                /^(?:was\s+ist\s+)?(?:auf\s+)?(?:meiner\s+)?liste$/i,
                /^liste\s+vorlesen$/i,
                /^zeigen\s+(?:mir\s+)?(?:meine\s+)?liste$/i,
                /^sagen\s+(?:mir\s+)?was\s+auf\s+(?:meiner\s+)?liste\s+steht$/i,
                /^artikel\s+auflisten$/i,
                /^was\s+habe\s+ich$/i
            ],
            clear: [
                /^liste\s+leeren$/i,
                /^liste\s+löschen$/i,
                /^alles\s+entfernen$/i,
                /^von\s+vorne\s+anfangen$/i,
                /^liste\s+zurücksetzen$/i
            ],
            quantity: [
                /^(\d+(?:\.\d+)?)\s+(flaschen?|dosen?|schachteln?|tüten?|pfund|unzen?|gallonen?|liter|kilos?|gramm)\s+(.+)$/i,
                /^(\d+(?:\.\d+)?)\s+(.+)$/i,
                /^(ein\s+dutzend|dutzend)\s+(.+)$/i,
                /^(ein\s+paar|paar)\s+(.+)$/i,
                /^(ein\s+halbes?|halb)\s+(.+)$/i,
                /^(ein\s+pfund|pfund)\s+(.+)$/i,
                /^(eine?\s+tüte|tüte)\s+(.+)$/i,
                /^(eine?\s+flasche|flasche)\s+(.+)$/i,
                /^(eine?\s+dose|dose)\s+(.+)$/i,
                /^(eine?\s+schachtel|schachtel)\s+(.+)$/i,
                /^(ein|eine)\s+(.+)$/i,
                /^(etwas|mehr)\s+(.+)$/i,
                /^(einige|mehrere|viele)\s+(.+)$/i
            ],
            quantityWords: {
                'ein': '1', 'eine': '1',
                'zwei': '2', 'drei': '3', 'vier': '4', 'fünf': '5',
                'sechs': '6', 'sieben': '7', 'acht': '8', 'neun': '9', 'zehn': '10',
                'dutzend': '12', 'ein dutzend': '12',
                'etwas': '1', 'mehr': '1',
                'einige': '3', 'mehrere': '4', 'viele': '5',
                'ein paar': '2', 'paar': '2',
                'ein halbes': '0.5', 'halb': '0.5'
            }
        };
    }
    
    /**
     * Get Italian patterns
     * @returns {Object} Italian patterns
     */
    getItalianPatterns() {
        return {
            add: [
                /^aggiungere\s+(.+)$/i,
                /^ho\s+bisogno\s+di\s+(.+)$/i,
                /^voglio\s+(.+)$/i,
                /^voglio\s+comprare\s+(.+)$/i,
                /^comprare\s+(.+)$/i,
                /^prendere\s+(.+)$/i,
                /^mettere\s+(.+)\s+nella\s+lista$/i,
                /^(?:puoi\s+)?aggiungere\s+(.+)\s+alla\s+(?:mia\s+)?lista$/i
            ],
            remove: [
                /^rimuovere\s+(.+)(?:\s+dalla\s+lista)?$/i,
                /^eliminare\s+(.+)(?:\s+dalla\s+lista)?$/i,
                /^cancellare\s+(.+)(?:\s+dalla\s+lista)?$/i,
                /^togliere\s+(.+)\s+dalla\s+lista$/i,
                /^non\s+ho\s+bisogno\s+di\s+(.+)$/i
            ],
            update: [
                /^cambiare\s+(.+)\s+in\s+(.+)$/i,
                /^modificare\s+(.+)\s+in\s+(.+)$/i,
                /^impostare\s+(.+)\s+a\s+(.+)$/i,
                /^fare\s+(.+)\s+(.+)$/i
            ],
            search: [
                /^cercare\s+(.+)$/i,
                /^trovare\s+(.+)$/i,
                /^mostrare\s+(?:mi\s+)?(.+)$/i,
                /^vedere\s+(.+)$/i
            ],
            substitute: [
                /^(?:quali\s+sono\s+)?(?:le\s+)?(?:alternative|sostituti)\s+(?:per|di)\s+(.+)$/i,
                /^cercare\s+(?:delle\s+)?(?:alternative|sostituti)\s+(?:per|di)\s+(.+)$/i,
                /^mostrare\s+(?:mi\s+)?(?:delle\s+)?(?:alternative|sostituti)\s+(?:per|di)\s+(.+)$/i,
                /^(?:puoi\s+)?suggerire\s+(?:delle\s+)?(?:alternative|sostituti)\s+(?:per|di)\s+(.+)$/i,
                /^cosa\s+posso\s+usare\s+al\s+posto\s+di\s+(.+)$/i,
                /^sostituire\s+(.+)\s+con\s+(?:qualcos'altro|alternativa)$/i,
                /^accettare\s+(?:alternativa|sostituto)\s+(\d+)$/i,
                /^usare\s+(?:alternativa|sostituto)\s+(\d+)$/i,
                /^aggiungere\s+(?:alternativa|sostituto)\s+(\d+)$/i,
                /^scegliere\s+(?:alternativa|sostituto)\s+(\d+)$/i,
                /^rifiutare\s+(?:tutte\s+le\s+)?(?:alternative|sostituti)$/i,
                /^saltare\s+(?:tutte\s+le\s+)?(?:alternative|sostituti)$/i,
                /^nessuna?\s+(?:alternativa|sostituto)$/i
            ],
            help: [
                /^aiuto$/i,
                /^cosa\s+posso\s+fare$/i,
                /^come\s+funziona$/i,
                /^comandi$/i,
                /^istruzioni$/i,
                /^guida$/i
            ],
            list: [
                /^(?:cosa\s+c'è\s+)?(?:nella\s+)?(?:mia\s+)?lista$/i,
                /^(?:la\s+)?(?:mia\s+)?lista$/i,
                /^leggere\s+(?:la\s+)?(?:mia\s+)?lista$/i,
                /^mostrare\s+(?:mi\s+)?(?:la\s+)?(?:mia\s+)?lista$/i,
                /^dire\s+(?:mi\s+)?cosa\s+c'è\s+nella\s+(?:mia\s+)?lista$/i,
                /^elencare\s+(?:i\s+miei\s+)?articoli$/i,
                /^cosa\s+ho$/i
            ],
            clear: [
                /^svuotare\s+(?:la\s+)?(?:mia\s+)?lista$/i,
                /^cancellare\s+(?:la\s+)?(?:mia\s+)?lista$/i,
                /^eliminare\s+tutto$/i,
                /^ricominciare$/i,
                /^resettare\s+(?:la\s+)?(?:mia\s+)?lista$/i
            ],
            quantity: [
                /^(\d+(?:\.\d+)?)\s+(bottiglie?|lattine?|scatole?|sacchetti?|libbre?|once?|galloni?|litri?|chili?|grammi?)\s+di\s+(.+)$/i,
                /^(\d+(?:\.\d+)?)\s+(bottiglie?|lattine?|scatole?|sacchetti?|libbre?|once?|galloni?|litri?|chili?|grammi?)\s+(.+)$/i,
                /^(\d+(?:\.\d+)?)\s+(.+)$/i,
                /^(una\s+dozzina|dozzina)\s+di\s+(.+)$/i,
                /^(un\s+paio\s+di|paio\s+di)\s+(.+)$/i,
                /^(mezzo|mezza)\s+(.+)$/i,
                /^(una?\s+libbra\s+di|libbra\s+di)\s+(.+)$/i,
                /^(un\s+sacchetto\s+di|sacchetto\s+di)\s+(.+)$/i,
                /^(una?\s+bottiglia\s+di|bottiglia\s+di)\s+(.+)$/i,
                /^(una?\s+lattina\s+di|lattina\s+di)\s+(.+)$/i,
                /^(una?\s+scatola\s+di|scatola\s+di)\s+(.+)$/i,
                /^(un|una)\s+(.+)$/i,
                /^(un\s+po'\s+di|più)\s+(.+)$/i,
                /^(alcuni?|parecchi?|molti?)\s+(.+)$/i
            ],
            quantityWords: {
                'un': '1', 'una': '1', 'uno': '1',
                'due': '2', 'tre': '3', 'quattro': '4', 'cinque': '5',
                'sei': '6', 'sette': '7', 'otto': '8', 'nove': '9', 'dieci': '10',
                'dozzina': '12', 'una dozzina': '12',
                'un po\' di': '1', 'più': '1',
                'alcuni': '3', 'parecchi': '4', 'molti': '5',
                'un paio di': '2', 'paio di': '2',
                'mezzo': '0.5', 'mezza': '0.5'
            }
        };
    }
    
    /**
     * Get Portuguese patterns
     * @returns {Object} Portuguese patterns
     */
    getPortuguesePatterns() {
        return {
            add: [
                /^adicionar\s+(.+)$/i,
                /^preciso\s+(?:de\s+)?(.+)$/i,
                /^quero\s+(.+)$/i,
                /^quero\s+comprar\s+(.+)$/i,
                /^comprar\s+(.+)$/i,
                /^pegar\s+(.+)$/i,
                /^colocar\s+(.+)\s+na\s+lista$/i,
                /^(?:pode\s+)?adicionar\s+(.+)\s+(?:na\s+)?(?:minha\s+)?lista$/i
            ],
            remove: [
                /^remover\s+(.+)(?:\s+da\s+lista)?$/i,
                /^tirar\s+(.+)(?:\s+da\s+lista)?$/i,
                /^excluir\s+(.+)(?:\s+da\s+lista)?$/i,
                /^apagar\s+(.+)(?:\s+da\s+lista)?$/i,
                /^não\s+preciso\s+(?:de\s+)?(.+)(?:\s+mais)?$/i
            ],
            update: [
                /^mudar\s+(.+)\s+para\s+(.+)$/i,
                /^alterar\s+(.+)\s+para\s+(.+)$/i,
                /^definir\s+(.+)\s+como\s+(.+)$/i,
                /^fazer\s+(.+)\s+(.+)$/i
            ],
            search: [
                /^procurar\s+(.+)$/i,
                /^buscar\s+(.+)$/i,
                /^encontrar\s+(.+)$/i,
                /^mostrar\s+(?:me\s+)?(.+)$/i
            ],
            substitute: [
                /^(?:quais\s+são\s+)?(?:as\s+)?(?:alternativas?|substitutos?)\s+(?:para|de)\s+(.+)$/i,
                /^procurar\s+(?:por\s+)?(?:alternativas?|substitutos?)\s+(?:para|de)\s+(.+)$/i,
                /^mostrar\s+(?:me\s+)?(?:as\s+)?(?:alternativas?|substitutos?)\s+(?:para|de)\s+(.+)$/i,
                /^(?:pode\s+)?sugerir\s+(?:alternativas?|substitutos?)\s+(?:para|de)\s+(.+)$/i,
                /^o\s+que\s+posso\s+usar\s+no\s+lugar\s+de\s+(.+)$/i,
                /^substituir\s+(.+)\s+por\s+(?:outra\s+coisa|alternativa)$/i,
                /^aceitar\s+(?:alternativa|substituto)\s+(\d+)$/i,
                /^usar\s+(?:alternativa|substituto)\s+(\d+)$/i,
                /^adicionar\s+(?:alternativa|substituto)\s+(\d+)$/i,
                /^escolher\s+(?:alternativa|substituto)\s+(\d+)$/i,
                /^recusar\s+(?:todas\s+as\s+)?(?:alternativas?|substitutos?)$/i,
                /^pular\s+(?:todas\s+as\s+)?(?:alternativas?|substitutos?)$/i,
                /^nenhuma?\s+(?:alternativa|substituto)$/i
            ],
            help: [
                /^ajuda$/i,
                /^o\s+que\s+posso\s+fazer$/i,
                /^como\s+funciona$/i,
                /^comandos$/i,
                /^instruções$/i,
                /^guia$/i
            ],
            list: [
                /^(?:o\s+que\s+tem\s+)?(?:na\s+)?(?:minha\s+)?lista$/i,
                /^ler\s+(?:a\s+)?(?:minha\s+)?lista$/i,
                /^mostrar\s+(?:me\s+)?(?:a\s+)?(?:minha\s+)?lista$/i,
                /^dizer\s+(?:me\s+)?o\s+que\s+tem\s+na\s+(?:minha\s+)?lista$/i,
                /^listar\s+(?:meus\s+)?itens$/i,
                /^o\s+que\s+eu\s+tenho$/i
            ],
            clear: [
                /^limpar\s+(?:a\s+)?(?:minha\s+)?lista$/i,
                /^apagar\s+(?:a\s+)?(?:minha\s+)?lista$/i,
                /^excluir\s+(?:a\s+)?(?:minha\s+)?lista$/i,
                /^remover\s+tudo$/i,
                /^começar\s+de\s+novo$/i,
                /^resetar\s+(?:a\s+)?(?:minha\s+)?lista$/i
            ],
            quantity: [
                /^(\d+(?:\.\d+)?)\s+(garrafas?|latas?|caixas?|sacos?|libras?|onças?|galões?|litros?|quilos?|gramas?)\s+de\s+(.+)$/i,
                /^(\d+(?:\.\d+)?)\s+(garrafas?|latas?|caixas?|sacos?|libras?|onças?|galões?|litros?|quilos?|gramas?)\s+(.+)$/i,
                /^(\d+(?:\.\d+)?)\s+(.+)$/i,
                /^(uma\s+dúzia|dúzia)\s+de\s+(.+)$/i,
                /^(um\s+par\s+de|par\s+de)\s+(.+)$/i,
                /^(meio|meia)\s+(.+)$/i,
                /^(uma?\s+libra\s+de|libra\s+de)\s+(.+)$/i,
                /^(um\s+saco\s+de|saco\s+de)\s+(.+)$/i,
                /^(uma?\s+garrafa\s+de|garrafa\s+de)\s+(.+)$/i,
                /^(uma?\s+lata\s+de|lata\s+de)\s+(.+)$/i,
                /^(uma?\s+caixa\s+de|caixa\s+de)\s+(.+)$/i,
                /^(um|uma)\s+(.+)$/i,
                /^(um\s+pouco\s+de|mais)\s+(.+)$/i,
                /^(alguns?|várias?|muitos?)\s+(.+)$/i
            ],
            quantityWords: {
                'um': '1', 'uma': '1',
                'dois': '2', 'duas': '2', 'três': '3', 'quatro': '4', 'cinco': '5',
                'seis': '6', 'sete': '7', 'oito': '8', 'nove': '9', 'dez': '10',
                'dúzia': '12', 'uma dúzia': '12',
                'um pouco de': '1', 'mais': '1',
                'alguns': '3', 'várias': '4', 'muitos': '5',
                'um par de': '2', 'par de': '2',
                'meio': '0.5', 'meia': '0.5'
            }
        };
    }
    
    /**
     * Get Chinese patterns (simplified)
     * @returns {Object} Chinese patterns
     */
    getChinesePatterns() {
        return {
            add: [
                /^添加\s*(.+)$/i,
                /^加\s*(.+)$/i,
                /^我需要\s*(.+)$/i,
                /^我想要\s*(.+)$/i,
                /^我要买\s*(.+)$/i,
                /^买\s*(.+)$/i,
                /^购买\s*(.+)$/i,
                /^把\s*(.+)\s*加到\s*(?:我的\s*)?(?:购物\s*)?清单$/i
            ],
            remove: [
                /^删除\s*(.+)$/i,
                /^移除\s*(.+)$/i,
                /^去掉\s*(.+)$/i,
                /^从\s*(?:我的\s*)?(?:购物\s*)?清单\s*(?:中\s*)?删除\s*(.+)$/i,
                /^我不需要\s*(.+)$/i
            ],
            update: [
                /^把\s*(.+)\s*改成\s*(.+)$/i,
                /^更改\s*(.+)\s*为\s*(.+)$/i,
                /^修改\s*(.+)\s*为\s*(.+)$/i,
                /^设置\s*(.+)\s*为\s*(.+)$/i
            ],
            search: [
                /^查找\s*(.+)$/i,
                /^搜索\s*(.+)$/i,
                /^寻找\s*(.+)$/i,
                /^显示\s*(.+)$/i
            ],
            help: [
                /^帮助$/i,
                /^我能做什么$/i,
                /^怎么使用$/i,
                /^命令$/i,
                /^指令$/i,
                /^说明$/i
            ],
            list: [
                /^(?:我的\s*)?(?:购物\s*)?清单$/i,
                /^读\s*(?:我的\s*)?(?:购物\s*)?清单$/i,
                /^显示\s*(?:我的\s*)?(?:购物\s*)?清单$/i,
                /^告诉我\s*(?:我的\s*)?清单\s*上有什么$/i,
                /^列出\s*(?:我的\s*)?物品$/i,
                /^我有什么$/i
            ],
            clear: [
                /^清空\s*(?:我的\s*)?(?:购物\s*)?清单$/i,
                /^删除\s*(?:我的\s*)?(?:购物\s*)?清单$/i,
                /^清除所有$/i,
                /^重新开始$/i,
                /^重置\s*(?:我的\s*)?清单$/i
            ],
            quantity: [
                /^(\d+(?:\.\d+)?)\s*(瓶|罐|盒|袋|斤|两|升|公斤|克)\s*(.+)$/i,
                /^(\d+(?:\.\d+)?)\s*(.+)$/i,
                /^(一打|打)\s*(.+)$/i,
                /^(几个|一些|很多)\s*(.+)$/i,
                /^(半)\s*(.+)$/i,
                /^(一|个)\s*(.+)$/i
            ],
            quantityWords: {
                '一': '1', '二': '2', '三': '3', '四': '4', '五': '5',
                '六': '6', '七': '7', '八': '8', '九': '9', '十': '10',
                '打': '12', '一打': '12',
                '一些': '1', '几个': '3', '很多': '5',
                '半': '0.5'
            }
        };
    }
    
    /**
     * Get Japanese patterns
     * @returns {Object} Japanese patterns
     */
    getJapanesePatterns() {
        return {
            add: [
                /^追加\s*(.+)$/i,
                /^(.+)\s*を追加$/i,
                /^(.+)\s*が必要$/i,
                /^(.+)\s*が欲しい$/i,
                /^(.+)\s*を買う$/i,
                /^(.+)\s*を購入$/i,
                /^(.+)\s*をリストに追加$/i
            ],
            remove: [
                /^削除\s*(.+)$/i,
                /^(.+)\s*を削除$/i,
                /^(.+)\s*を除去$/i,
                /^(.+)\s*をリストから削除$/i,
                /^(.+)\s*は必要ない$/i
            ],
            update: [
                /^(.+)\s*を\s*(.+)\s*に変更$/i,
                /^(.+)\s*を\s*(.+)\s*に更新$/i,
                /^(.+)\s*を\s*(.+)\s*に設定$/i
            ],
            search: [
                /^(.+)\s*を検索$/i,
                /^(.+)\s*を探す$/i,
                /^(.+)\s*を見つける$/i,
                /^(.+)\s*を表示$/i
            ],
            help: [
                /^ヘルプ$/i,
                /^何ができる$/i,
                /^使い方$/i,
                /^コマンド$/i,
                /^指示$/i,
                /^ガイド$/i
            ],
            list: [
                /^(?:私の\s*)?(?:買い物\s*)?リスト$/i,
                /^(?:私の\s*)?(?:買い物\s*)?リストを読む$/i,
                /^(?:私の\s*)?(?:買い物\s*)?リストを表示$/i,
                /^リストに何がある$/i,
                /^アイテムを一覧$/i,
                /^何を持っている$/i
            ],
            clear: [
                /^(?:私の\s*)?(?:買い物\s*)?リストをクリア$/i,
                /^(?:私の\s*)?(?:買い物\s*)?リストを削除$/i,
                /^すべて削除$/i,
                /^最初からやり直す$/i,
                /^(?:私の\s*)?リストをリセット$/i
            ],
            quantity: [
                /^(\d+(?:\.\d+)?)\s*(本|個|缶|箱|袋|ポンド|オンス|ガロン|リットル|キロ|グラム)\s*の\s*(.+)$/i,
                /^(\d+(?:\.\d+)?)\s*(.+)$/i,
                /^(ダース|1ダース)\s*の\s*(.+)$/i,
                /^(いくつか|たくさん)\s*の\s*(.+)$/i,
                /^(半分|半)\s*の\s*(.+)$/i,
                /^(一つ|ひとつ)\s*の\s*(.+)$/i
            ],
            quantityWords: {
                '一つ': '1', 'ひとつ': '1', '二つ': '2', 'ふたつ': '2',
                '三つ': '3', 'みっつ': '3', '四つ': '4', 'よっつ': '4',
                '五つ': '5', 'いつつ': '5', 'ダース': '12', '1ダース': '12',
                'いくつか': '3', 'たくさん': '5',
                '半分': '0.5', '半': '0.5'
            }
        };
    }
    
    /**
     * Get Korean patterns
     * @returns {Object} Korean patterns
     */
    getKoreanPatterns() {
        return {
            add: [
                /^추가\s*(.+)$/i,
                /^(.+)\s*추가$/i,
                /^(.+)\s*필요해$/i,
                /^(.+)\s*원해$/i,
                /^(.+)\s*사고\s*싶어$/i,
                /^(.+)\s*구매$/i,
                /^(.+)\s*를\s*목록에\s*추가$/i
            ],
            remove: [
                /^삭제\s*(.+)$/i,
                /^(.+)\s*삭제$/i,
                /^(.+)\s*제거$/i,
                /^(.+)\s*를\s*목록에서\s*삭제$/i,
                /^(.+)\s*필요\s*없어$/i
            ],
            update: [
                /^(.+)\s*를\s*(.+)\s*로\s*변경$/i,
                /^(.+)\s*를\s*(.+)\s*로\s*수정$/i,
                /^(.+)\s*를\s*(.+)\s*로\s*설정$/i
            ],
            search: [
                /^(.+)\s*검색$/i,
                /^(.+)\s*찾기$/i,
                /^(.+)\s*찾아$/i,
                /^(.+)\s*보여줘$/i
            ],
            help: [
                /^도움말$/i,
                /^뭘\s*할\s*수\s*있어$/i,
                /^사용법$/i,
                /^명령어$/i,
                /^지시$/i,
                /^가이드$/i
            ],
            list: [
                /^(?:내\s*)?(?:쇼핑\s*)?목록$/i,
                /^(?:내\s*)?(?:쇼핑\s*)?목록\s*읽어줘$/i,
                /^(?:내\s*)?(?:쇼핑\s*)?목록\s*보여줘$/i,
                /^목록에\s*뭐가\s*있어$/i,
                /^항목\s*나열$/i,
                /^뭘\s*가지고\s*있어$/i
            ],
            clear: [
                /^(?:내\s*)?(?:쇼핑\s*)?목록\s*지워$/i,
                /^(?:내\s*)?(?:쇼핑\s*)?목록\s*삭제$/i,
                /^모두\s*삭제$/i,
                /^처음부터\s*다시$/i,
                /^(?:내\s*)?목록\s*초기화$/i
            ],
            quantity: [
                /^(\d+(?:\.\d+)?)\s*(병|캔|상자|봉지|파운드|온스|갤런|리터|킬로|그램)\s*(.+)$/i,
                /^(\d+(?:\.\d+)?)\s*(.+)$/i,
                /^(한\s*다스|다스)\s*(.+)$/i,
                /^(몇\s*개|많은)\s*(.+)$/i,
                /^(반)\s*(.+)$/i,
                /^(하나|한\s*개)\s*(.+)$/i
            ],
            quantityWords: {
                '하나': '1', '한 개': '1', '둘': '2', '두 개': '2',
                '셋': '3', '세 개': '3', '넷': '4', '네 개': '4',
                '다섯': '5', '다스': '12', '한 다스': '12',
                '몇 개': '3', '많은': '5',
                '반': '0.5'
            }
        };
    }
    
    /**
     * Get Russian patterns
     * @returns {Object} Russian patterns
     */
    getRussianPatterns() {
        return {
            add: [
                /^добавить\s+(.+)$/i,
                /^мне\s+нужно\s+(.+)$/i,
                /^я\s+хочу\s+(.+)$/i,
                /^я\s+хочу\s+купить\s+(.+)$/i,
                /^купить\s+(.+)$/i,
                /^взять\s+(.+)$/i,
                /^положить\s+(.+)\s+в\s+список$/i,
                /^добавить\s+(.+)\s+в\s+(?:мой\s+)?список$/i
            ],
            remove: [
                /^удалить\s+(.+)(?:\s+из\s+списка)?$/i,
                /^убрать\s+(.+)(?:\s+из\s+списка)?$/i,
                /^исключить\s+(.+)(?:\s+из\s+списка)?$/i,
                /^мне\s+не\s+нужно\s+(.+)$/i
            ],
            update: [
                /^изменить\s+(.+)\s+на\s+(.+)$/i,
                /^поменять\s+(.+)\s+на\s+(.+)$/i,
                /^установить\s+(.+)\s+как\s+(.+)$/i
            ],
            search: [
                /^найти\s+(.+)$/i,
                /^искать\s+(.+)$/i,
                /^показать\s+(.+)$/i,
                /^посмотреть\s+(.+)$/i
            ],
            help: [
                /^помощь$/i,
                /^что\s+я\s+могу\s+делать$/i,
                /^как\s+это\s+работает$/i,
                /^команды$/i,
                /^инструкции$/i,
                /^руководство$/i
            ],
            list: [
                /^(?:что\s+в\s+)?(?:моем\s+)?списке$/i,
                /^прочитать\s+(?:мой\s+)?список$/i,
                /^показать\s+(?:мой\s+)?список$/i,
                /^сказать\s+что\s+в\s+(?:моем\s+)?списке$/i,
                /^перечислить\s+(?:мои\s+)?товары$/i,
                /^что\s+у\s+меня\s+есть$/i
            ],
            clear: [
                /^очистить\s+(?:мой\s+)?список$/i,
                /^удалить\s+(?:мой\s+)?список$/i,
                /^убрать\s+все$/i,
                /^начать\s+сначала$/i,
                /^сбросить\s+(?:мой\s+)?список$/i
            ],
            quantity: [
                /^(\d+(?:\.\d+)?)\s+(бутылок?|банок?|коробок?|пакетов?|фунтов?|унций?|галлонов?|литров?|килограммов?|граммов?)\s+(.+)$/i,
                /^(\d+(?:\.\d+)?)\s+(.+)$/i,
                /^(дюжина|дюжину)\s+(.+)$/i,
                /^(пару|несколько|много)\s+(.+)$/i,
                /^(половину|пол)\s+(.+)$/i,
                /^(один|одну)\s+(.+)$/i,
                /^(немного|еще)\s+(.+)$/i
            ],
            quantityWords: {
                'один': '1', 'одну': '1', 'два': '2', 'две': '2',
                'три': '3', 'четыре': '4', 'пять': '5',
                'шесть': '6', 'семь': '7', 'восемь': '8', 'девять': '9', 'десять': '10',
                'дюжина': '12', 'дюжину': '12',
                'немного': '1', 'еще': '1',
                'пару': '2', 'несколько': '3', 'много': '5',
                'половину': '0.5', 'пол': '0.5'
            }
        };
    }
    
    /**
     * Get Arabic patterns
     * @returns {Object} Arabic patterns
     */
    getArabicPatterns() {
        return {
            add: [
                /^إضافة\s+(.+)$/i,
                /^أحتاج\s+(.+)$/i,
                /^أريد\s+(.+)$/i,
                /^أريد\s+شراء\s+(.+)$/i,
                /^شراء\s+(.+)$/i,
                /^أخذ\s+(.+)$/i,
                /^وضع\s+(.+)\s+في\s+القائمة$/i,
                /^إضافة\s+(.+)\s+إلى\s+(?:قائمتي\s+)?القائمة$/i
            ],
            remove: [
                /^حذف\s+(.+)(?:\s+من\s+القائمة)?$/i,
                /^إزالة\s+(.+)(?:\s+من\s+القائمة)?$/i,
                /^إلغاء\s+(.+)(?:\s+من\s+القائمة)?$/i,
                /^لا\s+أحتاج\s+(.+)$/i
            ],
            update: [
                /^تغيير\s+(.+)\s+إلى\s+(.+)$/i,
                /^تحديث\s+(.+)\s+إلى\s+(.+)$/i,
                /^تعيين\s+(.+)\s+كـ\s+(.+)$/i
            ],
            search: [
                /^البحث\s+عن\s+(.+)$/i,
                /^العثور\s+على\s+(.+)$/i,
                /^إظهار\s+(.+)$/i,
                /^عرض\s+(.+)$/i
            ],
            help: [
                /^مساعدة$/i,
                /^ماذا\s+يمكنني\s+أن\s+أفعل$/i,
                /^كيف\s+يعمل$/i,
                /^الأوامر$/i,
                /^التعليمات$/i,
                /^الدليل$/i
            ],
            list: [
                /^(?:ما\s+في\s+)?(?:قائمتي\s+)?القائمة$/i,
                /^قراءة\s+(?:قائمتي\s+)?القائمة$/i,
                /^إظهار\s+(?:قائمتي\s+)?القائمة$/i,
                /^قل\s+لي\s+ما\s+في\s+(?:قائمتي\s+)?القائمة$/i,
                /^سرد\s+(?:عناصري\s+)?العناصر$/i,
                /^ماذا\s+لدي$/i
            ],
            clear: [
                /^مسح\s+(?:قائمتي\s+)?القائمة$/i,
                /^حذف\s+(?:قائمتي\s+)?القائمة$/i,
                /^إزالة\s+كل\s+شيء$/i,
                /^البدء\s+من\s+جديد$/i,
                /^إعادة\s+تعيين\s+(?:قائمتي\s+)?القائمة$/i
            ],
            quantity: [
                /^(\d+(?:\.\d+)?)\s+(زجاجات?|علب|صناديق|أكياس|أرطال|أونصات|جالونات|لترات|كيلوجرامات|جرامات)\s+(.+)$/i,
                /^(\d+(?:\.\d+)?)\s+(.+)$/i,
                /^(دزينة|دستة)\s+(.+)$/i,
                /^(بعض|كثير)\s+(.+)$/i,
                /^(نصف)\s+(.+)$/i,
                /^(واحد|واحدة)\s+(.+)$/i
            ],
            quantityWords: {
                'واحد': '1', 'واحدة': '1', 'اثنان': '2', 'اثنتان': '2',
                'ثلاثة': '3', 'أربعة': '4', 'خمسة': '5',
                'ستة': '6', 'سبعة': '7', 'ثمانية': '8', 'تسعة': '9', 'عشرة': '10',
                'دزينة': '12', 'دستة': '12',
                'بعض': '1', 'كثير': '5',
                'نصف': '0.5'
            }
        };
    }
    
    /**
     * Get Hindi patterns
     * @returns {Object} Hindi patterns
     */
    getHindiPatterns() {
        return {
            add: [
                // Devanagari patterns
                /^(.+)\s+जोड़ना$/i,                    // "ande jodna" (eggs add)
                /^(.+)\s+जोड़ो$/i,                     // "ande jodo" (add eggs)
                /^जोड़ना\s+(.+)$/i,                   // "jodna ande" (add eggs)
                /^जोड़ो\s+(.+)$/i,                    // "jodo ande" (add eggs)
                /^मुझे\s+(.+)\s+चाहिए$/i,             // "mujhe doodh chahiye" (I need milk)
                /^(.+)\s+चाहिए$/i,                    // "doodh chahiye" (need milk)
                /^मैं\s+(.+)\s+चाहता\s+हूं$/i,         // "main doodh chahta hun" (I want milk)
                /^(.+)\s+चाहता\s+हूं$/i,               // "doodh chahta hun" (want milk)
                /^(.+)\s+खरीदना$/i,                   // "doodh khareedna" (buy milk)
                /^खरीदना\s+(.+)$/i,                   // "khareedna doodh" (buy milk)
                /^(.+)\s+लेना$/i,                     // "doodh lena" (take milk)
                /^लेना\s+(.+)$/i,                     // "lena doodh" (take milk)
                /^(.+)\s+को\s+सूची\s+में\s+डालना$/i,    // "doodh ko suchi mein dalna"
                /^(.+)\s+को\s+(?:मेरी\s+)?सूची\s+में\s+जोड़ना$/i,  // "doodh ko meri suchi mein jodna"
                
                // Transliterated patterns (for voice recognition that outputs English)
                /^(.+)\s+jodna$/i,                    // "ande jodna" (eggs add)
                /^(.+)\s+jodo$/i,                     // "ande jodo" (add eggs)
                /^jodna\s+(.+)$/i,                    // "jodna ande" (add eggs)
                /^jodo\s+(.+)$/i,                     // "jodo ande" (add eggs)
                /^mujhe\s+(.+)\s+chahiye$/i,          // "mujhe doodh chahiye" (I need milk)
                /^(.+)\s+chahiye$/i,                  // "doodh chahiye" (need milk)
                /^main\s+(.+)\s+chahta\s+hun$/i,      // "main doodh chahta hun" (I want milk)
                /^(.+)\s+chahta\s+hun$/i,             // "doodh chahta hun" (want milk)
                /^(.+)\s+khareedna$/i,                // "doodh khareedna" (buy milk)
                /^khareedna\s+(.+)$/i,                // "khareedna doodh" (buy milk)
                /^(.+)\s+lena$/i,                     // "doodh lena" (take milk)
                /^lena\s+(.+)$/i,                     // "lena doodh" (take milk)
                /^(.+)\s+ko\s+suchi\s+mein\s+dalna$/i, // "doodh ko suchi mein dalna"
                /^(.+)\s+ko\s+(?:meri\s+)?suchi\s+mein\s+jodna$/i  // "doodh ko meri suchi mein jodna"
            ],
            remove: [
                // Devanagari patterns
                /^(.+)\s+हटाना$/i,                    // "doodh hatana" (remove milk)
                /^(.+)\s+हटाओ$/i,                     // "doodh hatao" (remove milk)
                /^हटाना\s+(.+)$/i,                    // "hatana doodh" (remove milk)
                /^हटाओ\s+(.+)$/i,                     // "hatao doodh" (remove milk)
                /^(.+)\s+निकालना$/i,                  // "doodh nikalna" (take out milk)
                /^निकालना\s+(.+)$/i,                  // "nikalna doodh" (take out milk)
                /^(.+)\s+मिटाना$/i,                   // "doodh mitana" (delete milk)
                /^मिटाना\s+(.+)$/i,                   // "mitana doodh" (delete milk)
                /^मुझे\s+(.+)\s+नहीं\s+चाहिए$/i,       // "mujhe doodh nahi chahiye" (I don't need milk)
                /^(.+)\s+नहीं\s+चाहिए$/i,             // "doodh nahi chahiye" (don't need milk)
                /^(.+)\s+की\s+जरूरत\s+नहीं$/i,         // "doodh ki zarurat nahi" (don't need milk)
                
                // Transliterated patterns
                /^(.+)\s+hatana$/i,                   // "doodh hatana" (remove milk)
                /^(.+)\s+hatao$/i,                    // "doodh hatao" (remove milk)
                /^hatana\s+(.+)$/i,                   // "hatana doodh" (remove milk)
                /^hatao\s+(.+)$/i,                    // "hatao doodh" (remove milk)
                /^(.+)\s+nikalna$/i,                  // "doodh nikalna" (take out milk)
                /^nikalna\s+(.+)$/i,                  // "nikalna doodh" (take out milk)
                /^(.+)\s+mitana$/i,                   // "doodh mitana" (delete milk)
                /^mitana\s+(.+)$/i,                   // "mitana doodh" (delete milk)
                /^mujhe\s+(.+)\s+nahi\s+chahiye$/i,   // "mujhe doodh nahi chahiye" (I don't need milk)
                /^(.+)\s+nahi\s+chahiye$/i,           // "doodh nahi chahiye" (don't need milk)
                /^(.+)\s+ki\s+zarurat\s+nahi$/i       // "doodh ki zarurat nahi" (don't need milk)
            ],
            update: [
                /^(.+)\s+को\s+(.+)\s+में\s+बदलना$/i,
                /^(.+)\s+को\s+(.+)\s+करना$/i,
                /^(.+)\s+को\s+(.+)\s+सेट\s+करना$/i
            ],
            search: [
                /^(.+)\s+खोजना$/i,
                /^(.+)\s+ढूंढना$/i,
                /^(.+)\s+दिखाना$/i,
                /^(.+)\s+देखना$/i
            ],
            help: [
                /^मदद$/i,
                /^मैं\s+क्या\s+कर\s+सकता\s+हूं$/i,
                /^यह\s+कैसे\s+काम\s+करता\s+है$/i,
                /^कमांड$/i,
                /^निर्देश$/i,
                /^गाइड$/i
            ],
            list: [
                // Devanagari patterns
                /^(?:मेरी\s+)?सूची$/i,                 // "meri suchi" (my list)
                /^सूची\s+दिखाओ$/i,                    // "suchi dikhao" (show list)
                /^(?:मेरी\s+)?सूची\s+दिखाना$/i,        // "meri suchi dikhana" (show my list)
                /^(?:मेरी\s+)?सूची\s+पढ़ना$/i,         // "meri suchi padhna" (read my list)
                /^(?:मेरी\s+)?सूची\s+पढ़ो$/i,          // "meri suchi padho" (read my list)
                /^क्या\s+है\s+(?:मेरी\s+)?सूची\s+में$/i, // "kya hai meri suchi mein" (what's in my list)
                /^(?:मेरी\s+)?वस्तुओं\s+की\s+सूची$/i,   // "meri vastuon ki suchi" (list of my items)
                /^मेरे\s+पास\s+क्या\s+है$/i,            // "mere paas kya hai" (what do I have)
                
                // Transliterated patterns
                /^(?:meri\s+)?suchi$/i,               // "meri suchi" (my list)
                /^suchi\s+dikhao$/i,                  // "suchi dikhao" (show list)
                /^(?:meri\s+)?suchi\s+dikhana$/i,     // "meri suchi dikhana" (show my list)
                /^(?:meri\s+)?suchi\s+padhna$/i,      // "meri suchi padhna" (read my list)
                /^(?:meri\s+)?suchi\s+padho$/i,       // "meri suchi padho" (read my list)
                /^kya\s+hai\s+(?:meri\s+)?suchi\s+mein$/i, // "kya hai meri suchi mein" (what's in my list)
                /^(?:meri\s+)?vastuon\s+ki\s+suchi$/i, // "meri vastuon ki suchi" (list of my items)
                /^mere\s+paas\s+kya\s+hai$/i          // "mere paas kya hai" (what do I have)
            ],
            clear: [
                // Devanagari patterns
                /^(?:मेरी\s+)?सूची\s+साफ\s+करो$/i,     // "meri suchi saaf karo" (clear my list)
                /^(?:मेरी\s+)?सूची\s+साफ\s+करना$/i,    // "meri suchi saaf karna" (clear my list)
                /^(?:मेरी\s+)?सूची\s+मिटाओ$/i,         // "meri suchi mitao" (delete my list)
                /^(?:मेरी\s+)?सूची\s+मिटाना$/i,        // "meri suchi mitana" (delete my list)
                /^सब\s+कुछ\s+हटाओ$/i,                 // "sab kuch hatao" (remove everything)
                /^सब\s+कुछ\s+हटाना$/i,                // "sab kuch hatana" (remove everything)
                /^फिर\s+से\s+शुरू\s+करो$/i,            // "phir se shuru karo" (start again)
                /^(?:मेरी\s+)?सूची\s+रीसेट\s+करो$/i,    // "meri suchi reset karo" (reset my list)
                
                // Transliterated patterns
                /^(?:meri\s+)?suchi\s+saaf\s+karo$/i,  // "meri suchi saaf karo" (clear my list)
                /^(?:meri\s+)?suchi\s+saaf\s+karna$/i, // "meri suchi saaf karna" (clear my list)
                /^(?:meri\s+)?suchi\s+mitao$/i,        // "meri suchi mitao" (delete my list)
                /^(?:meri\s+)?suchi\s+mitana$/i,       // "meri suchi mitana" (delete my list)
                /^sab\s+kuch\s+hatao$/i,               // "sab kuch hatao" (remove everything)
                /^sab\s+kuch\s+hatana$/i,              // "sab kuch hatana" (remove everything)
                /^phir\s+se\s+shuru\s+karo$/i,         // "phir se shuru karo" (start again)
                /^(?:meri\s+)?suchi\s+reset\s+karo$/i  // "meri suchi reset karo" (reset my list)
            ],
            quantity: [
                // Devanagari patterns
                /^(\d+(?:\.\d+)?)\s+(बोतलें?|डिब्बे|बक्से|थैले|पाउंड|औंस|गैलन|लीटर|किलो|ग्राम)\s+(.+)$/i,
                /^(\d+(?:\.\d+)?)\s+(.+)$/i,
                /^(एक\s+दर्जन|दर्जन)\s+(.+)$/i,
                /^(कुछ|बहुत)\s+(.+)$/i,
                /^(आधा)\s+(.+)$/i,
                /^(एक|दो|तीन|चार|पांच|छह|सात|आठ|नौ|दस)\s+(.+)$/i,
                
                // Transliterated patterns
                /^(ek\s+darjan|darjan)\s+(.+)$/i,
                /^(kuch|bahut)\s+(.+)$/i,
                /^(aadha)\s+(.+)$/i,
                /^(ek|do|teen|char|panch|cheh|saat|aath|nau|das)\s+(.+)$/i
            ],
            quantityWords: {
                // Devanagari numbers
                'एक': '1', 'दो': '2', 'तीन': '3', 'चार': '4', 'पांच': '5',
                'छह': '6', 'सात': '7', 'आठ': '8', 'नौ': '9', 'दस': '10',
                'दर्जन': '12', 'एक दर्जन': '12',
                'कुछ': '1', 'बहुत': '5',
                'आधा': '0.5',
                
                // Transliterated numbers
                'ek': '1', 'do': '2', 'teen': '3', 'char': '4', 'panch': '5',
                'cheh': '6', 'saat': '7', 'aath': '8', 'nau': '9', 'das': '10',
                'darjan': '12', 'ek darjan': '12',
                'kuch': '1', 'bahut': '5',
                'aadha': '0.5'
            }
        };
    }
    
    /**
     * Parse add commands to extract items and quantities
     * @param {string} text - The voice command text
     * @returns {Object|null} Parsed command with items array or null if not an add command
     */
    parseAddCommand(text) {
        if (!text || typeof text !== 'string') {
            return null;
        }
        
        const cleanText = text.trim().toLowerCase();
        
        // Check for search result patterns first
        const searchResultMatch = cleanText.match(/^(?:add\s+|choose\s+|select\s+|(?:i\s+want\s+)?)?(?:search\s+)?result\s+(\d+)$/i);
        if (searchResultMatch) {
            const resultIndex = parseInt(searchResultMatch[1]);
            return {
                intent: 'add_search_result',
                resultIndex: resultIndex,
                originalText: text
            };
        }
        
        // Check if this matches any add pattern
        let match = null;
        let itemText = null;
        
        for (const pattern of this.addPatterns) {
            match = cleanText.match(pattern);
            if (match) {
                itemText = match[1].trim();
                break;
            }
        }
        
        if (!itemText) {
            return null;
        }
        
        // Parse the item text for quantities and items
        const items = this.parseItemsWithQuantities(itemText);
        
        if (items.length === 0) {
            return null;
        }
        
        return {
            intent: 'add',
            items: items,
            originalText: text
        };
    }
    
    /**
     * Parse remove commands to extract items
     * @param {string} text - The voice command text
     * @returns {Object|null} Parsed command with items array or null if not a remove command
     */
    parseRemoveCommand(text) {
        if (!text || typeof text !== 'string') {
            return null;
        }
        
        const cleanText = text.trim().toLowerCase();
        
        // Check if this matches any remove pattern
        let match = null;
        let itemText = null;
        
        for (const pattern of this.removePatterns) {
            match = cleanText.match(pattern);
            if (match) {
                itemText = match[1].trim();
                break;
            }
        }
        
        if (!itemText) {
            return null;
        }
        
        // For remove commands, we typically don't need quantities
        // Just extract the item names and clean them
        const items = this.parseItemNames(itemText);
        
        if (items.length === 0) {
            return null;
        }
        
        return {
            intent: 'remove',
            items: items.map(item => ({ name: this.cleanItemName(item), quantity: null })),
            originalText: text
        };
    }
    
    /**
     * Parse search commands to extract search criteria
     * @param {string} text - The voice command text
     * @returns {Object|null} Parsed search command or null if not a search command
     */
    parseSearchCommand(text) {
        if (!text || typeof text !== 'string') {
            return null;
        }
        
        const cleanText = text.trim().toLowerCase();
        
        // Check if this matches any search pattern
        let match = null;
        let searchText = null;
        
        for (const pattern of this.searchPatterns) {
            match = cleanText.match(pattern);
            if (match) {
                searchText = match[1].trim();
                break;
            }
        }
        
        if (!searchText) {
            return null;
        }
        
        // Extract search criteria
        const criteria = this.parseSearchCriteria(searchText);
        
        // If no meaningful criteria found, return null
        if (!criteria || (!criteria.query && Object.keys(criteria.filters).length === 0)) {
            return null;
        }
        
        return {
            intent: 'search',
            criteria: criteria,
            originalText: text
        };
    }
    
    /**
     * Parse substitute commands to extract substitute requests or actions
     * @param {string} text - Voice command text
     * @returns {Object|null} Parsed substitute command or null
     */
    parseSubstituteCommand(text) {
        if (!text || typeof text !== 'string') {
            return null;
        }
        
        const normalizedText = text.toLowerCase().trim();
        
        // Check if it matches substitute patterns
        for (const pattern of this.substitutePatterns) {
            const match = normalizedText.match(pattern);
            if (match) {
                // Check for substitute acceptance/decline patterns
                if (normalizedText.includes('accept') || normalizedText.includes('use') || 
                    normalizedText.includes('add') || normalizedText.includes('choose')) {
                    const numberMatch = normalizedText.match(/(\d+)/);
                    if (numberMatch) {
                        return {
                            intent: 'accept_substitute',
                            substituteIndex: parseInt(numberMatch[1]) - 1, // Convert to 0-based index
                            originalText: text,
                            confidence: 0.95
                        };
                    }
                }
                
                // Check for substitute decline patterns
                if (normalizedText.includes('decline') || normalizedText.includes('skip') || 
                    normalizedText.includes('no')) {
                    return {
                        intent: 'decline_substitutes',
                        originalText: text,
                        confidence: 0.95
                    };
                }
                
                // Check for substitute request patterns
                if (match[1]) {
                    const itemName = match[1].trim();
                    return {
                        intent: 'request_substitutes',
                        itemName: itemName,
                        originalText: text,
                        confidence: 0.9
                    };
                }
            }
        }
        
        return null;
    }
    
    /**
     * Extract quantity information from text
     * @param {string} text - Text to parse for quantities
     * @returns {Object} Quantity information with number and unit
     */
    extractQuantity(text) {
        if (!text || typeof text !== 'string') {
            return { quantity: '1', unit: null };
        }
        
        const cleanText = text.trim().toLowerCase();
        
        // Try each quantity pattern
        for (const pattern of this.quantityPatterns) {
            const match = cleanText.match(pattern);
            if (match) {
                console.log('Pattern matched:', pattern.toString(), 'Match:', match);
                return this.processQuantityMatch(match, pattern);
            }
        }
        
        console.log('No pattern matched for:', cleanText);
        
        // Default quantity if no pattern matches
        return { quantity: '1', unit: null, item: text };
    }
    
    /**
     * Process a quantity pattern match
     * @param {Array} match - Regex match array
     * @param {RegExp} pattern - The pattern that matched
     * @returns {Object} Processed quantity information
     */
    processQuantityMatch(match, pattern) {
        const patternStr = pattern.toString();
        
        // Handle patterns with 3 groups: quantity, unit, item (e.g., "2 bottles of water")
        if (match[3]) {
            const quantity = match[1] || '1';
            const unit = match[2] ? this.normalizeUnit(match[2]) : null;
            const item = match[3];
            
            // Check if quantity is a word that needs mapping
            const mappedQuantity = quantity ? (this.quantityWords[quantity.toLowerCase()] || quantity) : '1';
            
            // Format quantity with unit if present
            const formattedQuantity = unit ? `${mappedQuantity} ${unit}` : mappedQuantity;
            
            console.log('Debug processQuantityMatch:', {
                quantity, unit, item, mappedQuantity, formattedQuantity
            });
            
            return {
                quantity: formattedQuantity,
                unit: unit,
                item: item
            };
        }
        // Handle patterns with 2 groups: quantity, item (e.g., "2 apples")
        else if (match[2]) {
            const quantityOrWord = match[1] || '1';
            const item = match[2];
            
            // Check if first group is a quantity word that needs mapping
            const mappedQuantity = quantityOrWord ? (this.quantityWords[quantityOrWord.toLowerCase()] || quantityOrWord) : '1';
            
            return {
                quantity: mappedQuantity,
                unit: null,
                item: item
            };
        }
        // Handle single group patterns (fallback)
        else {
            return {
                quantity: '1',
                unit: null,
                item: match[1] || match[0]
            };
        }
    }
    
    /**
     * Parse items with quantities from text
     * @param {string} text - Text containing items and quantities
     * @returns {Array} Array of item objects with name and quantity
     */
    parseItemsWithQuantities(text) {
        const items = [];
        
        // Get language-specific separators
        const separators = this.getItemSeparators();
        
        // Split by language-specific separators
        let itemTexts = [text];
        for (const separator of separators) {
            const newTexts = [];
            for (const itemText of itemTexts) {
                if (typeof separator === 'string') {
                    newTexts.push(...itemText.split(separator));
                } else {
                    // Handle regex separators
                    newTexts.push(...itemText.split(separator));
                }
            }
            itemTexts = newTexts;
        }
        
        for (const itemText of itemTexts) {
            const trimmed = itemText.trim();
            if (!trimmed) continue;
            
            const quantityInfo = this.extractQuantity(trimmed);
            
            let itemName = quantityInfo.item || trimmed;
            let quantity = quantityInfo.quantity;
            let unit = quantityInfo.unit;
            
            // Clean up item name
            itemName = this.cleanItemName(itemName);
            
            if (itemName) {
                // Format quantity with unit if present
                const formattedQuantity = unit ? `${quantity} ${unit}` : quantity;
                
                items.push({
                    name: itemName,
                    quantity: formattedQuantity
                });
            }
        }
        
        return items;
    }
    
    /**
     * Get language-specific item separators
     * @returns {Array} Array of separator patterns
     */
    getItemSeparators() {
        const langCode = this.currentLanguage.split('-')[0];
        
        const separators = {
            'en': [/\s+and\s+/i, /,\s*/],
            'es': [/\s+y\s+/i, /,\s*/],
            'fr': [/\s+et\s+/i, /,\s*/],
            'de': [/\s+und\s+/i, /,\s*/],
            'it': [/\s+e\s+/i, /,\s*/],
            'pt': [/\s+e\s+/i, /,\s*/],
            'zh': [/\s*和\s*/i, /,\s*/],
            'ja': [/\s*と\s*/i, /,\s*/],
            'ko': [/\s*와\s*/i, /\s*과\s*/i, /,\s*/],
            'ru': [/\s+и\s+/i, /,\s*/],
            'ar': [/\s+و\s+/i, /,\s*/],
            'hi': [/\s+और\s+/i, /,\s*/]
        };
        
        return separators[langCode] || separators['en'];
    }
    
    /**
     * Parse item names from text (without quantities)
     * @param {string} text - Text containing item names
     * @returns {Array} Array of item names
     */
    parseItemNames(text) {
        const items = [];
        
        // Get language-specific separators
        const separators = this.getItemSeparators();
        
        // Split by language-specific separators
        let itemTexts = [text];
        for (const separator of separators) {
            const newTexts = [];
            for (const itemText of itemTexts) {
                if (typeof separator === 'string') {
                    newTexts.push(...itemText.split(separator));
                } else {
                    // Handle regex separators
                    newTexts.push(...itemText.split(separator));
                }
            }
            itemTexts = newTexts;
        }
        
        for (const itemText of itemTexts) {
            const trimmed = itemText.trim();
            if (!trimmed) continue;
            
            const cleanName = this.cleanItemName(trimmed);
            if (cleanName) {
                items.push(cleanName);
            }
        }
        
        return items;
    }
    
    /**
     * Parse search criteria from search text
     * @param {string} text - Search text to parse
     * @returns {Object} Search criteria object
     */
    parseSearchCriteria(text) {
        const criteria = {
            query: text,
            filters: {}
        };
        
        let remainingText = text.toLowerCase();
        
        // Extract price range patterns
        const pricePatterns = [
            /under\s+\$?(\d+(?:\.\d+)?)/i,
            /less\s+than\s+\$?(\d+(?:\.\d+)?)/i,
            /below\s+\$?(\d+(?:\.\d+)?)/i,
            /cheaper\s+than\s+\$?(\d+(?:\.\d+)?)/i,
            /\$?(\d+(?:\.\d+)?)\s+or\s+less/i,
            /\$?(\d+(?:\.\d+)?)\s+max/i,
            /maximum\s+\$?(\d+(?:\.\d+)?)/i
        ];
        
        for (const pattern of pricePatterns) {
            const match = remainingText.match(pattern);
            if (match) {
                criteria.filters.maxPrice = parseFloat(match[1]);
                remainingText = remainingText.replace(match[0], '').trim();
                break;
            }
        }
        
        // Extract minimum price patterns
        const minPricePatterns = [
            /over\s+\$?(\d+(?:\.\d+)?)/i,
            /more\s+than\s+\$?(\d+(?:\.\d+)?)/i,
            /above\s+\$?(\d+(?:\.\d+)?)/i,
            /at\s+least\s+\$?(\d+(?:\.\d+)?)/i,
            /minimum\s+\$?(\d+(?:\.\d+)?)/i
        ];
        
        for (const pattern of minPricePatterns) {
            const match = remainingText.match(pattern);
            if (match) {
                criteria.filters.minPrice = parseFloat(match[1]);
                remainingText = remainingText.replace(match[0], '').trim();
                break;
            }
        }
        
        // Extract price range patterns (e.g., "between $2 and $5")
        const rangeMatch = remainingText.match(/between\s+\$?(\d+(?:\.\d+)?)\s+and\s+\$?(\d+(?:\.\d+)?)/i);
        if (rangeMatch) {
            criteria.filters.minPrice = parseFloat(rangeMatch[1]);
            criteria.filters.maxPrice = parseFloat(rangeMatch[2]);
            remainingText = remainingText.replace(rangeMatch[0], '').trim();
        }
        
        // Extract standalone price patterns (e.g., "$5" or "5 dollars")
        const standalonePriceMatch = remainingText.match(/^\$?(\d+(?:\.\d+)?)\s*(?:dollars?)?$/i);
        if (standalonePriceMatch) {
            criteria.filters.maxPrice = parseFloat(standalonePriceMatch[1]);
            remainingText = remainingText.replace(standalonePriceMatch[0], '').trim();
        }
        
        // Extract brand patterns first (multi-word brands before single words)
        const brandPatterns = [
            /\b(organic valley|coca cola)\b/i,
            /\b(kraft|chobani|silk|oatly|perdue|barilla|folgers|tropicana|pepsi|lays|oreo|ritz)\b/i,
            /brand\s+([\w\s]+)/i,
            /made\s+by\s+([\w\s]+)/i
        ];
        
        for (const pattern of brandPatterns) {
            const match = remainingText.match(pattern);
            if (match) {
                criteria.filters.brand = match[1].toLowerCase();
                remainingText = remainingText.replace(match[0], '').trim();
                break;
            }
        }
        
        // Extract type/quality modifiers (after brand extraction)
        const typePatterns = [
            /\b(organic|fresh|frozen|canned|dried|whole|low-fat|non-fat|diet|sugar-free|gluten-free|natural|raw)\b/i
        ];
        
        for (const pattern of typePatterns) {
            const match = remainingText.match(pattern);
            if (match) {
                criteria.filters.type = match[1].toLowerCase();
                remainingText = remainingText.replace(match[0], '').trim();
                break;
            }
        }
        
        // Extract category patterns
        const categoryPatterns = [
            /\b(dairy|produce|meat|pantry|snacks|beverages|frozen|bakery)\b/i,
            /in\s+the\s+(\w+)\s+section/i,
            /from\s+the\s+(\w+)\s+aisle/i
        ];
        
        for (const pattern of categoryPatterns) {
            const match = remainingText.match(pattern);
            if (match) {
                criteria.filters.category = match[1].toLowerCase();
                remainingText = remainingText.replace(match[0], '').trim();
                break;
            }
        }
        
        // Clean up remaining text for the main query
        criteria.query = remainingText
            .replace(/\s+/g, ' ')
            .replace(/^(find|search|look for|show me)\s+/i, '')
            .replace(/^(me\s+)?some\s+/i, '')
            .replace(/\s+in\s+produce$/i, '')
            .replace(/\s+in\s+the\s+\w+\s+section$/i, '')
            .replace(/\s+from\s+the\s+\w+\s+aisle$/i, '')
            .replace(/\s+in$/i, '') // Remove trailing "in"
            .trim();
        
        // If query is empty or just a modifier, set to empty but don't return null
        if (!criteria.query || criteria.query.length < 2) {
            criteria.query = '';
        }
        
        return criteria;
    }
    
    /**
     * Clean and normalize item names
     * @param {string} itemName - Raw item name
     * @returns {string} Cleaned item name
     */
    cleanItemName(itemName) {
        if (!itemName) return '';
        
        // Remove common prefixes and suffixes
        let cleaned = itemName
            .replace(/^(some|more|a|an|the)\s+/i, '')
            .replace(/\s+(please|thanks|thank you|anymore)$/i, '')
            .replace(/\s+(from\s+(?:my\s+)?(?:shopping\s+)?list)$/i, '') // Remove "from my list" etc.
            .replace(/\s+(to\s+(?:my\s+)?(?:shopping\s+)?list)$/i, '') // Remove "to my list" etc.
            .trim();
        
        // Remove quantity information that might have leaked through
        cleaned = cleaned.replace(/^\d+(?:\.\d+)?\s+(?:bottles?|cans?|boxes?|bags?|pounds?|lbs?|ounces?|oz|gallons?|liters?|litres?|kilos?|kg|grams?|g)?\s+(?:of\s+)?/i, '');
        
        return cleaned.trim();
    }
    
    /**
     * Normalize unit names
     * @param {string} unit - Raw unit name
     * @returns {string} Normalized unit name
     */
    normalizeUnit(unit) {
        if (!unit) return null;
        
        const normalized = unit.toLowerCase();
        return this.unitMappings[normalized] || normalized;
    }
    
    /**
     * Parse help commands
     * @param {string} text - The voice command text
     * @returns {Object|null} Parsed help command or null if not a help command
     */
    parseHelpCommand(text) {
        if (!text || typeof text !== 'string') {
            return null;
        }
        
        const cleanText = text.trim().toLowerCase();
        
        // Check if this matches any help pattern
        for (const pattern of this.helpPatterns) {
            if (pattern.test(cleanText)) {
                return {
                    intent: 'help',
                    originalText: text
                };
            }
        }
        
        return null;
    }
    
    /**
     * Parse list reading commands
     * @param {string} text - The voice command text
     * @returns {Object|null} Parsed list command or null if not a list command
     */
    parseListCommand(text) {
        if (!text || typeof text !== 'string') {
            return null;
        }
        
        const cleanText = text.trim().toLowerCase();
        
        // Check if this matches any list pattern
        for (const pattern of this.listPatterns) {
            if (pattern.test(cleanText)) {
                return {
                    intent: 'list',
                    originalText: text
                };
            }
        }
        
        return null;
    }
    
    /**
     * Parse clear list commands
     * @param {string} text - The voice command text
     * @returns {Object|null} Parsed clear command or null if not a clear command
     */
    parseClearCommand(text) {
        if (!text || typeof text !== 'string') {
            return null;
        }
        
        const cleanText = text.trim().toLowerCase();
        
        // Check if this matches any clear pattern
        for (const pattern of this.clearPatterns) {
            if (pattern.test(cleanText)) {
                return {
                    intent: 'clear',
                    originalText: text
                };
            }
        }
        
        return null;
    }
    
    /**
     * Detect the intent of a voice command
     * @param {string} text - The voice command text
     * @returns {string|null} The detected intent or null if unknown
     */
    detectIntent(text) {
        if (!text || typeof text !== 'string') {
            return null;
        }
        
        const cleanText = text.trim().toLowerCase();
        
        // Check for add intent
        for (const pattern of this.addPatterns) {
            if (pattern.test(cleanText)) {
                return 'add';
            }
        }
        
        // Check for remove intent
        for (const pattern of this.removePatterns) {
            if (pattern.test(cleanText)) {
                return 'remove';
            }
        }
        
        // Check for update intent
        for (const pattern of this.updatePatterns) {
            if (pattern.test(cleanText)) {
                return 'update';
            }
        }
        
        // Check for search intent
        for (const pattern of this.searchPatterns) {
            if (pattern.test(cleanText)) {
                return 'search';
            }
        }
        
        // Check for substitute intent
        for (const pattern of this.substitutePatterns) {
            if (pattern.test(cleanText)) {
                return 'substitute';
            }
        }
        
        // Check for help intent
        for (const pattern of this.helpPatterns) {
            if (pattern.test(cleanText)) {
                return 'help';
            }
        }
        
        // Check for list intent
        for (const pattern of this.listPatterns) {
            if (pattern.test(cleanText)) {
                return 'list';
            }
        }
        
        // Check for clear intent
        for (const pattern of this.clearPatterns) {
            if (pattern.test(cleanText)) {
                return 'clear';
            }
        }
        
        return null;
    }
    
    /**
     * Parse any voice command and return structured data
     * @param {string} text - The voice command text
     * @returns {Object|null} Parsed command object or null if not recognized
     */
    parseCommand(text) {
        if (!text || typeof text !== 'string') {
            return null;
        }
        
        // Try each parser in order
        let result = this.parseAddCommand(text);
        if (result) return result;
        
        result = this.parseRemoveCommand(text);
        if (result) return result;
        
        result = this.parseSearchCommand(text);
        if (result) return result;
        
        result = this.parseSubstituteCommand(text);
        if (result) return result;
        
        result = this.parseHelpCommand(text);
        if (result) return result;
        
        result = this.parseListCommand(text);
        if (result) return result;
        
        result = this.parseClearCommand(text);
        if (result) return result;
        
        // If no specific parser worked, try to detect intent
        const intent = this.detectIntent(text);
        if (intent) {
            return {
                intent: intent,
                originalText: text,
                error: 'Could not parse command details'
            };
        }
        
        return null;
    }
}