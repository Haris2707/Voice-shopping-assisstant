/**
 * AccessibilityManager - Manages accessibility features and ARIA support
 * Handles screen reader announcements, keyboard navigation, and accessibility enhancements
 */

export class AccessibilityManager {
    constructor() {
        // DOM elements for accessibility
        this.elements = {
            srAnnouncements: document.getElementById('sr-announcements'),
            listeningStatus: document.getElementById('listening-status'),
            statusIndicator: document.getElementById('status-indicator')
        };
        
        // Keyboard navigation state
        this.keyboardNavigation = false;
        this.focusableElements = [];
        this.currentFocusIndex = -1;
        
        // Screen reader state
        this.lastAnnouncement = '';
        this.announcementQueue = [];
        this.isProcessingQueue = false;
        
        // Initialize accessibility features
        this.init();
    }
    
    /**
     * Initialize accessibility features
     */
    init() {
        this.setupKeyboardNavigation();
        this.setupScreenReaderSupport();
        this.setupFocusManagement();
        this.setupARIALiveRegions();
        this.detectAccessibilityPreferences();
        
        console.log('AccessibilityManager initialized');
    }
    
    /**
     * Set up keyboard navigation
     */
    setupKeyboardNavigation() {
        // Detect keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab' || e.key === 'ArrowUp' || e.key === 'ArrowDown' || 
                e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
                this.enableKeyboardNavigation();
            }
        });
        
        // Detect mouse usage
        document.addEventListener('mousedown', () => {
            this.disableKeyboardNavigation();
        });
        
        // Global keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            this.handleGlobalKeyboardShortcuts(e);
        });
        
        // Update focusable elements periodically
        this.updateFocusableElements();
        setInterval(() => this.updateFocusableElements(), 2000);
    }
    
    /**
     * Enable keyboard navigation mode
     */
    enableKeyboardNavigation() {
        if (!this.keyboardNavigation) {
            this.keyboardNavigation = true;
            document.body.classList.add('keyboard-navigation');
            this.announceToScreenReader('Keyboard navigation enabled');
        }
    }
    
    /**
     * Disable keyboard navigation mode
     */
    disableKeyboardNavigation() {
        if (this.keyboardNavigation) {
            this.keyboardNavigation = false;
            document.body.classList.remove('keyboard-navigation');
        }
    }
    
    /**
     * Handle global keyboard shortcuts
     * @param {KeyboardEvent} event - Keyboard event
     */
    handleGlobalKeyboardShortcuts(event) {
        // Don't interfere with input fields
        if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA' || event.target.tagName === 'SELECT') {
            return;
        }
        
        switch (event.key) {
            case ' ': // Spacebar - toggle voice recording
                event.preventDefault();
                this.triggerVoiceToggle();
                break;
            case 'h': // H - show help
                if (event.ctrlKey || event.metaKey) {
                    event.preventDefault();
                    this.showKeyboardHelp();
                }
                break;
            case 'l': // L - focus on shopping list
                if (event.ctrlKey || event.metaKey) {
                    event.preventDefault();
                    this.focusShoppingList();
                }
                break;
            case 's': // S - focus on suggestions
                if (event.ctrlKey || event.metaKey) {
                    event.preventDefault();
                    this.focusSuggestions();
                }
                break;
            case 'Escape': // Escape - clear focus or close modals
                this.handleEscape();
                break;
        }
    }
    
    /**
     * Update list of focusable elements
     */
    updateFocusableElements() {
        const focusableSelectors = [
            'button:not([disabled])',
            'input:not([disabled])',
            'select:not([disabled])',
            'textarea:not([disabled])',
            '[tabindex]:not([tabindex="-1"])',
            '.suggestion-item',
            '.shopping-item .item-action-btn'
        ];
        
        this.focusableElements = Array.from(
            document.querySelectorAll(focusableSelectors.join(', '))
        ).filter(el => {
            return el.offsetParent !== null && // Element is visible
                   !el.hasAttribute('aria-hidden') &&
                   getComputedStyle(el).visibility !== 'hidden';
        });
    }
    
    /**
     * Set up screen reader support
     */
    setupScreenReaderSupport() {
        // Ensure screen reader announcement element exists
        if (!this.elements.srAnnouncements) {
            const srDiv = document.createElement('div');
            srDiv.id = 'sr-announcements';
            srDiv.className = 'sr-only';
            srDiv.setAttribute('aria-live', 'assertive');
            srDiv.setAttribute('aria-atomic', 'true');
            document.body.appendChild(srDiv);
            this.elements.srAnnouncements = srDiv;
        }
    }
    
    /**
     * Set up focus management
     */
    setupFocusManagement() {
        // Track focus changes
        document.addEventListener('focusin', (e) => {
            this.handleFocusChange(e.target);
        });
        
        // Handle focus trapping in modals
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                this.handleTabNavigation(e);
            }
        });
    }
    
    /**
     * Set up ARIA live regions
     */
    setupARIALiveRegions() {
        // Ensure status indicator has proper ARIA attributes
        if (this.elements.statusIndicator) {
            this.elements.statusIndicator.setAttribute('aria-live', 'polite');
            this.elements.statusIndicator.setAttribute('aria-atomic', 'true');
        }
        
        // Set up shopping list live region
        const shoppingList = document.getElementById('shopping-list');
        if (shoppingList) {
            shoppingList.setAttribute('aria-live', 'polite');
            shoppingList.setAttribute('aria-relevant', 'additions removals');
        }
        
        // Set up suggestions live region
        const suggestions = document.getElementById('suggestions');
        if (suggestions) {
            suggestions.setAttribute('aria-live', 'polite');
            suggestions.setAttribute('aria-relevant', 'additions removals');
        }
    }
    
    /**
     * Detect accessibility preferences
     */
    detectAccessibilityPreferences() {
        // Check for reduced motion preference
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            document.body.classList.add('reduced-motion');
            this.announceToScreenReader('Reduced motion mode detected');
        }
        
        // Check for high contrast preference
        if (window.matchMedia('(prefers-contrast: high)').matches) {
            document.body.classList.add('high-contrast');
            this.announceToScreenReader('High contrast mode detected');
        }
        
        // Check for large text preference
        if (window.matchMedia('(min-resolution: 120dpi)').matches) {
            document.body.classList.add('large-text');
        }
        
        // Listen for preference changes
        window.matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', (e) => {
            document.body.classList.toggle('reduced-motion', e.matches);
        });
        
        window.matchMedia('(prefers-contrast: high)').addEventListener('change', (e) => {
            document.body.classList.toggle('high-contrast', e.matches);
        });
    }
    
    /**
     * Announce message to screen readers
     * @param {string} message - Message to announce
     * @param {string} priority - Priority level ('polite' or 'assertive')
     */
    announceToScreenReader(message, priority = 'assertive') {
        if (!message || message === this.lastAnnouncement) {
            return;
        }
        
        this.lastAnnouncement = message;
        this.announcementQueue.push({ message, priority });
        
        if (!this.isProcessingQueue) {
            this.processAnnouncementQueue();
        }
    }
    
    /**
     * Process the announcement queue
     */
    async processAnnouncementQueue() {
        this.isProcessingQueue = true;
        
        while (this.announcementQueue.length > 0) {
            const { message, priority } = this.announcementQueue.shift();
            
            if (this.elements.srAnnouncements) {
                // Clear previous announcement
                this.elements.srAnnouncements.textContent = '';
                this.elements.srAnnouncements.setAttribute('aria-live', priority);
                
                // Add new announcement after a brief delay
                setTimeout(() => {
                    this.elements.srAnnouncements.textContent = message;
                }, 100);
                
                // Wait before processing next announcement
                await new Promise(resolve => setTimeout(resolve, 1500));
            }
        }
        
        this.isProcessingQueue = false;
    }
    
    /**
     * Update voice status for screen readers
     * @param {boolean} isListening - Whether voice recognition is active
     * @param {string} status - Current status message
     */
    updateVoiceStatus(isListening, status) {
        // Update listening status for screen readers
        if (this.elements.listeningStatus) {
            this.elements.listeningStatus.textContent = isListening ? 'Listening for voice commands' : 'Not listening';
        }
        
        // Update voice button ARIA attributes
        const voiceBtn = document.getElementById('voice-btn');
        if (voiceBtn) {
            voiceBtn.setAttribute('aria-pressed', isListening.toString());
            voiceBtn.setAttribute('aria-label', isListening ? 'Stop voice recording' : 'Start voice recording');
            
            const btnText = voiceBtn.querySelector('.voice-btn__text');
            if (btnText) {
                btnText.textContent = isListening ? 'Stop Listening' : 'Start Listening';
            }
        }
        
        // Update listening indicator
        const listeningIndicator = document.getElementById('listening-indicator');
        if (listeningIndicator) {
            listeningIndicator.setAttribute('aria-hidden', (!isListening).toString());
            if (isListening) {
                listeningIndicator.setAttribute('aria-label', 'Voice recognition active');
            }
        }
        
        // Announce status change
        if (status) {
            this.announceToScreenReader(status, 'polite');
        }
    }
    
    /**
     * Announce shopping list changes
     * @param {string} action - Action performed ('added', 'removed', 'updated')
     * @param {string} itemName - Name of the item
     * @param {string} quantity - Quantity (optional)
     */
    announceListChange(action, itemName, quantity = '') {
        let message = '';
        
        switch (action) {
            case 'added':
                message = `Added ${quantity} ${itemName} to shopping list`;
                break;
            case 'removed':
                message = `Removed ${itemName} from shopping list`;
                break;
            case 'updated':
                message = `Updated ${itemName} quantity to ${quantity}`;
                break;
            case 'completed':
                message = `Marked ${itemName} as completed`;
                break;
            case 'uncompleted':
                message = `Marked ${itemName} as not completed`;
                break;
        }
        
        if (message) {
            this.announceToScreenReader(message, 'polite');
        }
    }
    
    /**
     * Announce error messages
     * @param {string} error - Error message
     */
    announceError(error) {
        this.announceToScreenReader(`Error: ${error}`, 'assertive');
    }
    
    /**
     * Announce success messages
     * @param {string} message - Success message
     */
    announceSuccess(message) {
        this.announceToScreenReader(message, 'polite');
    }
    
    /**
     * Handle focus changes
     * @param {Element} element - Newly focused element
     */
    handleFocusChange(element) {
        // Update current focus index
        this.currentFocusIndex = this.focusableElements.indexOf(element);
        
        // Provide context for screen readers
        if (element.classList.contains('suggestion-item')) {
            const itemName = element.getAttribute('data-item-name');
            const index = element.getAttribute('data-suggestion-index');
            this.announceToScreenReader(`Suggestion ${index}: ${itemName}`, 'polite');
        } else if (element.classList.contains('item-action-btn')) {
            const action = element.getAttribute('aria-label');
            this.announceToScreenReader(action, 'polite');
        }
    }
    
    /**
     * Handle Tab navigation in modals
     * @param {KeyboardEvent} event - Tab key event
     */
    handleTabNavigation(event) {
        // Check if we're in a modal
        const modal = document.querySelector('.substitute-suggestions[style*="block"]');
        if (modal) {
            const modalFocusable = modal.querySelectorAll(
                'button:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
            );
            
            if (modalFocusable.length > 0) {
                const firstElement = modalFocusable[0];
                const lastElement = modalFocusable[modalFocusable.length - 1];
                
                if (event.shiftKey && document.activeElement === firstElement) {
                    event.preventDefault();
                    lastElement.focus();
                } else if (!event.shiftKey && document.activeElement === lastElement) {
                    event.preventDefault();
                    firstElement.focus();
                }
            }
        }
    }
    
    /**
     * Trigger voice toggle (for keyboard shortcut)
     */
    triggerVoiceToggle() {
        const voiceBtn = document.getElementById('voice-btn');
        if (voiceBtn && !voiceBtn.disabled) {
            voiceBtn.click();
            this.announceToScreenReader('Voice recording toggled', 'assertive');
        }
    }
    
    /**
     * Show keyboard help
     */
    showKeyboardHelp() {
        const helpMessage = `
            Keyboard shortcuts: 
            Spacebar - Toggle voice recording, 
            Ctrl+H - Show this help, 
            Ctrl+L - Focus shopping list, 
            Ctrl+S - Focus suggestions, 
            Escape - Clear focus or close modals, 
            Tab - Navigate between elements
        `;
        this.announceToScreenReader(helpMessage, 'assertive');
    }
    
    /**
     * Focus on shopping list
     */
    focusShoppingList() {
        const shoppingList = document.getElementById('shopping-list');
        if (shoppingList) {
            shoppingList.focus();
            this.announceToScreenReader('Focused on shopping list', 'polite');
        }
    }
    
    /**
     * Focus on suggestions
     */
    focusSuggestions() {
        const suggestions = document.getElementById('suggestions');
        const firstSuggestion = suggestions?.querySelector('.suggestion-item');
        if (firstSuggestion) {
            firstSuggestion.focus();
            this.announceToScreenReader('Focused on suggestions', 'polite');
        } else if (suggestions) {
            suggestions.focus();
            this.announceToScreenReader('No suggestions available', 'polite');
        }
    }
    
    /**
     * Handle Escape key
     */
    handleEscape() {
        // Close modals
        const modal = document.querySelector('.substitute-suggestions[style*="block"]');
        if (modal) {
            const closeBtn = modal.querySelector('.close-substitutes');
            if (closeBtn) {
                closeBtn.click();
                this.announceToScreenReader('Modal closed', 'polite');
            }
            return;
        }
        
        // Clear focus from current element
        if (document.activeElement && document.activeElement !== document.body) {
            document.activeElement.blur();
            this.announceToScreenReader('Focus cleared', 'polite');
        }
    }
    
    /**
     * Set up item accessibility attributes
     * @param {HTMLElement} itemElement - Shopping item element
     * @param {Object} item - Shopping item data
     */
    setupItemAccessibility(itemElement, item) {
        // Set up main item container
        itemElement.setAttribute('role', 'listitem');
        itemElement.setAttribute('aria-label', `${item.name}, quantity: ${item.quantity}, category: ${item.category}`);
        itemElement.setAttribute('tabindex', '0');
        
        // Set up action buttons
        const completeBtn = itemElement.querySelector('.complete-btn');
        if (completeBtn) {
            completeBtn.setAttribute('aria-label', 
                item.completed ? `Mark ${item.name} as incomplete` : `Mark ${item.name} as complete`);
            completeBtn.setAttribute('aria-pressed', item.completed.toString());
        }
        
        const editBtn = itemElement.querySelector('.edit-btn');
        if (editBtn) {
            editBtn.setAttribute('aria-label', `Edit quantity for ${item.name}`);
        }
        
        const removeBtn = itemElement.querySelector('.remove-btn');
        if (removeBtn) {
            removeBtn.setAttribute('aria-label', `Remove ${item.name} from shopping list`);
        }
    }
    
    /**
     * Set up suggestion accessibility attributes
     * @param {HTMLElement} suggestionElement - Suggestion element
     * @param {Object} suggestion - Suggestion data
     * @param {number} index - Suggestion index
     */
    setupSuggestionAccessibility(suggestionElement, suggestion, index) {
        const itemName = typeof suggestion === 'string' ? suggestion : suggestion.itemName;
        const reason = typeof suggestion === 'object' ? suggestion.reason : '';
        
        suggestionElement.setAttribute('role', 'button');
        suggestionElement.setAttribute('tabindex', '0');
        suggestionElement.setAttribute('aria-label', 
            `Add ${itemName} to shopping list. ${reason ? `Reason: ${reason}` : ''} Press Enter or Space to add.`);
        suggestionElement.setAttribute('aria-describedby', `suggestion-${index}-help`);
        
        // Add hidden help text
        const helpText = document.createElement('div');
        helpText.id = `suggestion-${index}-help`;
        helpText.className = 'sr-only';
        helpText.textContent = `Suggestion ${index}. Say "add suggestion ${index}" or click to add to your shopping list.`;
        suggestionElement.appendChild(helpText);
    }
    
    /**
     * Update shopping list accessibility
     * @param {number} itemCount - Number of items in the list
     */
    updateShoppingListAccessibility(itemCount) {
        const shoppingList = document.getElementById('shopping-list');
        if (shoppingList) {
            shoppingList.setAttribute('aria-label', `Shopping list with ${itemCount} items`);
            
            if (itemCount === 0) {
                shoppingList.setAttribute('aria-describedby', 'empty-state');
            } else {
                shoppingList.removeAttribute('aria-describedby');
            }
        }
        
        // Update section heading
        const heading = document.getElementById('shopping-list-heading');
        if (heading) {
            heading.textContent = `Your Shopping List (${itemCount} items)`;
        }
    }
    
    /**
     * Update suggestions accessibility
     * @param {number} suggestionCount - Number of suggestions
     */
    updateSuggestionsAccessibility(suggestionCount) {
        const suggestions = document.getElementById('suggestions');
        if (suggestions) {
            suggestions.setAttribute('aria-label', `${suggestionCount} suggestions available`);
        }
        
        // Update section heading
        const heading = document.getElementById('suggestions-heading');
        if (heading) {
            heading.textContent = `Suggestions (${suggestionCount} available)`;
        }
    }
    
    /**
     * Validate accessibility compliance
     * @returns {Object} Validation results
     */
    validateAccessibility() {
        const issues = [];
        const warnings = [];
        
        // Check for missing alt text on images
        const images = document.querySelectorAll('img:not([alt])');
        if (images.length > 0) {
            issues.push(`${images.length} images missing alt text`);
        }
        
        // Check for missing form labels
        const inputs = document.querySelectorAll('input:not([aria-label]):not([aria-labelledby])');
        inputs.forEach(input => {
            const label = document.querySelector(`label[for="${input.id}"]`);
            if (!label) {
                issues.push(`Input ${input.id || input.type} missing label`);
            }
        });
        
        // Check for missing headings
        const sections = document.querySelectorAll('section:not([aria-labelledby]):not([aria-label])');
        if (sections.length > 0) {
            warnings.push(`${sections.length} sections without proper headings`);
        }
        
        // Check for proper heading hierarchy
        const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
        let lastLevel = 0;
        headings.forEach(heading => {
            const level = parseInt(heading.tagName.charAt(1));
            if (level > lastLevel + 1) {
                warnings.push(`Heading level skip detected: ${heading.textContent}`);
            }
            lastLevel = level;
        });
        
        return {
            issues,
            warnings,
            isCompliant: issues.length === 0
        };
    }
}