/**
 * StorageManager - Handles data persistence using localStorage
 * Manages shopping lists, user history, and application settings
 */

import { ShoppingList } from './ShoppingList.js';

export class StorageManager {
    constructor() {
        this.STORAGE_KEYS = {
            SHOPPING_LIST: 'voice_shopping_list',
            USER_HISTORY: 'voice_shopping_history',
            PREFERENCES: 'voice_shopping_preferences',
            CATEGORIES: 'voice_shopping_categories'
        };
        
        this.DEFAULT_PREFERENCES = {
            language: 'en-US',
            voiceSpeed: 1.0,
            autoSuggestions: true,
            theme: 'light'
        };
        
        // Check localStorage availability
        this.isAvailable = this.checkStorageAvailability();
        
        if (!this.isAvailable) {
            console.warn('localStorage is not available. Data will not persist.');
        }
    }
    
    /**
     * Check if localStorage is available and working
     * @returns {boolean} True if localStorage is available
     */
    checkStorageAvailability() {
        try {
            const testKey = '__storage_test__';
            localStorage.setItem(testKey, 'test');
            localStorage.removeItem(testKey);
            return true;
        } catch (error) {
            return false;
        }
    }
    
    /**
     * Save shopping list to localStorage
     * @param {ShoppingList} shoppingList - Shopping list to save
     * @returns {boolean} True if save was successful
     */
    saveList(shoppingList) {
        if (!this.isAvailable) {
            console.warn('Cannot save list: localStorage not available');
            return false;
        }
        
        if (!(shoppingList instanceof ShoppingList)) {
            throw new Error('Invalid shopping list provided');
        }
        
        try {
            const data = JSON.stringify(shoppingList.toJSON());
            localStorage.setItem(this.STORAGE_KEYS.SHOPPING_LIST, data);
            return true;
        } catch (error) {
            console.error('Failed to save shopping list:', error);
            
            // Handle quota exceeded error
            if (error.name === 'QuotaExceededError') {
                this.handleStorageQuotaExceeded();
            }
            
            return false;
        }
    }
    
    /**
     * Load shopping list from localStorage
     * @returns {ShoppingList} Loaded shopping list or empty list
     */
    loadList() {
        if (!this.isAvailable) {
            console.warn('Cannot load list: localStorage not available');
            return new ShoppingList();
        }
        
        try {
            const data = localStorage.getItem(this.STORAGE_KEYS.SHOPPING_LIST);
            
            if (!data) {
                return new ShoppingList();
            }
            
            const parsedData = JSON.parse(data);
            return ShoppingList.fromJSON(parsedData);
        } catch (error) {
            console.error('Failed to load shopping list:', error);
            return new ShoppingList();
        }
    }
    
    /**
     * Save user history (frequent items, preferences)
     * @param {Object} history - User history object
     * @returns {boolean} True if save was successful
     */
    saveHistory(history) {
        if (!this.isAvailable) {
            console.warn('Cannot save history: localStorage not available');
            return false;
        }
        
        if (!history || typeof history !== 'object') {
            throw new Error('Invalid history data provided');
        }
        
        try {
            const sanitizedHistory = this.sanitizeHistory(history);
            const data = JSON.stringify(sanitizedHistory);
            localStorage.setItem(this.STORAGE_KEYS.USER_HISTORY, data);
            return true;
        } catch (error) {
            console.error('Failed to save user history:', error);
            
            if (error.name === 'QuotaExceededError') {
                this.handleStorageQuotaExceeded();
            }
            
            return false;
        }
    }
    
    /**
     * Load user history from localStorage
     * @returns {Object} User history object
     */
    loadHistory() {
        if (!this.isAvailable) {
            return { frequentItems: [], lastUpdated: new Date().toISOString() };
        }
        
        try {
            const data = localStorage.getItem(this.STORAGE_KEYS.USER_HISTORY);
            
            if (!data) {
                return { frequentItems: [], lastUpdated: new Date().toISOString() };
            }
            
            const parsedData = JSON.parse(data);
            return this.validateHistory(parsedData);
        } catch (error) {
            console.error('Failed to load user history:', error);
            return { frequentItems: [], lastUpdated: new Date().toISOString() };
        }
    }
    
    /**
     * Save user preferences
     * @param {Object} preferences - User preferences object
     * @returns {boolean} True if save was successful
     */
    savePreferences(preferences) {
        if (!this.isAvailable) {
            console.warn('Cannot save preferences: localStorage not available');
            return false;
        }
        
        if (!preferences || typeof preferences !== 'object') {
            throw new Error('Invalid preferences provided');
        }
        
        try {
            const sanitizedPrefs = this.sanitizePreferences(preferences);
            const data = JSON.stringify(sanitizedPrefs);
            localStorage.setItem(this.STORAGE_KEYS.PREFERENCES, data);
            return true;
        } catch (error) {
            console.error('Failed to save preferences:', error);
            return false;
        }
    }
    
    /**
     * Load user preferences from localStorage
     * @returns {Object} User preferences object
     */
    loadPreferences() {
        if (!this.isAvailable) {
            return { ...this.DEFAULT_PREFERENCES };
        }
        
        try {
            const data = localStorage.getItem(this.STORAGE_KEYS.PREFERENCES);
            
            if (!data) {
                return { ...this.DEFAULT_PREFERENCES };
            }
            
            const parsedData = JSON.parse(data);
            return { ...this.DEFAULT_PREFERENCES, ...parsedData };
        } catch (error) {
            console.error('Failed to load preferences:', error);
            return { ...this.DEFAULT_PREFERENCES };
        }
    }
    
    /**
     * Clear all stored data
     * @returns {boolean} True if clear was successful
     */
    clearAll() {
        if (!this.isAvailable) {
            return false;
        }
        
        try {
            Object.values(this.STORAGE_KEYS).forEach(key => {
                localStorage.removeItem(key);
            });
            return true;
        } catch (error) {
            console.error('Failed to clear storage:', error);
            return false;
        }
    }
    
    /**
     * Clear only the shopping list
     * @returns {boolean} True if clear was successful
     */
    clearList() {
        if (!this.isAvailable) {
            return false;
        }
        
        try {
            localStorage.removeItem(this.STORAGE_KEYS.SHOPPING_LIST);
            return true;
        } catch (error) {
            console.error('Failed to clear shopping list:', error);
            return false;
        }
    }
    
    /**
     * Get storage usage information
     * @returns {Object} Storage usage stats
     */
    getStorageInfo() {
        if (!this.isAvailable) {
            return { available: false, used: 0, total: 0 };
        }
        
        try {
            let used = 0;
            Object.values(this.STORAGE_KEYS).forEach(key => {
                const data = localStorage.getItem(key);
                if (data) {
                    used += data.length;
                }
            });
            
            // Estimate total localStorage size (usually 5-10MB)
            const total = 5 * 1024 * 1024; // 5MB estimate
            
            return {
                available: true,
                used: used,
                total: total,
                usedPercent: (used / total) * 100
            };
        } catch (error) {
            console.error('Failed to get storage info:', error);
            return { available: false, used: 0, total: 0 };
        }
    }
    
    /**
     * Handle storage quota exceeded error
     */
    handleStorageQuotaExceeded() {
        console.warn('Storage quota exceeded. Attempting cleanup...');
        
        try {
            // Try to clean up old history data
            const history = this.loadHistory();
            if (history.frequentItems && history.frequentItems.length > 50) {
                // Keep only the 50 most frequent items
                history.frequentItems = history.frequentItems
                    .sort((a, b) => b.frequency - a.frequency)
                    .slice(0, 50);
                this.saveHistory(history);
            }
        } catch (error) {
            console.error('Failed to cleanup storage:', error);
        }
    }
    
    /**
     * Sanitize history data before saving
     * @param {Object} history - Raw history data
     * @returns {Object} Sanitized history data
     */
    sanitizeHistory(history) {
        const sanitized = {
            frequentItems: [],
            lastUpdated: new Date().toISOString()
        };
        
        if (Array.isArray(history.frequentItems)) {
            sanitized.frequentItems = history.frequentItems
                .filter(item => item && typeof item === 'object')
                .map(item => ({
                    itemName: String(item.itemName || '').substring(0, 100),
                    frequency: Math.max(0, parseInt(item.frequency) || 0),
                    lastPurchased: item.lastPurchased || new Date().toISOString()
                }))
                .slice(0, 100); // Limit to 100 items
        }
        
        if (history.lastUpdated) {
            sanitized.lastUpdated = history.lastUpdated;
        }
        
        return sanitized;
    }
    
    /**
     * Validate and sanitize loaded history data
     * @param {Object} history - Loaded history data
     * @returns {Object} Validated history data
     */
    validateHistory(history) {
        if (!history || typeof history !== 'object') {
            return { frequentItems: [], lastUpdated: new Date().toISOString() };
        }
        
        const validated = {
            frequentItems: [],
            lastUpdated: history.lastUpdated || new Date().toISOString()
        };
        
        if (Array.isArray(history.frequentItems)) {
            validated.frequentItems = history.frequentItems
                .filter(item => 
                    item && 
                    typeof item === 'object' && 
                    item.itemName && 
                    typeof item.frequency === 'number'
                );
        }
        
        return validated;
    }
    
    /**
     * Sanitize preferences data before saving
     * @param {Object} preferences - Raw preferences data
     * @returns {Object} Sanitized preferences data
     */
    sanitizePreferences(preferences) {
        const sanitized = { ...this.DEFAULT_PREFERENCES };
        
        if (typeof preferences.language === 'string') {
            sanitized.language = preferences.language.substring(0, 10);
        }
        
        if (typeof preferences.voiceSpeed === 'number') {
            sanitized.voiceSpeed = Math.max(0.1, Math.min(3.0, preferences.voiceSpeed));
        }
        
        if (typeof preferences.autoSuggestions === 'boolean') {
            sanitized.autoSuggestions = preferences.autoSuggestions;
        }
        
        if (typeof preferences.theme === 'string') {
            sanitized.theme = ['light', 'dark'].includes(preferences.theme) 
                ? preferences.theme 
                : 'light';
        }
        
        return sanitized;
    }
    
    /**
     * Export all data as JSON string
     * @returns {string} JSON string of all data
     */
    exportData() {
        if (!this.isAvailable) {
            return JSON.stringify({});
        }
        
        const exportData = {};
        
        Object.entries(this.STORAGE_KEYS).forEach(([key, storageKey]) => {
            try {
                const data = localStorage.getItem(storageKey);
                if (data) {
                    exportData[key] = JSON.parse(data);
                }
            } catch (error) {
                console.warn(`Failed to export ${key}:`, error);
            }
        });
        
        return JSON.stringify(exportData, null, 2);
    }
    
    /**
     * Import data from JSON string
     * @param {string} jsonData - JSON string of data to import
     * @returns {boolean} True if import was successful
     */
    importData(jsonData) {
        if (!this.isAvailable) {
            return false;
        }
        
        try {
            const data = JSON.parse(jsonData);
            
            Object.entries(this.STORAGE_KEYS).forEach(([key, storageKey]) => {
                if (data[key]) {
                    localStorage.setItem(storageKey, JSON.stringify(data[key]));
                }
            });
            
            return true;
        } catch (error) {
            console.error('Failed to import data:', error);
            return false;
        }
    }
}