/**
 * ErrorHandler - Comprehensive error handling and fallback management
 * Handles various error scenarios and provides graceful degradation
 */

export class ErrorHandler {
    constructor(uiController, speechSynthesizer) {
        this.uiController = uiController;
        this.speechSynthesizer = speechSynthesizer;
        
        // Error tracking
        this.errorHistory = [];
        this.maxErrorHistory = 50;
        
        // Fallback states
        this.isOfflineMode = false;
        this.isFallbackMode = false;
        this.hasVoiceSupport = true;
        
        // Recovery suggestions
        this.recoverySuggestions = {
            'BROWSER_NOT_SUPPORTED': [
                'Try using Chrome, Edge, or Safari for voice features',
                'Use the text input below to add items',
                'Voice commands are not supported in this browser'
            ],
            'PERMISSION_DENIED': [
                'Click the microphone icon in your browser address bar',
                'Allow microphone access and refresh the page',
                'Use the text input below as an alternative'
            ],
            'AUDIO_CAPTURE': [
                'Check if your microphone is connected',
                'Try refreshing the page',
                'Use the text input below to continue'
            ],
            'NETWORK_ERROR': [
                'Check your internet connection',
                'Try again in a few moments',
                'The app will work offline with limited features'
            ],
            'NO_SPEECH': [
                'Speak more clearly and try again',
                'Make sure you\'re close to the microphone',
                'Check if your microphone is working'
            ]
        };
        
        this.init();
    }
    
    /**
     * Initialize error handler
     */
    init() {
        // Check if we're offline
        this.checkOnlineStatus();
        
        // Listen for online/offline events
        window.addEventListener('online', () => this.handleOnlineStatusChange(true));
        window.addEventListener('offline', () => this.handleOnlineStatusChange(false));
        
        // Listen for unhandled errors
        window.addEventListener('error', (event) => this.handleGlobalError(event));
        window.addEventListener('unhandledrejection', (event) => this.handleUnhandledRejection(event));
        
        console.log('ErrorHandler initialized');
    }
    
    /**
     * Handle voice processor errors
     * @param {string} errorCode - Error code from VoiceProcessor
     * @param {string} message - Error message
     * @param {Object} context - Additional context
     */
    handleVoiceError(errorCode, message, context = {}) {
        console.error('Voice error:', errorCode, message, context);
        
        // Log error
        this.logError('VOICE_ERROR', errorCode, message, context);
        
        // Get recovery suggestions
        const suggestions = this.getRecoverySuggestions(errorCode);
        
        // Handle specific error types
        switch (errorCode) {
            case 'BROWSER_NOT_SUPPORTED':
                this.enableFallbackMode();
                this.showBrowserCompatibilityError(suggestions);
                break;
                
            case 'PERMISSION_DENIED':
                this.enableFallbackMode();
                this.showPermissionError(suggestions);
                break;
                
            case 'AUDIO_CAPTURE':
                this.enableFallbackMode();
                this.showMicrophoneError(suggestions);
                break;
                
            case 'NETWORK_ERROR':
                this.handleNetworkError(suggestions);
                break;
                
            case 'NO_SPEECH':
                this.showSpeechRecognitionError(suggestions);
                break;
                
            default:
                this.showGenericError(message, suggestions);
        }
        
        // Provide audio feedback if possible
        if (this.speechSynthesizer && this.speechSynthesizer.isSupported) {
            this.speechSynthesizer.announceError(errorCode.toLowerCase(), message);
        }
    }
    
    /**
     * Handle application errors
     * @param {string} errorType - Type of error
     * @param {Error} error - Error object
     * @param {Object} context - Additional context
     */
    handleApplicationError(errorType, error, context = {}) {
        console.error('Application error:', errorType, error, context);
        
        // Log error
        this.logError('APPLICATION_ERROR', errorType, error.message, {
            ...context,
            stack: error.stack
        });
        
        // Show user-friendly error message
        const userMessage = this.getUserFriendlyMessage(errorType, error);
        this.uiController.displayError(userMessage);
        
        // Provide recovery suggestions
        const suggestions = this.getApplicationRecoverySuggestions(errorType);
        if (suggestions.length > 0) {
            this.showRecoverySuggestions(suggestions);
        }
    }
    
    /**
     * Handle network-related errors
     * @param {Array} suggestions - Recovery suggestions
     */
    handleNetworkError(suggestions) {
        if (!navigator.onLine) {
            this.enableOfflineMode();
        }
        
        this.uiController.displayError('Network connection issue detected');
        this.showRecoverySuggestions(suggestions);
        
        // Show offline mode notification if applicable
        if (this.isOfflineMode) {
            this.showOfflineModeNotification();
        }
    }
    
    /**
     * Enable fallback mode (text input instead of voice)
     */
    enableFallbackMode() {
        this.isFallbackMode = true;
        this.hasVoiceSupport = false;
        
        // Show fallback input
        this.showFallbackInput();
        
        // Hide voice controls
        this.hideVoiceControls();
        
        // Update UI to reflect fallback mode
        this.updateUIForFallbackMode();
        
        console.log('Fallback mode enabled');
    }
    
    /**
     * Enable offline mode
     */
    enableOfflineMode() {
        this.isOfflineMode = true;
        
        // Show offline notification
        this.showOfflineModeNotification();
        
        // Disable features that require network
        this.disableNetworkFeatures();
        
        console.log('Offline mode enabled');
    }
    
    /**
     * Disable offline mode when back online
     */
    disableOfflineMode() {
        this.isOfflineMode = false;
        
        // Hide offline notification
        this.hideOfflineModeNotification();
        
        // Re-enable network features
        this.enableNetworkFeatures();
        
        console.log('Offline mode disabled');
    }
    
    /**
     * Show fallback text input
     */
    showFallbackInput() {
        const fallbackInput = document.getElementById('fallback-input');
        if (fallbackInput) {
            fallbackInput.style.display = 'block';
            
            // Focus on text input for better UX
            const textInput = document.getElementById('text-input');
            if (textInput && typeof textInput.focus === 'function') {
                setTimeout(() => textInput.focus(), 100);
            }
        }
    }
    
    /**
     * Hide voice controls when in fallback mode
     */
    hideVoiceControls() {
        const voiceBtn = document.getElementById('voice-btn');
        const listeningIndicator = document.getElementById('listening-indicator');
        
        if (voiceBtn) {
            voiceBtn.style.display = 'none';
        }
        
        if (listeningIndicator) {
            listeningIndicator.style.display = 'none';
        }
    }
    
    /**
     * Update UI for fallback mode
     */
    updateUIForFallbackMode() {
        // Add fallback mode indicator
        this.showFallbackModeIndicator();
        
        // Update help text
        this.updateHelpTextForFallback();
    }
    
    /**
     * Show browser compatibility error
     * @param {Array} suggestions - Recovery suggestions
     */
    showBrowserCompatibilityError(suggestions) {
        const errorMessage = 'Voice commands are not supported in this browser';
        this.uiController.displayError(errorMessage);
        this.showRecoverySuggestions(suggestions);
        
        // Show browser compatibility notice
        this.showBrowserCompatibilityNotice();
    }
    
    /**
     * Show permission error
     * @param {Array} suggestions - Recovery suggestions
     */
    showPermissionError(suggestions) {
        const errorMessage = 'Microphone access is required for voice commands';
        this.uiController.displayError(errorMessage);
        this.showRecoverySuggestions(suggestions);
        
        // Show permission request UI
        this.showPermissionRequestUI();
    }
    
    /**
     * Show microphone error
     * @param {Array} suggestions - Recovery suggestions
     */
    showMicrophoneError(suggestions) {
        const errorMessage = 'Microphone is not available';
        this.uiController.displayError(errorMessage);
        this.showRecoverySuggestions(suggestions);
    }
    
    /**
     * Show speech recognition error
     * @param {Array} suggestions - Recovery suggestions
     */
    showSpeechRecognitionError(suggestions) {
        const errorMessage = 'Could not understand speech - please try again';
        this.uiController.displayError(errorMessage);
        this.showRecoverySuggestions(suggestions);
    }
    
    /**
     * Show generic error
     * @param {string} message - Error message
     * @param {Array} suggestions - Recovery suggestions
     */
    showGenericError(message, suggestions) {
        this.uiController.displayError(message);
        if (suggestions && suggestions.length > 0) {
            this.showRecoverySuggestions(suggestions);
        }
    }
    
    /**
     * Show recovery suggestions to user
     * @param {Array} suggestions - Array of suggestion strings
     */
    showRecoverySuggestions(suggestions) {
        if (!suggestions || suggestions.length === 0) return;
        
        // Create or update recovery suggestions element
        let suggestionsDiv = document.getElementById('recovery-suggestions');
        
        if (!suggestionsDiv) {
            suggestionsDiv = document.createElement('div');
            suggestionsDiv.id = 'recovery-suggestions';
            suggestionsDiv.className = 'recovery-suggestions';
            
            // Insert after error messages
            const errorMessage = document.getElementById('error-message');
            if (errorMessage && errorMessage.parentNode) {
                errorMessage.parentNode.insertBefore(suggestionsDiv, errorMessage.nextSibling);
            } else {
                document.querySelector('.main').prepend(suggestionsDiv);
            }
        }
        
        suggestionsDiv.innerHTML = `
            <div class="recovery-header">
                <h4>💡 Try these solutions:</h4>
            </div>
            <ul class="recovery-list">
                ${suggestions.map(suggestion => `<li>${suggestion}</li>`).join('')}
            </ul>
        `;
        
        suggestionsDiv.style.display = 'block';
        
        // Auto-hide after 15 seconds
        setTimeout(() => {
            if (suggestionsDiv) {
                suggestionsDiv.style.display = 'none';
            }
        }, 15000);
    }
    
    /**
     * Show offline mode notification
     */
    showOfflineModeNotification() {
        let offlineDiv = document.getElementById('offline-notification');
        
        if (!offlineDiv) {
            offlineDiv = document.createElement('div');
            offlineDiv.id = 'offline-notification';
            offlineDiv.className = 'offline-notification';
            offlineDiv.innerHTML = `
                <div class="offline-content">
                    <span class="offline-icon">📡</span>
                    <span class="offline-text">You're offline - some features may be limited</span>
                    <button class="offline-dismiss" onclick="this.parentElement.parentElement.style.display='none'">×</button>
                </div>
            `;
            
            document.body.prepend(offlineDiv);
        }
        
        offlineDiv.style.display = 'block';
    }
    
    /**
     * Hide offline mode notification
     */
    hideOfflineModeNotification() {
        const offlineDiv = document.getElementById('offline-notification');
        if (offlineDiv) {
            offlineDiv.style.display = 'none';
        }
    }
    
    /**
     * Show fallback mode indicator
     */
    showFallbackModeIndicator() {
        let fallbackDiv = document.getElementById('fallback-mode-indicator');
        
        if (!fallbackDiv) {
            fallbackDiv = document.createElement('div');
            fallbackDiv.id = 'fallback-mode-indicator';
            fallbackDiv.className = 'fallback-mode-indicator';
            fallbackDiv.innerHTML = `
                <div class="fallback-content">
                    <span class="fallback-icon">⌨️</span>
                    <span class="fallback-text">Using text input mode</span>
                </div>
            `;
            
            const header = document.querySelector('.header');
            if (header) {
                header.appendChild(fallbackDiv);
            }
        }
        
        fallbackDiv.style.display = 'block';
    }
    
    /**
     * Show browser compatibility notice
     */
    showBrowserCompatibilityNotice() {
        let compatDiv = document.getElementById('browser-compatibility-notice');
        
        if (!compatDiv) {
            compatDiv = document.createElement('div');
            compatDiv.id = 'browser-compatibility-notice';
            compatDiv.className = 'browser-compatibility-notice';
            compatDiv.innerHTML = `
                <div class="compat-content">
                    <h4>🌐 Browser Compatibility</h4>
                    <p>For the best experience with voice commands, try:</p>
                    <ul>
                        <li>Google Chrome (recommended)</li>
                        <li>Microsoft Edge</li>
                        <li>Safari (limited support)</li>
                    </ul>
                    <button class="compat-dismiss" onclick="this.parentElement.parentElement.style.display='none'">Got it</button>
                </div>
            `;
            
            document.querySelector('.main').prepend(compatDiv);
        }
        
        compatDiv.style.display = 'block';
    }
    
    /**
     * Show permission request UI
     */
    showPermissionRequestUI() {
        const permissionsNotice = document.getElementById('permissions-notice');
        if (permissionsNotice) {
            permissionsNotice.style.display = 'block';
        }
    }
    
    /**
     * Update help text for fallback mode
     */
    updateHelpTextForFallback() {
        const helpText = document.querySelector('.help-text');
        if (helpText) {
            helpText.innerHTML = `
                <p><strong>Type these commands in the text box below:</strong></p>
                <ul>
                    <li>"Add milk"</li>
                    <li>"Buy 2 apples"</li>
                    <li>"I need bread"</li>
                    <li>"Remove cheese"</li>
                    <li>"Clear list"</li>
                </ul>
                <p><em>Voice commands are not available in this browser</em></p>
            `;
        }
    }
    
    /**
     * Handle online/offline status changes
     * @param {boolean} isOnline - Whether the browser is online
     */
    handleOnlineStatusChange(isOnline) {
        if (isOnline && this.isOfflineMode) {
            this.disableOfflineMode();
            this.uiController.displaySuccess('Connection restored');
        } else if (!isOnline && !this.isOfflineMode) {
            this.enableOfflineMode();
        }
    }
    
    /**
     * Check current online status
     */
    checkOnlineStatus() {
        if (!navigator.onLine) {
            this.enableOfflineMode();
        }
    }
    
    /**
     * Disable network-dependent features
     */
    disableNetworkFeatures() {
        // Disable features that require network connectivity
        // This is a placeholder for future network-dependent features
        console.log('Network features disabled for offline mode');
    }
    
    /**
     * Enable network-dependent features
     */
    enableNetworkFeatures() {
        // Re-enable features that require network connectivity
        console.log('Network features enabled');
    }
    
    /**
     * Handle global JavaScript errors
     * @param {ErrorEvent} event - Error event
     */
    handleGlobalError(event) {
        console.error('Global error:', event.error);
        
        this.logError('GLOBAL_ERROR', 'JavaScript Error', event.message, {
            filename: event.filename,
            lineno: event.lineno,
            colno: event.colno,
            stack: event.error?.stack
        });
        
        // Show user-friendly error message
        this.uiController.displayError('An unexpected error occurred. Please refresh the page if problems persist.');
    }
    
    /**
     * Handle unhandled promise rejections
     * @param {PromiseRejectionEvent} event - Promise rejection event
     */
    handleUnhandledRejection(event) {
        console.error('Unhandled promise rejection:', event.reason);
        
        this.logError('PROMISE_REJECTION', 'Unhandled Promise', event.reason?.message || 'Unknown error', {
            reason: event.reason
        });
        
        // Prevent the default browser behavior
        event.preventDefault();
        
        // Show user-friendly error message
        this.uiController.displayError('A background operation failed. The app should continue to work normally.');
    }
    
    /**
     * Log error for debugging and analytics
     * @param {string} category - Error category
     * @param {string} type - Error type
     * @param {string} message - Error message
     * @param {Object} context - Additional context
     */
    logError(category, type, message, context = {}) {
        const errorEntry = {
            timestamp: new Date().toISOString(),
            category,
            type,
            message,
            context,
            userAgent: navigator.userAgent,
            url: window.location.href
        };
        
        // Add to error history
        this.errorHistory.push(errorEntry);
        
        // Keep only recent errors
        if (this.errorHistory.length > this.maxErrorHistory) {
            this.errorHistory.shift();
        }
        
        // In a real app, you might send this to an error tracking service
        console.log('Error logged:', errorEntry);
    }
    
    /**
     * Get recovery suggestions for error code
     * @param {string} errorCode - Error code
     * @returns {Array} Array of suggestion strings
     */
    getRecoverySuggestions(errorCode) {
        return this.recoverySuggestions[errorCode] || [];
    }
    
    /**
     * Get application-specific recovery suggestions
     * @param {string} errorType - Type of application error
     * @returns {Array} Array of suggestion strings
     */
    getApplicationRecoverySuggestions(errorType) {
        const suggestions = {
            'STORAGE_ERROR': [
                'Clear your browser cache and cookies',
                'Try using the app in an incognito/private window',
                'Check if you have enough storage space'
            ],
            'PARSING_ERROR': [
                'Try rephrasing your command',
                'Use simpler language',
                'Check the examples for proper format'
            ],
            'VALIDATION_ERROR': [
                'Check that item names contain only valid characters',
                'Ensure quantities are in a valid format',
                'Try adding items one at a time'
            ]
        };
        
        return suggestions[errorType] || [];
    }
    
    /**
     * Get user-friendly error message
     * @param {string} errorType - Error type
     * @param {Error} error - Original error
     * @returns {string} User-friendly message
     */
    getUserFriendlyMessage(errorType, error) {
        const messages = {
            'STORAGE_ERROR': 'Unable to save your shopping list. Your changes may not be preserved.',
            'PARSING_ERROR': 'Could not understand your command. Please try rephrasing it.',
            'VALIDATION_ERROR': 'The item information is not valid. Please check and try again.',
            'NETWORK_ERROR': 'Network connection issue. Some features may not work properly.',
            'UNKNOWN_ERROR': 'An unexpected error occurred. Please try again.'
        };
        
        return messages[errorType] || messages['UNKNOWN_ERROR'];
    }
    
    /**
     * Get error statistics for debugging
     * @returns {Object} Error statistics
     */
    getErrorStatistics() {
        const stats = {
            totalErrors: this.errorHistory.length,
            errorsByCategory: {},
            errorsByType: {},
            recentErrors: this.errorHistory.slice(-10)
        };
        
        this.errorHistory.forEach(error => {
            stats.errorsByCategory[error.category] = (stats.errorsByCategory[error.category] || 0) + 1;
            stats.errorsByType[error.type] = (stats.errorsByType[error.type] || 0) + 1;
        });
        
        return stats;
    }
    
    /**
     * Clear error history
     */
    clearErrorHistory() {
        this.errorHistory = [];
        console.log('Error history cleared');
    }
    
    /**
     * Check if app is in fallback mode
     * @returns {boolean} True if in fallback mode
     */
    isFallbackModeEnabled() {
        return this.isFallbackMode;
    }
    
    /**
     * Check if app is in offline mode
     * @returns {boolean} True if in offline mode
     */
    isOfflineModeEnabled() {
        return this.isOfflineMode;
    }
    
    /**
     * Check if voice support is available
     * @returns {boolean} True if voice is supported
     */
    hasVoiceSupportAvailable() {
        return this.hasVoiceSupport;
    }
}