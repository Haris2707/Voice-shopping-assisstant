/**
 * Voice Shopping Assistant - Main Application Module
 * Handles initialization, microphone permissions, and basic UI interactions
 */

import { ShoppingListManager } from './models/ShoppingListManager.js';
import { UIController } from './ui/UIController.js';
import { VoiceProcessor } from './models/VoiceProcessor.js';
import { NLPParser } from './models/NLPParser.js';
import { SpeechSynthesizer } from './models/SpeechSynthesizer.js';
import { SuggestionEngine } from './models/SuggestionEngine.js';
import { SearchEngine } from './models/SearchEngine.js';
import { ErrorHandler } from './models/ErrorHandler.js';
import { OnboardingManager } from './ui/OnboardingManager.js';
import { KeyboardShortcutsManager } from './ui/KeyboardShortcutsManager.js';
import { LoadingManager } from './ui/LoadingManager.js';

class VoiceShoppingApp {
    constructor() {
        // Initialize shopping list manager
        this.listManager = new ShoppingListManager();
        
        // Initialize suggestion engine
        this.suggestionEngine = new SuggestionEngine(this.listManager.storage);
        
        // Initialize search engine
        this.searchEngine = new SearchEngine();
        
        // Initialize UI controller
        this.uiController = null; // Will be initialized after DOM elements are set up
        
        // Initialize voice processor
        this.voiceProcessor = null; // Will be initialized after DOM elements are set up
        
        // Initialize NLP parser with current language
        this.nlpParser = new NLPParser(this.currentLanguage);
        
        // Initialize speech synthesizer with current language
        this.speechSynthesizer = new SpeechSynthesizer(this.currentLanguage);
        
        // Initialize error handler (will be set up after UI controller)
        this.errorHandler = null;
        
        // Initialize UI enhancement managers
        this.loadingManager = new LoadingManager();
        this.onboardingManager = null; // Will be initialized after DOM setup
        this.keyboardManager = null; // Will be initialized after app setup
        
        // Current language
        this.currentLanguage = 'en-US';
        
        // Current suggestions for voice command processing
        this.currentSuggestions = [];
        
        // Current substitutes for voice command processing
        this.currentSubstitutes = [];
        
        // Mobile detection and optimization
        this.isMobile = this.detectMobile();
        this.mobileOptimizations = {
            reducedAnimations: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
            touchSupport: 'ontouchstart' in window,
            isLandscape: false
        };
        
        // DOM elements
        this.elements = {
            voiceBtn: document.getElementById('voice-btn'),
            statusIndicator: document.getElementById('status-indicator'),
            listeningIndicator: document.getElementById('listening-indicator'),
            permissionsNotice: document.getElementById('permissions-notice'),
            requestPermissionsBtn: document.getElementById('request-permissions'),
            fallbackInput: document.getElementById('fallback-input'),
            textInput: document.getElementById('text-input'),
            textSubmit: document.getElementById('text-submit'),
            shoppingList: document.getElementById('shopping-list'),
            emptyState: document.getElementById('empty-state'),
            suggestions: document.getElementById('suggestions'),
            languageSelect: document.getElementById('language-select'),
            helpBtn: document.getElementById('help-btn')
        };
        
        this.init();
    }
    
    /**
     * Detect if the device is mobile
     * @returns {boolean} True if mobile device
     */
    detectMobile() {
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
               (window.innerWidth <= 768) ||
               ('ontouchstart' in window);
    }
    
    /**
     * Initialize the application
     */
    async init() {
        console.log('Initializing Voice Shopping Assistant...');
        
        // Show app loading
        this.loadingManager.showAppLoading();
        this.loadingManager.updateAppLoading(10, 'Setting up UI components...');
        
        // Initialize UI controller
        this.uiController = new UIController(this.listManager);
        
        // Initialize error handler
        this.errorHandler = new ErrorHandler(this.uiController, this.speechSynthesizer);
        
        // Get accessibility manager from UI controller
        this.accessibilityManager = this.uiController.accessibilityManager;
        
        this.loadingManager.updateAppLoading(30, 'Initializing voice processing...');
        
        // Set up suggestion callback
        this.uiController.setSuggestionAcceptedCallback((suggestion) => {
            this.handleSuggestionAccepted(suggestion);
        });
        
        // Initialize voice processor with callbacks
        this.voiceProcessor = new VoiceProcessor(
            (command) => this.processVoiceCommand(command),
            (errorCode, message) => this.handleVoiceError(errorCode, message),
            (status, message) => this.handleStatusChange(status, message)
        );
        
        this.loadingManager.updateAppLoading(50, 'Setting up event listeners...');
        
        // Set up event listeners
        this.setupEventListeners();
        
        // Set up mobile-specific features
        if (this.isMobile) {
            this.setupMobileOptimizations();
        }
        
        this.loadingManager.updateAppLoading(70, 'Initializing UI enhancements...');
        
        // Initialize UI enhancement managers
        this.onboardingManager = new OnboardingManager();
        this.keyboardManager = new KeyboardShortcutsManager(this);
        
        // Make managers globally available
        window.onboardingManager = this.onboardingManager;
        window.keyboardManager = this.keyboardManager;
        
        this.loadingManager.updateAppLoading(85, 'Finalizing setup...');
        
        // Initialize UI state
        this.updateUI();
        
        // Show smart suggestions instead of sample ones
        this.showSmartSuggestions();
        
        this.loadingManager.updateAppLoading(100, 'Ready!');
        
        // Hide app loading after a brief delay
        setTimeout(() => {
            this.loadingManager.hideAppLoading();
        }, 500);
        
        // Provide welcome message if speech synthesis is supported
        if (this.speechSynthesizer.isSupported) {
            setTimeout(() => {
                this.speechSynthesizer.provideGuidance('welcome');
            }, 1500);
        }
        
        console.log('Voice Shopping Assistant initialized');
    }
    
    /**
     * Show toast notification
     * @param {string} type - Toast type (success, error, warning, info)
     * @param {string} title - Toast title
     * @param {string} message - Toast message
     */
    showToast(type, title, message) {
        if (this.onboardingManager) {
            const toast = this.onboardingManager.createToast(type, title, message);
            this.onboardingManager.showToast(toast);
        }
    }
    
    /**
     * Get current suggestions for voice command processing
     * @returns {Array} Current suggestions
     */
    getCurrentSuggestions() {
        return this.currentSuggestions || [];
    }
    
    /**
     * Highlight an item in the shopping list
     * @param {string} itemName - Name of item to highlight
     */
    highlightItem(itemName) {
        if (this.uiController) {
            this.uiController.highlightItem(itemName);
        }
    }
    
    /**
     * Handle voice processor status changes
     */
    handleStatusChange(status, message) {
        switch (status) {
            case 'LISTENING':
                this.updateStatus(message);
                this.uiController.showListeningIndicator();
                this.updateUI();
                break;
            case 'READY':
                this.updateStatus(message);
                this.uiController.hideListeningIndicator();
                this.updateUI();
                break;
            case 'INTERIM':
                this.updateStatus(message);
                // Show what we're hearing in real-time
                if (message.includes('Hearing:')) {
                    const transcript = message.replace('Hearing: "', '').replace('"', '');
                    this.uiController.showVoiceProcessing(transcript);
                }
                break;
            case 'ERROR':
                this.updateStatus(message);
                this.uiController.hideListeningIndicator();
                this.updateUI();
                break;
            case 'PERMISSION_GRANTED':
                this.hidePermissionsNotice();
                this.updateStatus(message);
                break;
            case 'PERMISSION_CHANGED':
                this.updateUI();
                break;
            default:
                this.updateStatus(message);
        }
    }
    
    /**
     * Handle voice processor errors
     */
    handleVoiceError(errorCode, message) {
        // Delegate to error handler for comprehensive error management
        this.errorHandler.handleVoiceError(errorCode, message, {
            currentLanguage: this.currentLanguage,
            isListening: this.voiceProcessor?.getIsListening(),
            hasPermissions: this.voiceProcessor?.getHasPermissions()
        });
        
        // Update UI state
        this.updateUI();
    }
    
    /**
     * Set up event listeners for UI interactions
     */
    setupEventListeners() {
        // Voice button click
        this.elements.voiceBtn.addEventListener('click', () => {
            this.toggleListening();
        });
        
        // Request permissions button
        this.elements.requestPermissionsBtn.addEventListener('click', () => {
            this.voiceProcessor.requestMicrophonePermissions();
        });
        
        // Fallback text input
        this.elements.textSubmit.addEventListener('click', () => {
            this.processTextCommand();
        });
        
        this.elements.textInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.processTextCommand();
            }
        });
        
        // Language selector change
        this.elements.languageSelect.addEventListener('change', (e) => {
            this.changeLanguage(e.target.value);
        });
        
        // Help button click
        this.elements.helpBtn.addEventListener('click', () => {
            if (this.keyboardManager) {
                this.keyboardManager.toggleHelp();
            }
        });
        
        // Listen for shopping list changes to update suggestions
        this.listManager.addEventListener('itemAdded', (item) => {
            this.handleItemAdded(item);
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Space bar to toggle listening (when not typing in input)
            if (e.code === 'Space' && e.target !== this.elements.textInput) {
                e.preventDefault();
                this.toggleListening();
            }
        });
    }
    

    
    /**
     * Set up mobile-specific optimizations
     */
    setupMobileOptimizations() {
        console.log('Setting up mobile optimizations...');
        
        // Add mobile class to body
        document.body.classList.add('mobile-device');
        
        // Handle orientation changes
        window.addEventListener('orientationchange', () => {
            setTimeout(() => {
                this.handleOrientationChange();
            }, 100);
        });
        
        // Handle viewport changes for mobile keyboards
        this.setupMobileViewportHandler();
        
        // Optimize voice button for mobile
        this.optimizeVoiceButtonForMobile();
        
        // Handle mobile-specific touch events
        this.setupMobileTouchHandling();
        
        // Prevent zoom on double tap
        this.preventMobileZoom();
    }
    
    /**
     * Handle orientation changes on mobile
     */
    handleOrientationChange() {
        const isLandscape = Math.abs(window.orientation) === 90;
        this.mobileOptimizations.isLandscape = isLandscape;
        
        document.body.classList.toggle('landscape', isLandscape);
        document.body.classList.toggle('portrait', !isLandscape);
        
        // Adjust UI for orientation
        if (isLandscape) {
            // Compact layout for landscape
            this.elements.voiceBtn.style.minWidth = '140px';
        } else {
            // Standard layout for portrait
            this.elements.voiceBtn.style.minWidth = '180px';
        }
        
        // Update UI
        this.updateUI();
    }
    
    /**
     * Set up mobile viewport handler for keyboard detection
     */
    setupMobileViewportHandler() {
        let initialViewportHeight = window.innerHeight;
        
        window.addEventListener('resize', () => {
            const currentHeight = window.innerHeight;
            const heightDifference = initialViewportHeight - currentHeight;
            
            // If height decreased significantly, keyboard is likely open
            if (heightDifference > 150) {
                document.body.classList.add('keyboard-open');
                this.handleMobileKeyboardOpen();
            } else {
                document.body.classList.remove('keyboard-open');
                this.handleMobileKeyboardClose();
            }
        });
    }
    
    /**
     * Handle mobile keyboard opening
     */
    handleMobileKeyboardOpen() {
        // Stop voice recognition when keyboard opens
        if (this.voiceProcessor.getIsListening()) {
            this.voiceProcessor.stopListening();
            this.updateStatus('Voice paused for text input');
        }
        
        // Scroll to active input if needed
        const activeElement = document.activeElement;
        if (activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA')) {
            setTimeout(() => {
                activeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 300);
        }
    }
    
    /**
     * Handle mobile keyboard closing
     */
    handleMobileKeyboardClose() {
        // Restore normal layout
        this.updateUI();
    }
    
    /**
     * Optimize voice button for mobile interaction
     */
    optimizeVoiceButtonForMobile() {
        const voiceBtn = this.elements.voiceBtn;
        
        // Add mobile-specific touch feedback
        voiceBtn.addEventListener('touchstart', () => {
            voiceBtn.classList.add('touch-active');
        }, { passive: true });
        
        voiceBtn.addEventListener('touchend', () => {
            setTimeout(() => {
                voiceBtn.classList.remove('touch-active');
            }, 150);
        }, { passive: true });
        
        // Prevent context menu on long press
        voiceBtn.addEventListener('contextmenu', (e) => {
            e.preventDefault();
        });
    }
    
    /**
     * Set up mobile touch handling
     */
    setupMobileTouchHandling() {
        // Handle touch events for better mobile interaction
        document.addEventListener('touchstart', (e) => {
            // Add touch feedback to interactive elements
            const target = e.target.closest('button, .suggestion-item, .shopping-item');
            if (target) {
                target.classList.add('touch-feedback');
            }
        }, { passive: true });
        
        document.addEventListener('touchend', (e) => {
            // Remove touch feedback
            const target = e.target.closest('button, .suggestion-item, .shopping-item');
            if (target) {
                setTimeout(() => {
                    target.classList.remove('touch-feedback');
                }, 150);
            }
        }, { passive: true });
    }
    
    /**
     * Prevent zoom on double tap for mobile
     */
    preventMobileZoom() {
        let lastTouchEnd = 0;
        document.addEventListener('touchend', (event) => {
            const now = (new Date()).getTime();
            if (now - lastTouchEnd <= 300) {
                event.preventDefault();
            }
            lastTouchEnd = now;
        }, false);
    }
    
    /**
     * Toggle voice listening state
     */
    toggleListening() {
        if (!this.voiceProcessor.getIsSupported()) {
            console.warn('Speech recognition not available');
            this.showToast('error', 'Voice Not Supported', 'Voice recognition is not available in your browser.');
            return;
        }
        
        const voiceBtn = this.elements.voiceBtn;
        
        if (this.voiceProcessor.getIsListening()) {
            this.voiceProcessor.stopListening();
            voiceBtn.classList.remove('listening');
            this.loadingManager.hideVoiceListening();
        } else {
            this.voiceProcessor.startListening();
            voiceBtn.classList.add('listening');
            this.loadingManager.showVoiceListening();
        }
    }
    
    /**
     * Change the application language
     * @param {string} language - Language code
     */
    changeLanguage(language) {
        console.log(`Changing language to: ${language}`);
        this.currentLanguage = language;
        
        // Update voice processor language
        this.voiceProcessor.setLanguage(language);
        
        // Update NLP parser language
        this.nlpParser.setLanguage(language);
        
        // Update speech synthesizer language
        this.speechSynthesizer.setLanguage(language);
        
        // Update UI language selector
        this.elements.languageSelect.value = language;
        
        // Provide audio confirmation in new language
        setTimeout(() => {
            this.speechSynthesizer.speak(this.speechSynthesizer.getLocalizedMessage('welcome'));
        }, 500);
        
        this.updateStatus(`Language changed to ${language}`);
    }
    
    /**
     * Process text command from fallback input
     */
    processTextCommand() {
        const textInput = this.elements.textInput;
        const command = textInput.value.trim();
        
        if (!command) {
            this.uiController.displayError('Please enter a command');
            return;
        }
        
        // Clear the input
        textInput.value = '';
        
        // Process the command using the same logic as voice commands
        this.processCommand(command, 'text');
    }
    
    /**
     * Process voice command using NLP parser integration
     */
    processVoiceCommand(transcript) {
        this.processCommand(transcript, 'voice');
    }
    
    /**
     * Process command from either voice or text input
     * @param {string} transcript - The command text
     * @param {string} source - Source of command ('voice' or 'text')
     */
    processCommand(transcript, source = 'voice') {
        console.log(`Processing ${source} command:`, transcript);
        
        if (source === 'voice') {
            this.updateStatus(`Heard: "${transcript}"`);
            // Show visual feedback that we're processing
            this.uiController.showVoiceProcessing(transcript);
        } else {
            this.updateStatus(`Processing: "${transcript}"`);
        }
        
        // Try to auto-detect language and switch if needed
        const languageSwitched = this.voiceProcessor.autoSwitchLanguage(transcript);
        if (languageSwitched) {
            const newLanguage = this.voiceProcessor.getLanguage();
            if (newLanguage !== this.currentLanguage) {
                console.log(`Auto-detected language change: ${this.currentLanguage} -> ${newLanguage}`);
                this.changeLanguage(newLanguage);
            }
        }
        
        try {
            // First check if this is a suggestion command
            const currentSuggestions = this.getCurrentSuggestions();
            const suggestionCommand = this.suggestionEngine.processVoiceSuggestionCommand(transcript, currentSuggestions);
            
            if (suggestionCommand) {
                this.handleSuggestionCommand(suggestionCommand);
                return;
            }
            
            // Use NLP parser to parse the command
            const parsedCommand = this.nlpParser.parseCommand(transcript);
            
            if (!parsedCommand) {
                this.handleUnrecognizedCommand(transcript);
                return;
            }
            
            console.log('Parsed command:', parsedCommand);
            
            // Process the parsed command based on intent
            switch (parsedCommand.intent) {
                case 'add':
                    this.handleAddCommand(parsedCommand);
                    break;
                case 'add_search_result':
                    this.handleAddSearchResultCommand(parsedCommand);
                    break;
                case 'remove':
                    this.handleRemoveCommand(parsedCommand);
                    break;
                case 'search':
                    this.handleSearchCommand(parsedCommand);
                    break;
                case 'help':
                    this.handleHelpCommand();
                    break;
                case 'list':
                    this.handleListCommand();
                    break;
                case 'clear':
                    this.handleClearCommand();
                    break;
                case 'request_substitutes':
                    this.handleRequestSubstitutesCommand(parsedCommand);
                    break;
                case 'accept_substitute':
                    this.handleAcceptSubstituteCommand(parsedCommand);
                    break;
                case 'decline_substitutes':
                    this.handleDeclineSubstitutesCommand();
                    break;
                default:
                    this.handleUnrecognizedCommand(transcript);
            }
        } catch (error) {
            console.error(`Error processing ${source} command:`, error);
            this.errorHandler.handleApplicationError('PARSING_ERROR', error, {
                command: transcript,
                source: source,
                currentLanguage: this.currentLanguage
            });
        }
        
        // Reset status after a delay
        setTimeout(() => {
            this.updateStatus('Ready');
        }, 3000);
    }
    
    /**
     * Show fallback input for text commands
     */
    showFallbackInput() {
        const fallbackInput = this.elements.fallbackInput;
        if (fallbackInput) {
            fallbackInput.style.display = 'block';
        }
    }
    
    /**
     * Show permissions notice
     */
    showPermissionsNotice() {
        const permissionsNotice = this.elements.permissionsNotice;
        if (permissionsNotice) {
            permissionsNotice.style.display = 'block';
        }
    }
    
    /**
     * Hide permissions notice
     */
    hidePermissionsNotice() {
        const permissionsNotice = this.elements.permissionsNotice;
        if (permissionsNotice) {
            permissionsNotice.style.display = 'none';
        }
    }
    
    /**
     * Handle add commands from NLP parser
     * @param {Object} parsedCommand - Parsed command object
     */
    handleAddCommand(parsedCommand) {
        if (!parsedCommand.items || parsedCommand.items.length === 0) {
            this.updateStatus('Could not understand what to add');
            this.uiController.displayError('Please specify what item to add');
            return;
        }
        
        let addedItems = [];
        let errors = [];
        
        // Process each item in the command
        parsedCommand.items.forEach(item => {
            try {
                const addedItem = this.listManager.addItem(item.name, item.quantity);
                addedItems.push(addedItem);
                
                // Highlight the added item
                this.uiController.highlightItem(item.name);
                
                console.log(`Added item: ${item.name} (${item.quantity})`);
            } catch (error) {
                console.error(`Error adding item ${item.name}:`, error);
                this.errorHandler.handleApplicationError('VALIDATION_ERROR', error, {
                    itemName: item.name,
                    quantity: item.quantity,
                    operation: 'add'
                });
                errors.push(`${item.name}: ${error.message}`);
            }
        });
        
        // Provide feedback to user
        if (addedItems.length > 0) {
            const itemNames = addedItems.map(item => `${item.quantity} ${item.name}`).join(', ');
            this.updateStatus(`Added ${itemNames} to your list`);
            this.uiController.displaySuccess(`Added ${itemNames}`);
            this.uiController.showVoiceResult(`Added ${itemNames}`, true);
            
            // Provide audio confirmation
            if (addedItems.length === 1) {
                const item = addedItems[0];
                this.speechSynthesizer.confirmAction('added', item.name, item.quantity);
            } else {
                this.speechSynthesizer.speak(`Added ${addedItems.length} items to your shopping list`);
            }
        }
        
        if (errors.length > 0) {
            const errorMessage = `Failed to add: ${errors.join(', ')}`;
            this.uiController.displayError(errorMessage);
            this.uiController.showVoiceResult(errorMessage, false);
            this.speechSynthesizer.announceError('invalid_command', errorMessage);
        }
    }
    
    /**
     * Handle add search result commands from voice
     * @param {Object} parsedCommand - Parsed command object with resultIndex
     */
    handleAddSearchResultCommand(parsedCommand) {
        console.log('Processing add search result command:', parsedCommand);
        
        if (!this.currentSearchResults || !this.currentSearchResults.results) {
            this.updateStatus('No search results available');
            this.uiController.displayError('Please search for products first');
            this.uiController.showVoiceResult('No search results available', false);
            this.speechSynthesizer.speak('Please search for products first before adding results');
            return;
        }
        
        const resultIndex = parsedCommand.resultIndex;
        const searchResults = this.currentSearchResults.results;
        
        if (resultIndex < 1 || resultIndex > searchResults.length) {
            this.updateStatus(`Result ${resultIndex} not found`);
            this.uiController.displayError(`Result ${resultIndex} is not available. Please choose a number between 1 and ${searchResults.length}`);
            this.uiController.showVoiceResult(`Result ${resultIndex} not found`, false);
            this.speechSynthesizer.speak(`Result ${resultIndex} is not available. Please choose a number between 1 and ${searchResults.length}`);
            return;
        }
        
        try {
            // Get the product from search results (convert to 0-based index)
            const product = searchResults[resultIndex - 1];
            const productForList = this.searchEngine.getProductForList(product.id, '1');
            
            // Add to shopping list
            const addedItem = this.listManager.addItem(productForList.name, productForList.quantity);
            
            // Provide feedback
            const message = `Added ${productForList.name} to your list`;
            this.updateStatus(message);
            this.uiController.displaySuccess(message);
            this.uiController.showVoiceResult(message, true);
            this.uiController.highlightItem(productForList.name);
            
            // Provide audio confirmation
            this.speechSynthesizer.confirmAction('added', productForList.name, productForList.quantity);
            
            // Remove the search result item from UI if it exists
            const resultItem = document.querySelector(`[data-result-index="${resultIndex}"]`);
            if (resultItem) {
                resultItem.style.opacity = '0.5';
                resultItem.style.transform = 'translateX(20px)';
                setTimeout(() => {
                    if (resultItem.parentNode) {
                        resultItem.remove();
                    }
                }, 500);
            }
            
            console.log(`Added search result ${resultIndex}: ${productForList.name}`);
            
        } catch (error) {
            console.error('Error adding search result:', error);
            const errorMessage = `Failed to add result ${resultIndex}: ${error.message}`;
            this.updateStatus(errorMessage);
            this.uiController.displayError(errorMessage);
            this.uiController.showVoiceResult(errorMessage, false);
            this.speechSynthesizer.announceError('invalid_command', errorMessage);
        }
    }
    
    /**
     * Handle remove commands from NLP parser
     * @param {Object} parsedCommand - Parsed command object
     */
    handleRemoveCommand(parsedCommand) {
        if (!parsedCommand.items || parsedCommand.items.length === 0) {
            this.updateStatus('Could not understand what to remove');
            this.uiController.displayError('Please specify what item to remove');
            return;
        }
        
        let removedItems = [];
        let notFoundItems = [];
        
        // Process each item in the command
        parsedCommand.items.forEach(item => {
            try {
                const wasRemoved = this.listManager.removeItem(item.name);
                
                if (wasRemoved) {
                    removedItems.push(item.name);
                    console.log(`Removed item: ${item.name}`);
                } else {
                    notFoundItems.push(item.name);
                    console.log(`Item not found: ${item.name}`);
                }
            } catch (error) {
                console.error(`Error removing item ${item.name}:`, error);
                notFoundItems.push(item.name);
            }
        });
        
        // Provide feedback to user
        if (removedItems.length > 0) {
            const itemNames = removedItems.join(', ');
            this.updateStatus(`Removed ${itemNames} from your list`);
            this.uiController.displaySuccess(`Removed ${itemNames}`);
            this.uiController.showVoiceResult(`Removed ${itemNames}`, true);
            
            // Provide audio confirmation
            if (removedItems.length === 1) {
                this.speechSynthesizer.confirmAction('removed', removedItems[0]);
            } else {
                this.speechSynthesizer.speak(`Removed ${removedItems.length} items from your shopping list`);
            }
        }
        
        if (notFoundItems.length > 0) {
            const itemNames = notFoundItems.join(', ');
            const errorMessage = `Items not found in your list: ${itemNames}`;
            this.updateStatus(`Items not found: ${itemNames}`);
            this.uiController.displayError(errorMessage);
            this.uiController.showVoiceResult(errorMessage, false);
            this.speechSynthesizer.announceError('not_found', `${itemNames} not found in your shopping list`);
        }
    }
    
    /**
     * Handle search commands from NLP parser
     * @param {Object} parsedCommand - Parsed command object
     */
    handleSearchCommand(parsedCommand) {
        console.log('Processing search command:', parsedCommand.criteria);
        
        try {
            // Perform the search
            const searchResults = this.searchEngine.search(parsedCommand.criteria);
            
            // Update status
            this.updateStatus(searchResults.summary);
            
            // Display results visually
            const displayData = this.searchEngine.formatResultsForDisplay(searchResults);
            this.uiController.displaySearchResults(displayData);
            
            // Provide voice feedback
            const voiceText = this.searchEngine.formatResultsForVoice(searchResults);
            this.speechSynthesizer.speak(voiceText);
            this.uiController.showVoiceResult(searchResults.summary, searchResults.results.length > 0);
            
            // Store current search results for potential follow-up commands
            this.currentSearchResults = searchResults;
            
            console.log('Search completed:', searchResults);
            
        } catch (error) {
            console.error('Error performing search:', error);
            const errorMessage = 'Sorry, I encountered an error while searching for products';
            this.updateStatus(errorMessage);
            this.uiController.displayError(errorMessage);
            this.uiController.showVoiceResult(errorMessage, false);
            this.speechSynthesizer.announceError('search_error', errorMessage);
        }
    }
    
    /**
     * Handle request substitutes commands
     * @param {Object} parsedCommand - Parsed command object
     */
    handleRequestSubstitutesCommand(parsedCommand) {
        const itemName = parsedCommand.itemName;
        console.log('Requesting substitutes for:', itemName);
        
        // Get substitutes from suggestion engine
        const substitutes = this.suggestionEngine.getSubstitutes(itemName);
        
        if (substitutes.length === 0) {
            const message = `Sorry, I don't have any substitutes for ${itemName}`;
            this.updateStatus(message);
            this.uiController.showVoiceResult(message, false);
            this.speechSynthesizer.speak(message);
            return;
        }
        
        // Store current substitutes for voice commands
        this.currentSubstitutes = substitutes;
        
        // Show substitutes in UI
        this.uiController.showSubstituteSuggestions(itemName, substitutes);
        
        // Provide voice feedback
        const message = `Found ${substitutes.length} substitute${substitutes.length > 1 ? 's' : ''} for ${itemName}`;
        this.updateStatus(message);
        this.uiController.showVoiceResult(message, true);
        
        // Announce substitutes via voice
        let voiceMessage = `Here are alternatives for ${itemName}: `;
        substitutes.forEach((substitute, index) => {
            voiceMessage += `${index + 1}. ${substitute.itemName} - ${substitute.reason}. `;
        });
        voiceMessage += 'Say "accept substitute" followed by a number to add one, or "decline substitutes" to skip.';
        
        this.speechSynthesizer.speak(voiceMessage);
    }
    
    /**
     * Handle accept substitute commands
     * @param {Object} parsedCommand - Parsed command object
     */
    handleAcceptSubstituteCommand(parsedCommand) {
        if (!this.currentSubstitutes || this.currentSubstitutes.length === 0) {
            const message = 'No substitutes available to accept';
            this.updateStatus(message);
            this.uiController.showVoiceResult(message, false);
            this.speechSynthesizer.speak(message);
            return;
        }
        
        const substituteIndex = parsedCommand.substituteIndex;
        
        if (substituteIndex < 0 || substituteIndex >= this.currentSubstitutes.length) {
            const message = `Invalid substitute number. Please choose between 1 and ${this.currentSubstitutes.length}`;
            this.updateStatus(message);
            this.uiController.showVoiceResult(message, false);
            this.speechSynthesizer.speak(message);
            return;
        }
        
        const selectedSubstitute = this.currentSubstitutes[substituteIndex];
        
        // Add the substitute to the shopping list
        try {
            this.listManager.addItem(selectedSubstitute.itemName, '1', null);
            this.suggestionEngine.updateHistory(selectedSubstitute.itemName);
            
            // Update UI
            this.uiController.updateShoppingList(this.listManager.getList());
            
            // Hide substitute suggestions
            const substituteDiv = document.getElementById('substitute-suggestions');
            if (substituteDiv) {
                substituteDiv.style.display = 'none';
            }
            
            // Clear current substitutes
            this.currentSubstitutes = [];
            
            const message = `Added ${selectedSubstitute.itemName} to your list`;
            this.updateStatus(message);
            this.uiController.showVoiceResult(message, true);
            this.speechSynthesizer.speak(`${selectedSubstitute.itemName} added to your shopping list`);
            
            console.log('Substitute accepted and added:', selectedSubstitute);
        } catch (error) {
            console.error('Error adding substitute:', error);
            this.updateStatus('Error adding substitute');
            this.uiController.displayError(`Error: ${error.message}`);
            this.uiController.showVoiceResult(`Error: ${error.message}`, false);
        }
    }
    
    /**
     * Handle decline substitutes commands
     */
    handleDeclineSubstitutesCommand() {
        // Hide substitute suggestions
        const substituteDiv = document.getElementById('substitute-suggestions');
        if (substituteDiv) {
            substituteDiv.style.display = 'none';
        }
        
        // Clear current substitutes
        this.currentSubstitutes = [];
        
        const message = 'Substitutes declined';
        this.updateStatus(message);
        this.uiController.showVoiceResult(message, true);
        this.speechSynthesizer.speak('Okay, skipping substitutes');
        
        console.log('Substitutes declined');
    }
    
    /**
     * Handle help commands
     */
    handleHelpCommand() {
        this.updateStatus('Providing help');
        this.uiController.showVoiceResult('Help information provided', true);
        this.speechSynthesizer.provideGuidance('help');
        
        console.log('Help command received');
    }
    
    /**
     * Handle list reading commands
     */
    handleListCommand() {
        const items = this.listManager.getItems();
        this.updateStatus('Reading your shopping list');
        this.uiController.showVoiceResult('Reading shopping list', true);
        this.speechSynthesizer.readShoppingList(items);
        
        console.log('List command received, items:', items.length);
    }
    
    /**
     * Handle clear list commands
     */
    handleClearCommand() {
        const itemCount = this.listManager.getItems().length;
        
        if (itemCount === 0) {
            this.updateStatus('Shopping list is already empty');
            this.uiController.showVoiceResult('List is already empty', true);
            this.speechSynthesizer.provideGuidance('empty_list');
        } else {
            this.listManager.clearList();
            this.updateStatus('Shopping list cleared');
            this.uiController.displaySuccess('Shopping list cleared');
            this.uiController.showVoiceResult('Shopping list cleared', true);
            this.speechSynthesizer.confirmAction('cleared');
        }
        
        console.log('Clear command received');
    }
    
    /**
     * Handle unrecognized commands
     * @param {string} transcript - Original voice transcript
     */
    handleUnrecognizedCommand(transcript) {
        this.updateStatus('Command not recognized');
        
        // Provide helpful suggestions based on common patterns
        const suggestions = [
            'Try saying "add milk" or "buy 2 apples"',
            'Say "remove bread" to remove items',
            'Use phrases like "I need bananas" or "get some cheese"'
        ];
        
        const randomSuggestion = suggestions[Math.floor(Math.random() * suggestions.length)];
        const errorMessage = `Command not recognized. ${randomSuggestion}`;
        
        this.uiController.displayError(errorMessage);
        this.uiController.showVoiceResult('Command not recognized', false);
        
        // Provide audio guidance
        this.speechSynthesizer.announceError('invalid_command', randomSuggestion);
        
        console.log('Unrecognized command:', transcript);
    }
    

    
    /**
     * Process text command from fallback input
     */
    processTextCommand() {
        const command = this.elements.textInput.value.trim();
        if (!command) return;
        
        console.log('Processing text command:', command);
        this.processVoiceCommand(command);
        this.elements.textInput.value = '';
    }
    

    
    /**
     * Update the UI based on current state
     */
    updateUI() {
        const isListening = this.voiceProcessor.getIsListening();
        const isSupported = this.voiceProcessor.getIsSupported();
        const hasPermissions = this.voiceProcessor.getHasPermissions();
        
        // Update voice button
        if (isListening) {
            this.elements.voiceBtn.textContent = '🛑 Stop Listening';
            this.elements.voiceBtn.classList.add('listening');
            this.elements.listeningIndicator.classList.add('active');
        } else {
            this.elements.voiceBtn.innerHTML = '<span class="voice-btn__icon">🎤</span><span class="voice-btn__text">Start Listening</span>';
            this.elements.voiceBtn.classList.remove('listening');
            this.elements.listeningIndicator.classList.remove('active');
        }
        
        // Disable voice button if no speech recognition or permissions
        this.elements.voiceBtn.disabled = !isSupported || (!hasPermissions && !isListening);
    }
    
    /**
     * Update status text
     */
    updateStatus(message) {
        this.elements.statusIndicator.querySelector('.status-text').textContent = message;
    }
    
    /**
     * Show permissions notice
     */
    showPermissionsNotice() {
        this.elements.permissionsNotice.style.display = 'block';
    }
    
    /**
     * Hide permissions notice
     */
    hidePermissionsNotice() {
        this.elements.permissionsNotice.style.display = 'none';
    }
    
    /**
     * Show fallback text input
     */
    showFallbackInput() {
        this.elements.fallbackInput.style.display = 'flex';
    }
    
    /**
     * Hide fallback text input
     */
    hideFallbackInput() {
        this.elements.fallbackInput.style.display = 'none';
    }
    
    /**
     * Show smart suggestions based on history and context
     */
    showSmartSuggestions() {
        const recommendations = this.suggestionEngine.getVoiceRecommendations(5);
        
        if (recommendations.length > 0) {
            this.uiController.showSuggestions(recommendations);
            this.currentSuggestions = recommendations;
        } else {
            // Show seasonal suggestions if no history-based recommendations
            const seasonalItems = this.suggestionEngine.getSeasonalItems(3);
            if (seasonalItems.length > 0) {
                this.uiController.showSuggestions(seasonalItems);
                this.currentSuggestions = seasonalItems;
            }
        }
    }
    
    /**
     * Handle when an item is added to update suggestion history
     * @param {ShoppingItem} item - Added item
     */
    handleItemAdded(item) {
        // Update suggestion engine history
        this.suggestionEngine.updateHistory(item.name);
        
        // Refresh suggestions after a short delay
        setTimeout(() => {
            this.showSmartSuggestions();
        }, 1000);
    }
    
    /**
     * Handle suggestion commands from voice input
     * @param {Object} suggestionCommand - Processed suggestion command
     */
    handleSuggestionCommand(suggestionCommand) {
        const { action, suggestion } = suggestionCommand;
        
        if (action === 'accept') {
            try {
                this.listManager.addItem(suggestion.itemName);
                this.updateStatus(`Added ${suggestion.itemName} from suggestions`);
                this.uiController.displaySuccess(`Added ${suggestion.itemName}`);
                this.uiController.showVoiceResult(`Added ${suggestion.itemName}`, true);
                this.speechSynthesizer.confirmAction('added', suggestion.itemName);
                
                // Remove from current suggestions
                this.removeSuggestionFromCurrent(suggestion);
                
            } catch (error) {
                this.uiController.displayError(`Failed to add ${suggestion.itemName}: ${error.message}`);
                this.uiController.showVoiceResult(`Failed to add ${suggestion.itemName}`, false);
            }
        } else if (action === 'decline') {
            this.updateStatus(`Skipped suggestion: ${suggestion.itemName}`);
            this.uiController.showVoiceResult(`Skipped ${suggestion.itemName}`, true);
            this.speechSynthesizer.speak(`Skipped ${suggestion.itemName}`);
            
            // Remove from current suggestions
            this.removeSuggestionFromCurrent(suggestion);
        }
    }
    
    /**
     * Handle when a suggestion is accepted through UI
     * @param {Object} suggestion - Accepted suggestion
     */
    handleSuggestionAccepted(suggestion) {
        // Update suggestion engine history
        this.suggestionEngine.updateHistory(suggestion.itemName);
        
        // Provide audio feedback
        this.speechSynthesizer.confirmAction('added', suggestion.itemName);
        
        // Refresh suggestions
        setTimeout(() => {
            this.showSmartSuggestions();
        }, 1000);
    }
    
    /**
     * Get current suggestions for voice command processing
     * @returns {Array} Current suggestions array
     */
    getCurrentSuggestions() {
        return this.currentSuggestions || [];
    }
    
    /**
     * Remove a suggestion from current suggestions list
     * @param {Object} suggestion - Suggestion to remove
     */
    removeSuggestionFromCurrent(suggestion) {
        if (this.currentSuggestions) {
            this.currentSuggestions = this.currentSuggestions.filter(
                s => s.itemName !== suggestion.itemName
            );
            
            // Update UI to reflect the change
            this.uiController.removeSuggestionFromDisplay(suggestion.itemName);
        }
    }


}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.voiceShoppingApp = new VoiceShoppingApp();
});

// Export for potential module usage
export default VoiceShoppingApp;