# Voice Shopping Assistant - User Guide

## Table of Contents
1. [Getting Started](#getting-started)
2. [Voice Commands](#voice-commands)
3. [Features](#features)
4. [Troubleshooting](#troubleshooting)
5. [Accessibility](#accessibility)
6. [Browser Compatibility](#browser-compatibility)

## Getting Started

### First Time Setup
1. Open the Voice Shopping Assistant in your web browser
2. Allow microphone access when prompted
3. Click the microphone button or say "Hello" to start
4. Follow the voice prompts for a quick tutorial

### Basic Usage
- **Click the microphone button** to start listening
- **Speak clearly** into your device's microphone
- **Wait for the beep** before speaking
- **Listen for confirmation** of your commands

## Voice Commands

### Adding Items

#### Basic Add Commands
```
"Add milk"
"Add bread to my list"
"I need eggs"
"Put apples on my shopping list"
"Buy bananas"
```

#### Adding with Quantities
```
"Add 2 gallons of milk"
"Add 3 pounds of chicken breast"
"I need 12 eggs"
"Buy 5 bananas and 2 avocados"
"Add a dozen donuts"
"Put 2 liters of water on my list"
```

#### Adding Multiple Items
```
"Add milk, bread, and eggs"
"I need apples, bananas, and oranges"
"Add 2 gallons of milk and a loaf of bread"
"Buy chicken, rice, and vegetables"
```

### Removing Items

#### Basic Remove Commands
```
"Remove milk"
"Delete bread from my list"
"Take off eggs"
"Remove apples from my shopping list"
"I don't need bananas anymore"
```

#### Remove Multiple Items
```
"Remove milk and bread"
"Delete eggs and cheese from my list"
"Take off apples, bananas, and oranges"
```

### Modifying Items

#### Changing Quantities
```
"Change milk to 2 gallons"
"Update bread to 2 loaves"
"Make eggs 18 instead of 12"
"Increase apples to 10"
```

#### Marking Items as Completed
```
"Mark milk as done"
"Check off bread"
"I got the eggs"
"Found the apples"
```

### Search Commands

#### Basic Search
```
"Find organic apples"
"Search for gluten-free bread"
"Look for almond milk"
"Find chicken breast"
```

#### Search with Filters
```
"Find organic apples under $5"
"Search for gluten-free bread from Brand X"
"Look for almond milk on sale"
"Find chicken breast less than $8 per pound"
```

#### Price Range Searches
```
"Find pasta under $3"
"Search for wine between $10 and $20"
"Look for cheese under $5"
"Find snacks less than $2"
```

### Getting Suggestions

#### General Suggestions
```
"What should I buy?"
"Give me suggestions"
"What do I usually get?"
"Recommend something"
"What am I missing?"
```

#### Seasonal Suggestions
```
"What's good for summer?"
"Suggest winter items"
"What's in season?"
"Holiday suggestions"
```

#### Substitute Suggestions
```
"What can I use instead of milk?"
"Suggest alternatives to bread"
"Find substitutes for eggs"
"What's similar to chicken?"
```

### List Management

#### Viewing Your List
```
"Show my list"
"What's on my list?"
"Read my shopping list"
"How many items do I have?"
```

#### Organizing Your List
```
"Group by category"
"Sort by name"
"Show me dairy items"
"What's in produce?"
```

#### Clearing Your List
```
"Clear my list"
"Delete everything"
"Start over"
"Empty my shopping list"
```

## Features

### Automatic Categorization
Items are automatically sorted into categories:
- **Dairy**: milk, cheese, yogurt, butter
- **Produce**: fruits, vegetables, herbs
- **Meat**: chicken, beef, pork, fish, seafood
- **Pantry**: rice, pasta, flour, spices, canned goods
- **Snacks**: chips, cookies, crackers, candy
- **Beverages**: water, juice, soda, coffee, tea
- **Bakery**: bread, bagels, pastries
- **Frozen**: frozen vegetables, ice cream, frozen meals
- **Personal Care**: toothpaste, shampoo, soap
- **Household**: cleaning supplies, paper products

### Smart Suggestions
The app learns from your shopping history and provides:
- **Frequent Items**: Items you buy regularly
- **Seasonal Items**: Products that are in season
- **Complementary Items**: Items that go well together
- **Sale Items**: Products currently on sale (when available)

### Multi-language Support
Supported languages:
- **English** (US, UK, AU)
- **Spanish** (ES, MX, US)
- **French** (FR, CA)
- **German** (DE)
- **Italian** (IT)
- **Portuguese** (BR, PT)

To change language:
```
"Switch to Spanish"
"Change language to French"
"Use German"
```

### Voice Feedback
The app provides audio confirmation for:
- Items added successfully
- Items removed
- Error messages
- Suggestions and recommendations
- List summaries

## Troubleshooting

### Common Issues

#### Microphone Not Working
1. Check browser permissions for microphone access
2. Ensure your microphone is not muted
3. Try refreshing the page
4. Check if other applications are using the microphone

#### Voice Not Recognized
1. Speak clearly and at normal pace
2. Reduce background noise
3. Move closer to the microphone
4. Try rephrasing your command
5. Use the fallback text input if available

#### Items Not Added Correctly
1. Speak item names clearly
2. Use common names for products
3. Specify quantities clearly ("two" instead of "2")
4. Try breaking complex commands into simpler ones

#### App Not Responding
1. Refresh the browser page
2. Clear browser cache and cookies
3. Try a different browser
4. Check internet connection

### Error Messages

#### "Microphone access denied"
- **Solution**: Allow microphone access in browser settings
- **Chrome**: Click the microphone icon in the address bar
- **Firefox**: Click the microphone icon in the address bar
- **Safari**: Go to Safari > Preferences > Websites > Microphone

#### "Speech recognition not supported"
- **Solution**: Use a supported browser (Chrome, Edge, Safari)
- **Fallback**: Use the text input option

#### "Network error"
- **Solution**: Check internet connection
- **Note**: Basic functionality works offline

## Accessibility

### Screen Reader Support
- Full ARIA label support
- Semantic HTML structure
- Keyboard navigation
- Audio descriptions of actions

### Keyboard Navigation
- **Tab**: Navigate between elements
- **Enter/Space**: Activate buttons
- **Escape**: Cancel current action
- **Arrow keys**: Navigate lists

### Visual Accessibility
- High contrast mode support
- Large text options
- Clear visual indicators
- Color-blind friendly design

### Motor Accessibility
- Voice-only operation
- Large touch targets
- No time-sensitive interactions
- Customizable interface

## Browser Compatibility

### Fully Supported
- **Chrome** 25+ (Windows, Mac, Linux, Android)
- **Edge** 79+ (Windows, Mac)
- **Safari** 14.1+ (Mac, iOS) - Limited voice features
- **Chrome Mobile** 25+ (Android, iOS)

### Partially Supported
- **Firefox** 55+ - Voice recognition limited
- **Opera** 27+ - Voice recognition limited
- **Samsung Internet** 4.0+ - Voice recognition limited

### Fallback Support
- **Internet Explorer** - Text input only
- **Older browsers** - Basic list management without voice

### Feature Support by Browser

| Feature | Chrome | Edge | Safari | Firefox |
|---------|--------|------|--------|---------|
| Voice Recognition | ✅ | ✅ | ⚠️ | ⚠️ |
| Speech Synthesis | ✅ | ✅ | ✅ | ✅ |
| Offline Mode | ✅ | ✅ | ✅ | ✅ |
| Multi-language | ✅ | ✅ | ⚠️ | ⚠️ |
| Mobile Support | ✅ | ✅ | ✅ | ⚠️ |

**Legend:**
- ✅ Full support
- ⚠️ Limited support
- ❌ Not supported

## Tips for Best Experience

### Voice Commands
1. **Speak naturally** - Use conversational language
2. **Be specific** - "2 gallons of milk" vs "some milk"
3. **Pause between items** - When adding multiple items
4. **Use common names** - "Apples" instead of "Granny Smith apples"
5. **Confirm additions** - Listen for confirmation before continuing

### Environment
1. **Quiet space** - Minimize background noise
2. **Good microphone** - Use a quality microphone if available
3. **Stable internet** - For best voice recognition
4. **Modern browser** - Keep your browser updated

### Organization
1. **Review your list** - Check items before shopping
2. **Use categories** - Organize by store layout
3. **Mark completed items** - As you shop
4. **Clear old lists** - Start fresh for new shopping trips

## Advanced Features

### Custom Categories
Create your own categories:
```
"Create category called 'Baby Items'"
"Add diapers to Baby Items category"
```

### Shopping History
View your shopping patterns:
```
"Show my shopping history"
"What do I buy most often?"
"When did I last buy milk?"
```

### Price Tracking
Track prices over time:
```
"What did milk cost last time?"
"Show price history for bread"
"Alert me when apples go on sale"
```

### Meal Planning Integration
Plan meals and generate lists:
```
"Plan dinner for tonight"
"Add ingredients for spaghetti"
"What do I need for tacos?"
```

## Getting Help

### In-App Help
- Say "Help" for voice assistance
- Click the help button for tutorials
- Use the "?" icon for tooltips

### Voice Commands for Help
```
"Help"
"How do I add items?"
"What can I say?"
"Show me examples"
"Tutorial"
```

### Support
For technical support or feature requests:
- Check the FAQ section
- Report issues through the feedback form
- Contact support via the help menu

---

*Last updated: December 2023*
*Version: 1.0*