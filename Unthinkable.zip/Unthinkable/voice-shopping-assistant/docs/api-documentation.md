# Voice Shopping Assistant - API Documentation

## Table of Contents
1. [Core Classes](#core-classes)
2. [Data Models](#data-models)
3. [Voice Processing](#voice-processing)
4. [Storage Management](#storage-management)
5. [UI Components](#ui-components)
6. [Utilities](#utilities)
7. [Error Handling](#error-handling)
8. [Events](#events)

## Core Classes

### ShoppingListManager

The main business logic class that orchestrates shopping list operations.

#### Constructor
```javascript
new ShoppingListManager(storage, categoryManager)
```

**Parameters:**
- `storage` (StorageManager, optional): Storage manager instance
- `categoryManager` (CategoryManager, optional): Category manager instance

**Example:**
```javascript
const storage = new StorageManager();
const categoryManager = new CategoryManager();
const listManager = new ShoppingListManager(storage, categoryManager);
```

#### Methods

##### addItem(itemName, quantity, category)
Adds an item to the shopping list or updates quantity if item exists.

**Parameters:**
- `itemName` (string): Name of the item to add
- `quantity` (string|number, optional): Quantity of the item (default: "1")
- `category` (string, optional): Category of the item (auto-categorized if not provided)

**Returns:** `ShoppingItem` - The added or updated item

**Throws:** `Error` if itemName is invalid

**Example:**
```javascript
const item = listManager.addItem('milk', '2 gallons', 'dairy');
console.log(item.name); // 'milk'
console.log(item.quantity); // '2 gallons'
```

##### removeItem(itemName)
Removes an item from the shopping list.

**Parameters:**
- `itemName` (string): Name of the item to remove

**Returns:** `boolean` - True if item was removed, false if not found

**Example:**
```javascript
const removed = listManager.removeItem('milk');
if (removed) {
    console.log('Milk removed from list');
}
```

##### updateQuantity(itemName, newQuantity)
Updates the quantity of an existing item.

**Parameters:**
- `itemName` (string): Name of the item to update
- `newQuantity` (string|number): New quantity value

**Returns:** `boolean` - True if updated successfully, false if item not found

**Example:**
```javascript
const updated = listManager.updateQuantity('milk', '3 gallons');
```

##### getList()
Gets the current shopping list.

**Returns:** `ShoppingList` - The current shopping list instance

**Example:**
```javascript
const list = listManager.getList();
console.log(`List has ${list.getItemCount()} items`);
```

##### clearList()
Clears all items from the shopping list.

**Returns:** `void`

**Example:**
```javascript
listManager.clearList();
```

##### categorizeItem(itemName)
Automatically categorizes an item based on its name.

**Parameters:**
- `itemName` (string): Name of the item to categorize

**Returns:** `string` - The determined category

**Example:**
```javascript
const category = listManager.categorizeItem('milk');
console.log(category); // 'dairy'
```

##### addEventListener(event, callback)
Adds an event listener for list changes.

**Parameters:**
- `event` (string): Event type ('itemAdded', 'itemRemoved', 'itemUpdated', 'listCleared')
- `callback` (function): Callback function to execute

**Example:**
```javascript
listManager.addEventListener('itemAdded', (item) => {
    console.log(`Added: ${item.name}`);
});
```

### VoiceProcessor

Handles voice recognition and command processing.

#### Constructor
```javascript
new VoiceProcessor(onCommandReceived, onError)
```

**Parameters:**
- `onCommandReceived` (function): Callback for successful voice commands
- `onError` (function): Callback for voice recognition errors

#### Methods

##### startListening()
Starts voice recognition.

**Returns:** `void`

**Example:**
```javascript
voiceProcessor.startListening();
```

##### stopListening()
Stops voice recognition.

**Returns:** `void`

##### setLanguage(languageCode)
Sets the recognition language.

**Parameters:**
- `languageCode` (string): Language code (e.g., 'en-US', 'es-ES')

**Example:**
```javascript
voiceProcessor.setLanguage('es-ES');
```

##### isListening()
Checks if currently listening for voice input.

**Returns:** `boolean` - True if listening, false otherwise

### NLPParser

Parses natural language commands into structured data.

#### Methods

##### parseAddCommand(text)
Parses commands for adding items.

**Parameters:**
- `text` (string): The voice command text

**Returns:** `Object` - Parsed command with items array

**Example:**
```javascript
const result = nlpParser.parseAddCommand('Add 2 gallons of milk');
console.log(result.items[0].name); // 'milk'
console.log(result.items[0].quantity); // '2 gallons'
```

##### parseRemoveCommand(text)
Parses commands for removing items.

**Parameters:**
- `text` (string): The voice command text

**Returns:** `Object` - Parsed command with items array

##### parseSearchCommand(text)
Parses search commands.

**Parameters:**
- `text` (string): The voice command text

**Returns:** `Object` - Parsed search with query and filters

**Example:**
```javascript
const result = nlpParser.parseSearchCommand('Find organic apples under $5');
console.log(result.query); // 'organic apples'
console.log(result.filters.maxPrice); // 5
```

##### extractQuantity(text)
Extracts quantity information from text.

**Parameters:**
- `text` (string): Text containing quantity

**Returns:** `Object` - Quantity and unit information

## Data Models

### ShoppingItem

Represents a single shopping list item.

#### Constructor
```javascript
new ShoppingItem(name, quantity, category)
```

**Parameters:**
- `name` (string): Item name
- `quantity` (string, optional): Item quantity (default: "1")
- `category` (string, optional): Item category (default: "miscellaneous")

#### Properties
- `id` (string): Unique identifier
- `name` (string): Item name
- `quantity` (string): Item quantity
- `category` (string): Item category
- `dateAdded` (Date): When item was added
- `completed` (boolean): Whether item is completed

#### Methods

##### updateQuantity(newQuantity)
Updates the item's quantity.

**Parameters:**
- `newQuantity` (string): New quantity value

##### setCompleted(completed)
Sets the completion status.

**Parameters:**
- `completed` (boolean): Completion status

##### toJSON()
Serializes the item to JSON.

**Returns:** `Object` - JSON representation

##### toString()
Returns string representation.

**Returns:** `string` - Human-readable string

#### Static Methods

##### fromJSON(data)
Creates a ShoppingItem from JSON data.

**Parameters:**
- `data` (Object): JSON data

**Returns:** `ShoppingItem` - New instance

### ShoppingList

Represents a collection of shopping items.

#### Constructor
```javascript
new ShoppingList()
```

#### Methods

##### addItem(name, quantity, category)
Adds an item to the list.

**Parameters:**
- `name` (string): Item name
- `quantity` (string): Item quantity
- `category` (string): Item category

**Returns:** `ShoppingItem` - The added item

##### removeItem(name)
Removes an item by name.

**Parameters:**
- `name` (string): Item name to remove

**Returns:** `boolean` - Success status

##### findItemByName(name)
Finds an item by name.

**Parameters:**
- `name` (string): Item name to find

**Returns:** `ShoppingItem|null` - Found item or null

##### getItemCount()
Gets the total number of items.

**Returns:** `number` - Item count

##### isEmpty()
Checks if the list is empty.

**Returns:** `boolean` - True if empty

##### getCategories()
Gets all unique categories in the list.

**Returns:** `string[]` - Array of category names

##### getItemsGroupedByCategory()
Groups items by category.

**Returns:** `Object` - Items grouped by category

##### sortItems(field, ascending)
Sorts items by a field.

**Parameters:**
- `field` (string): Field to sort by ('name', 'quantity', 'category', 'dateAdded')
- `ascending` (boolean): Sort direction

##### getCompletedCount()
Gets count of completed items.

**Returns:** `number` - Completed item count

##### markItemCompleted(name, completed)
Marks an item as completed.

**Parameters:**
- `name` (string): Item name
- `completed` (boolean): Completion status

##### clear()
Removes all items from the list.

##### toJSON()
Serializes the list to JSON.

**Returns:** `Object` - JSON representation

## Voice Processing

### SpeechSynthesizer

Handles text-to-speech functionality.

#### Methods

##### speak(text, options)
Speaks the given text.

**Parameters:**
- `text` (string): Text to speak
- `options` (Object, optional): Speech options

**Options:**
- `lang` (string): Language code
- `rate` (number): Speech rate (0.1-10)
- `pitch` (number): Speech pitch (0-2)
- `volume` (number): Speech volume (0-1)

**Example:**
```javascript
synthesizer.speak('Item added to list', {
    lang: 'en-US',
    rate: 1.0,
    pitch: 1.0
});
```

##### stop()
Stops current speech.

##### setVoice(voiceName)
Sets the voice to use.

**Parameters:**
- `voiceName` (string): Name of the voice

##### getAvailableVoices()
Gets available voices.

**Returns:** `Array` - Available voice objects

### MultilingualSupport

Handles multiple language support.

#### Methods

##### setLanguage(languageCode)
Sets the current language.

**Parameters:**
- `languageCode` (string): Language code

##### getLanguage()
Gets the current language.

**Returns:** `string` - Current language code

##### getSupportedLanguages()
Gets supported languages.

**Returns:** `Array` - Supported language objects

##### translateCommand(command, targetLanguage)
Translates a command to target language.

**Parameters:**
- `command` (string): Command to translate
- `targetLanguage` (string): Target language code

**Returns:** `string` - Translated command

## Storage Management

### StorageManager

Handles data persistence using localStorage.

#### Methods

##### saveList(shoppingList)
Saves a shopping list.

**Parameters:**
- `shoppingList` (ShoppingList): List to save

**Returns:** `boolean` - Success status

##### loadList()
Loads the saved shopping list.

**Returns:** `ShoppingList` - Loaded list or empty list

##### savePreferences(preferences)
Saves user preferences.

**Parameters:**
- `preferences` (Object): Preferences object

##### loadPreferences()
Loads user preferences.

**Returns:** `Object` - Preferences object

##### saveHistory(history)
Saves shopping history.

**Parameters:**
- `history` (Object): History object

##### loadHistory()
Loads shopping history.

**Returns:** `Object` - History object

##### clearAll()
Clears all stored data.

**Returns:** `boolean` - Success status

##### getStorageInfo()
Gets storage usage information.

**Returns:** `Object` - Storage info with used/total bytes

##### isAvailable
Property indicating if localStorage is available.

**Type:** `boolean`

## UI Components

### UIController

Manages the user interface and interactions.

#### Methods

##### updateShoppingList()
Updates the visual shopping list display.

##### showListeningIndicator()
Shows the voice listening indicator.

##### hideListeningIndicator()
Hides the voice listening indicator.

##### displayError(message)
Displays an error message.

**Parameters:**
- `message` (string): Error message to display

##### showSuggestions(suggestions)
Displays product suggestions.

**Parameters:**
- `suggestions` (Array): Array of suggestion objects

##### updateItemCount(count)
Updates the item count display.

**Parameters:**
- `count` (number): Number of items

##### setLanguage(languageCode)
Updates UI language.

**Parameters:**
- `languageCode` (string): Language code

## Utilities

### CategoryManager

Manages item categorization.

#### Methods

##### categorizeItem(itemName)
Categorizes an item by name.

**Parameters:**
- `itemName` (string): Item name

**Returns:** `string` - Category name

##### getCategories()
Gets all available categories.

**Returns:** `Array` - Category objects

##### addCustomCategory(categoryName, keywords)
Adds a custom category.

**Parameters:**
- `categoryName` (string): Category name
- `keywords` (Array): Keywords for categorization

### SuggestionEngine

Provides intelligent product suggestions.

#### Methods

##### getRecommendations()
Gets personalized recommendations.

**Returns:** `Array` - Recommendation objects

##### getSeasonalItems()
Gets seasonal item suggestions.

**Returns:** `Array` - Seasonal item objects

##### getSubstitutes(itemName)
Gets substitute suggestions for an item.

**Parameters:**
- `itemName` (string): Item to find substitutes for

**Returns:** `Array` - Substitute objects

##### updateHistory(item)
Updates purchase history.

**Parameters:**
- `item` (ShoppingItem): Item that was purchased

## Error Handling

### ErrorHandler

Centralized error handling and logging.

#### Methods

##### handleError(error, context)
Handles and logs errors.

**Parameters:**
- `error` (Error): Error object
- `context` (string): Context where error occurred

##### logError(message, details)
Logs error information.

**Parameters:**
- `message` (string): Error message
- `details` (Object): Additional error details

##### showUserError(message)
Shows user-friendly error message.

**Parameters:**
- `message` (string): User-friendly error message

### Common Error Types

#### VoiceRecognitionError
Thrown when voice recognition fails.

#### StorageError
Thrown when storage operations fail.

#### ValidationError
Thrown when data validation fails.

#### NetworkError
Thrown when network operations fail.

## Events

### Event Types

#### itemAdded
Fired when an item is added to the list.

**Payload:**
```javascript
{
    item: ShoppingItem,
    timestamp: Date
}
```

#### itemRemoved
Fired when an item is removed from the list.

**Payload:**
```javascript
{
    itemName: string,
    timestamp: Date
}
```

#### itemUpdated
Fired when an item is updated.

**Payload:**
```javascript
{
    item: ShoppingItem,
    changes: Object,
    timestamp: Date
}
```

#### listCleared
Fired when the list is cleared.

**Payload:**
```javascript
{
    itemCount: number,
    timestamp: Date
}
```

#### voiceCommandReceived
Fired when a voice command is processed.

**Payload:**
```javascript
{
    command: string,
    confidence: number,
    timestamp: Date
}
```

#### languageChanged
Fired when the language is changed.

**Payload:**
```javascript
{
    oldLanguage: string,
    newLanguage: string,
    timestamp: Date
}
```

## Usage Examples

### Basic Setup
```javascript
// Initialize components
const storage = new StorageManager();
const categoryManager = new CategoryManager();
const listManager = new ShoppingListManager(storage, categoryManager);
const nlpParser = new NLPParser();

// Set up voice processing
const voiceProcessor = new VoiceProcessor(
    (command) => {
        const parsed = nlpParser.parseAddCommand(command);
        if (parsed.items.length > 0) {
            parsed.items.forEach(item => {
                listManager.addItem(item.name, item.quantity, item.category);
            });
        }
    },
    (error) => {
        console.error('Voice error:', error);
    }
);

// Start listening
voiceProcessor.startListening();
```

### Adding Items Programmatically
```javascript
// Add single item
listManager.addItem('milk', '2 gallons', 'dairy');

// Add multiple items
const items = [
    { name: 'bread', quantity: '1 loaf', category: 'bakery' },
    { name: 'eggs', quantity: '12', category: 'dairy' },
    { name: 'apples', quantity: '5', category: 'produce' }
];

items.forEach(item => {
    listManager.addItem(item.name, item.quantity, item.category);
});
```

### Working with Categories
```javascript
// Get items by category
const list = listManager.getList();
const dairyItems = list.getItemsByCategory('dairy');

// Group all items by category
const grouped = list.getItemsGroupedByCategory();
Object.entries(grouped).forEach(([category, items]) => {
    console.log(`${category}: ${items.length} items`);
});
```

### Voice Command Processing
```javascript
// Process various command types
const commands = [
    'Add 2 gallons of milk',
    'Remove bread from my list',
    'Find organic apples under $5'
];

commands.forEach(command => {
    // Try different parsers
    let parsed = nlpParser.parseAddCommand(command);
    if (parsed.items.length > 0) {
        // Handle add command
        return;
    }
    
    parsed = nlpParser.parseRemoveCommand(command);
    if (parsed.items.length > 0) {
        // Handle remove command
        return;
    }
    
    parsed = nlpParser.parseSearchCommand(command);
    if (parsed.query) {
        // Handle search command
        return;
    }
});
```

### Error Handling
```javascript
try {
    listManager.addItem('', '1', 'dairy'); // Invalid empty name
} catch (error) {
    if (error instanceof ValidationError) {
        console.error('Validation failed:', error.message);
    }
}

// Handle voice recognition errors
voiceProcessor.addEventListener('error', (error) => {
    switch (error.type) {
        case 'no-speech':
            console.log('No speech detected');
            break;
        case 'network':
            console.log('Network error occurred');
            break;
        default:
            console.log('Unknown error:', error);
    }
});
```

---

*This documentation covers the main APIs and usage patterns for the Voice Shopping Assistant. For implementation details, see the source code and inline comments.*