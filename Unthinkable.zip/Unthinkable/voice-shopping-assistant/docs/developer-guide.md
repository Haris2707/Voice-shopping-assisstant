# Voice Shopping Assistant - Developer Guide

## Table of Contents
1. [Project Overview](#project-overview)
2. [Architecture](#architecture)
3. [Getting Started](#getting-started)
4. [Code Structure](#code-structure)
5. [Development Workflow](#development-workflow)
6. [Testing](#testing)
7. [Performance Optimization](#performance-optimization)
8. [Deployment](#deployment)
9. [Contributing](#contributing)

## Project Overview

The Voice Shopping Assistant is a client-side web application that enables users to manage shopping lists through voice commands. Built with vanilla JavaScript, HTML5, and CSS3, it leverages modern web APIs for voice recognition and synthesis.

### Key Features
- Voice-controlled shopping list management
- Natural language processing for command interpretation
- Automatic item categorization
- Multi-language support
- Offline functionality with localStorage
- Responsive design for mobile and desktop
- Accessibility compliance (WCAG 2.1)

### Technology Stack
- **Frontend**: HTML5, CSS3, Vanilla JavaScript (ES6+)
- **Voice APIs**: Web Speech API (SpeechRecognition, SpeechSynthesis)
- **Storage**: localStorage for client-side persistence
- **Testing**: Custom test framework with comprehensive coverage
- **Build Tools**: None (vanilla implementation for simplicity)

## Architecture

### High-Level Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   User Voice    │───▶│  Voice Processor │───▶│   NLP Parser    │
│     Input       │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                        │
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   UI Controller │◀───│ Shopping List   │◀───│  Category       │
│                 │    │    Manager      │    │   Manager       │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │
┌─────────────────┐    ┌─────────────────┐
│ Speech Synthesis│    │ Storage Manager │
│                 │    │                 │
└─────────────────┘    └─────────────────┘
```

### Module Dependencies

```javascript
// Core Dependencies
ShoppingListManager
├── StorageManager
├── CategoryManager
└── ShoppingList
    └── ShoppingItem

// Voice Processing
VoiceProcessor
├── NLPParser
└── SpeechSynthesizer

// UI Layer
UIController
├── ShoppingListManager
├── VoiceProcessor
└── ErrorHandler
```

## Getting Started

### Prerequisites
- Modern web browser with Web Speech API support
- Local web server (for development)
- Text editor or IDE

### Installation

1. **Clone or download the project**
```bash
git clone <repository-url>
cd voice-shopping-assistant
```

2. **Start a local web server**
```bash
# Using Python 3
python -m http.server 8000

# Using Node.js (if you have http-server installed)
npx http-server

# Using PHP
php -S localhost:8000
```

3. **Open in browser**
```
http://localhost:8000
```

### Project Structure
```
voice-shopping-assistant/
├── index.html              # Main application entry point
├── app.js                  # Application initialization
├── styles.css              # Main stylesheet
├── models/                 # Data models and business logic
│   ├── ShoppingItem.js
│   ├── ShoppingList.js
│   ├── ShoppingListManager.js
│   ├── StorageManager.js
│   ├── CategoryManager.js
│   ├── VoiceProcessor.js
│   ├── NLPParser.js
│   ├── SpeechSynthesizer.js
│   └── SuggestionEngine.js
├── ui/                     # User interface components
│   └── UIController.js
├── tests/                  # Test files
│   ├── *.test.js
│   └── comprehensive-test-suite.html
└── docs/                   # Documentation
    ├── user-guide.md
    ├── api-documentation.md
    └── developer-guide.md
```

## Code Structure

### Core Models

#### ShoppingItem.js
```javascript
/**
 * Represents a single shopping list item
 * Handles item data, validation, and serialization
 */
export class ShoppingItem {
    constructor(name, quantity = "1", category = "miscellaneous") {
        this.id = this.generateId();
        this.name = this.validateName(name);
        this.quantity = quantity;
        this.category = category;
        this.dateAdded = new Date();
        this.completed = false;
    }
    
    /**
     * Generates a unique ID for the item
     * @returns {string} Unique identifier
     */
    generateId() {
        return 'item_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    /**
     * Validates item name
     * @param {string} name - Item name to validate
     * @returns {string} Validated name
     * @throws {Error} If name is invalid
     */
    validateName(name) {
        if (!name || typeof name !== 'string') {
            throw new Error('Item name is required and must be a string');
        }
        
        const trimmed = name.trim();
        if (trimmed.length === 0) {
            throw new Error('Item name cannot be empty');
        }
        
        if (trimmed.length > 100) {
            throw new Error('Item name too long (max 100 characters)');
        }
        
        return trimmed;
    }
}
```

#### ShoppingListManager.js
```javascript
/**
 * Core business logic for shopping list operations
 * Orchestrates interactions between models and provides event handling
 */
export class ShoppingListManager {
    constructor(storage = null, categoryManager = null) {
        this.storage = storage || new StorageManager();
        this.categoryManager = categoryManager || new CategoryManager();
        this.shoppingList = this.loadList();
        this.listeners = this.initializeEventListeners();
    }
    
    /**
     * Adds an item to the shopping list
     * Handles duplicate detection and quantity merging
     */
    addItem(itemName, quantity = "1", category = null) {
        try {
            const sanitizedName = this.sanitizeItemName(itemName);
            const finalCategory = category || this.categorizeItem(sanitizedName);
            
            // Check for existing item
            const existingItem = this.shoppingList.findItemByName(sanitizedName);
            
            if (existingItem) {
                return this.handleDuplicateItem(existingItem, quantity);
            }
            
            // Create new item
            const newItem = this.shoppingList.addItem(sanitizedName, quantity, finalCategory);
            
            // Persist changes
            this.saveList();
            
            // Notify listeners
            this.notifyListeners('itemAdded', { item: newItem });
            
            return newItem;
            
        } catch (error) {
            this.handleError('addItem', error);
            throw error;
        }
    }
    
    /**
     * Handles duplicate item logic
     * @private
     */
    handleDuplicateItem(existingItem, newQuantity) {
        const mergedQuantity = this.mergeQuantities(existingItem.quantity, newQuantity);
        existingItem.updateQuantity(mergedQuantity);
        
        this.saveList();
        this.notifyListeners('itemUpdated', { 
            item: existingItem, 
            changes: { quantity: mergedQuantity } 
        });
        
        return existingItem;
    }
}
```

### Voice Processing

#### VoiceProcessor.js
```javascript
/**
 * Handles Web Speech API integration
 * Manages voice recognition lifecycle and error handling
 */
export class VoiceProcessor {
    constructor(onCommandReceived, onError) {
        this.onCommandReceived = onCommandReceived;
        this.onError = onError;
        this.recognition = this.initializeSpeechRecognition();
        this.isCurrentlyListening = false;
        this.language = 'en-US';
    }
    
    /**
     * Initializes speech recognition with proper configuration
     * @private
     */
    initializeSpeechRecognition() {
        // Check for browser support
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        
        if (!SpeechRecognition) {
            throw new Error('Speech recognition not supported in this browser');
        }
        
        const recognition = new SpeechRecognition();
        
        // Configure recognition settings
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = this.language;
        recognition.maxAlternatives = 1;
        
        // Set up event handlers
        this.setupRecognitionEventHandlers(recognition);
        
        return recognition;
    }
    
    /**
     * Sets up event handlers for speech recognition
     * @private
     */
    setupRecognitionEventHandlers(recognition) {
        recognition.onstart = () => {
            this.isCurrentlyListening = true;
            this.notifyListeningStateChange(true);
        };
        
        recognition.onend = () => {
            this.isCurrentlyListening = false;
            this.notifyListeningStateChange(false);
        };
        
        recognition.onresult = (event) => {
            this.handleRecognitionResult(event);
        };
        
        recognition.onerror = (event) => {
            this.handleRecognitionError(event);
        };
    }
    
    /**
     * Processes speech recognition results
     * @private
     */
    handleRecognitionResult(event) {
        try {
            const result = event.results[0];
            const transcript = result[0].transcript;
            const confidence = result[0].confidence;
            
            // Log recognition details for debugging
            console.log(`Voice command: "${transcript}" (confidence: ${confidence})`);
            
            // Only process high-confidence results
            if (confidence > 0.7) {
                this.onCommandReceived(transcript, confidence);
            } else {
                this.onError({
                    type: 'low-confidence',
                    message: 'Speech recognition confidence too low',
                    transcript,
                    confidence
                });
            }
            
        } catch (error) {
            this.onError({
                type: 'processing-error',
                message: 'Error processing speech recognition result',
                originalError: error
            });
        }
    }
}
```

#### NLPParser.js
```javascript
/**
 * Natural Language Processing for voice commands
 * Extracts intent, entities, and parameters from user speech
 */
export class NLPParser {
    constructor() {
        this.commandPatterns = this.initializeCommandPatterns();
        this.quantityPatterns = this.initializeQuantityPatterns();
        this.stopWords = ['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'];
    }
    
    /**
     * Parses add commands and extracts items with quantities
     * @param {string} text - Voice command text
     * @returns {Object} Parsed command with items array
     */
    parseAddCommand(text) {
        const normalizedText = this.normalizeText(text);
        
        // Check if this is an add command
        if (!this.isAddCommand(normalizedText)) {
            return { intent: 'unknown', items: [] };
        }
        
        // Extract items from the command
        const items = this.extractItemsFromAddCommand(normalizedText);
        
        return {
            intent: 'add',
            items: items,
            originalText: text,
            confidence: this.calculateConfidence(items, text)
        };
    }
    
    /**
     * Extracts items from add command text
     * @private
     */
    extractItemsFromAddCommand(text) {
        const items = [];
        
        // Remove command words
        let cleanText = this.removeCommandWords(text);
        
        // Split on common separators
        const itemPhrases = this.splitItemPhrases(cleanText);
        
        itemPhrases.forEach(phrase => {
            const item = this.parseItemPhrase(phrase);
            if (item.name) {
                items.push(item);
            }
        });
        
        return items;
    }
    
    /**
     * Parses individual item phrase to extract name, quantity, and modifiers
     * @private
     */
    parseItemPhrase(phrase) {
        const trimmed = phrase.trim();
        
        // Extract quantity first
        const quantityResult = this.extractQuantity(trimmed);
        
        // Remove quantity from phrase to get item name
        let itemName = trimmed;
        if (quantityResult.found) {
            itemName = trimmed.replace(quantityResult.pattern, '').trim();
        }
        
        // Clean up item name
        itemName = this.cleanItemName(itemName);
        
        return {
            name: itemName,
            quantity: quantityResult.quantity || "1",
            unit: quantityResult.unit || null,
            modifiers: this.extractModifiers(trimmed)
        };
    }
    
    /**
     * Extracts quantity and unit from text
     * Handles various formats: "2", "two", "2 gallons", "a dozen", etc.
     */
    extractQuantity(text) {
        const patterns = [
            // Number + unit patterns
            /(\d+(?:\.\d+)?)\s*(gallons?|gallon|liters?|liter|pounds?|pound|lbs?|lb|ounces?|ounce|oz|bottles?|bottle|cans?|can|boxes?|box|bags?|bag|loaves?|loaf|dozens?|dozen)/i,
            
            // Word numbers + unit patterns
            /(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\s*(gallons?|gallon|liters?|liter|pounds?|pound|lbs?|lb|ounces?|ounce|oz|bottles?|bottle|cans?|can|boxes?|box|bags?|bag|loaves?|loaf|dozens?|dozen)/i,
            
            // Special quantity words
            /(a\s+dozen|half\s+dozen|a\s+couple|a\s+few|some|several)/i,
            
            // Simple numbers
            /(\d+(?:\.\d+)?)/,
            
            // Word numbers
            /(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty)/i
        ];
        
        for (const pattern of patterns) {
            const match = text.match(pattern);
            if (match) {
                return this.processQuantityMatch(match, pattern);
            }
        }
        
        return { found: false, quantity: null, unit: null, pattern: null };
    }
    
    /**
     * Processes quantity pattern matches
     * @private
     */
    processQuantityMatch(match, pattern) {
        const fullMatch = match[0];
        const quantity = match[1];
        const unit = match[2] || null;
        
        // Convert word numbers to digits
        const numericQuantity = this.convertWordToNumber(quantity) || quantity;
        
        // Handle special cases
        if (fullMatch.includes('dozen')) {
            return {
                found: true,
                quantity: fullMatch.includes('half') ? '6' : '12',
                unit: null,
                pattern: fullMatch
            };
        }
        
        if (fullMatch.includes('couple')) {
            return {
                found: true,
                quantity: '2',
                unit: null,
                pattern: fullMatch
            };
        }
        
        return {
            found: true,
            quantity: numericQuantity,
            unit: unit,
            pattern: fullMatch
        };
    }
}
```

### UI Components

#### UIController.js
```javascript
/**
 * Manages user interface updates and interactions
 * Bridges between business logic and DOM manipulation
 */
export class UIController {
    constructor(listManager, voiceProcessor) {
        this.listManager = listManager;
        this.voiceProcessor = voiceProcessor;
        this.elements = this.initializeElements();
        this.setupEventListeners();
    }
    
    /**
     * Initializes DOM element references
     * @private
     */
    initializeElements() {
        return {
            shoppingList: document.getElementById('shopping-list'),
            itemCount: document.getElementById('item-count'),
            microphoneButton: document.getElementById('microphone-button'),
            listeningIndicator: document.getElementById('listening-indicator'),
            errorMessage: document.getElementById('error-message'),
            categoryTabs: document.getElementById('category-tabs'),
            addItemForm: document.getElementById('add-item-form'),
            itemInput: document.getElementById('item-input'),
            quantityInput: document.getElementById('quantity-input')
        };
    }
    
    /**
     * Updates the shopping list display
     * Renders items grouped by category with proper styling
     */
    updateShoppingList() {
        const list = this.listManager.getList();
        const groupedItems = list.getItemsGroupedByCategory();
        
        // Clear existing content
        this.elements.shoppingList.innerHTML = '';
        
        // Render each category
        Object.entries(groupedItems).forEach(([category, items]) => {
            if (items.length > 0) {
                this.renderCategory(category, items);
            }
        });
        
        // Update item count
        this.updateItemCount(list.getItemCount());
        
        // Update empty state
        this.updateEmptyState(list.isEmpty());
    }
    
    /**
     * Renders a category section with its items
     * @private
     */
    renderCategory(category, items) {
        const categorySection = this.createCategorySection(category);
        const itemsList = this.createItemsList(items);
        
        categorySection.appendChild(itemsList);
        this.elements.shoppingList.appendChild(categorySection);
    }
    
    /**
     * Creates a category section element
     * @private
     */
    createCategorySection(category) {
        const section = document.createElement('div');
        section.className = 'category-section';
        section.setAttribute('data-category', category);
        
        const header = document.createElement('h3');
        header.className = 'category-header';
        header.textContent = this.formatCategoryName(category);
        
        section.appendChild(header);
        return section;
    }
    
    /**
     * Creates items list for a category
     * @private
     */
    createItemsList(items) {
        const list = document.createElement('ul');
        list.className = 'items-list';
        
        items.forEach(item => {
            const listItem = this.createItemElement(item);
            list.appendChild(listItem);
        });
        
        return list;
    }
    
    /**
     * Creates individual item element with controls
     * @private
     */
    createItemElement(item) {
        const li = document.createElement('li');
        li.className = `item ${item.completed ? 'completed' : ''}`;
        li.setAttribute('data-item-id', item.id);
        
        li.innerHTML = `
            <div class="item-content">
                <button class="item-checkbox" 
                        onclick="toggleItemCompletion('${item.id}')"
                        aria-label="Mark ${item.name} as ${item.completed ? 'incomplete' : 'complete'}">
                    <span class="checkbox-icon">${item.completed ? '✓' : ''}</span>
                </button>
                
                <div class="item-details">
                    <span class="item-name">${this.escapeHtml(item.name)}</span>
                    <span class="item-quantity">${this.escapeHtml(item.quantity)}</span>
                </div>
                
                <div class="item-actions">
                    <button class="edit-button" 
                            onclick="editItem('${item.id}')"
                            aria-label="Edit ${item.name}">
                        ✏️
                    </button>
                    <button class="delete-button" 
                            onclick="deleteItem('${item.id}')"
                            aria-label="Delete ${item.name}">
                        🗑️
                    </button>
                </div>
            </div>
        `;
        
        return li;
    }
    
    /**
     * Shows visual listening indicator
     * Provides feedback during voice recognition
     */
    showListeningIndicator() {
        if (this.elements.listeningIndicator) {
            this.elements.listeningIndicator.classList.add('active');
            this.elements.listeningIndicator.setAttribute('aria-live', 'polite');
            this.elements.listeningIndicator.textContent = 'Listening...';
        }
        
        if (this.elements.microphoneButton) {
            this.elements.microphoneButton.classList.add('listening');
            this.elements.microphoneButton.setAttribute('aria-pressed', 'true');
        }
    }
    
    /**
     * Hides listening indicator
     */
    hideListeningIndicator() {
        if (this.elements.listeningIndicator) {
            this.elements.listeningIndicator.classList.remove('active');
            this.elements.listeningIndicator.textContent = '';
        }
        
        if (this.elements.microphoneButton) {
            this.elements.microphoneButton.classList.remove('listening');
            this.elements.microphoneButton.setAttribute('aria-pressed', 'false');
        }
    }
    
    /**
     * Displays error message to user
     * @param {string} message - Error message to display
     * @param {string} type - Error type for styling
     */
    displayError(message, type = 'error') {
        if (!this.elements.errorMessage) return;
        
        this.elements.errorMessage.textContent = message;
        this.elements.errorMessage.className = `error-message ${type}`;
        this.elements.errorMessage.setAttribute('role', 'alert');
        this.elements.errorMessage.style.display = 'block';
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            this.hideError();
        }, 5000);
    }
    
    /**
     * Utility function to escape HTML
     * @private
     */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}
```

## Development Workflow

### Code Style Guidelines

1. **ES6+ Features**: Use modern JavaScript features
2. **Modular Design**: Each class in its own file
3. **JSDoc Comments**: Document all public methods
4. **Error Handling**: Comprehensive try-catch blocks
5. **Accessibility**: ARIA labels and semantic HTML

### Example Code Patterns

#### Error Handling Pattern
```javascript
async function performOperation() {
    try {
        const result = await riskyOperation();
        return result;
    } catch (error) {
        this.handleError('performOperation', error);
        throw new Error(`Operation failed: ${error.message}`);
    }
}
```

#### Event Listener Pattern
```javascript
class ComponentWithEvents {
    constructor() {
        this.listeners = {
            dataChanged: [],
            errorOccurred: []
        };
    }
    
    addEventListener(event, callback) {
        if (this.listeners[event]) {
            this.listeners[event].push(callback);
        }
    }
    
    notifyListeners(event, data) {
        if (this.listeners[event]) {
            this.listeners[event].forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error(`Event listener error:`, error);
                }
            });
        }
    }
}
```

#### Validation Pattern
```javascript
validateInput(input, rules) {
    const errors = [];
    
    rules.forEach(rule => {
        if (!rule.test(input)) {
            errors.push(rule.message);
        }
    });
    
    if (errors.length > 0) {
        throw new ValidationError(errors.join(', '));
    }
    
    return true;
}
```

## Testing

### Test Structure
```
tests/
├── unit/                   # Unit tests for individual components
├── integration/            # Integration tests
├── e2e/                   # End-to-end workflow tests
├── performance/           # Performance and load tests
├── accessibility/         # Accessibility compliance tests
└── cross-browser/         # Browser compatibility tests
```

### Running Tests

#### All Tests
```bash
# Open comprehensive test suite
open tests/comprehensive-test-suite.html
```

#### Individual Test Suites
```javascript
// Unit tests
import { ShoppingItemTests } from './tests/ShoppingItem.test.js';
ShoppingItemTests.runAll();

// Performance tests
import { PerformanceTests } from './tests/performance.test.js';
PerformanceTests.runAll();
```

### Writing Tests

#### Unit Test Example
```javascript
import { TestRunner, Assert } from './test-runner.js';
import { ShoppingItem } from '../models/ShoppingItem.js';

const runner = new TestRunner();

runner.test('ShoppingItem creation with valid data', () => {
    const item = new ShoppingItem('milk', '2 gallons', 'dairy');
    
    Assert.equal(item.name, 'milk');
    Assert.equal(item.quantity, '2 gallons');
    Assert.equal(item.category, 'dairy');
    Assert.true(item.id.length > 0);
    Assert.instanceOf(item.dateAdded, Date);
});

runner.test('ShoppingItem validation throws on empty name', () => {
    Assert.throws(() => {
        new ShoppingItem('', '1', 'dairy');
    }, 'Should throw error for empty name');
});

export { runner as ShoppingItemTests };
```

## Performance Optimization

### Best Practices

1. **Lazy Loading**: Load components only when needed
2. **Debouncing**: Limit API calls and DOM updates
3. **Memory Management**: Clean up event listeners
4. **Efficient DOM Updates**: Batch DOM modifications

### Performance Monitoring
```javascript
class PerformanceMonitor {
    static measure(label, fn) {
        const start = performance.now();
        const result = fn();
        const end = performance.now();
        
        console.log(`${label}: ${(end - start).toFixed(2)}ms`);
        return result;
    }
    
    static async measureAsync(label, asyncFn) {
        const start = performance.now();
        const result = await asyncFn();
        const end = performance.now();
        
        console.log(`${label}: ${(end - start).toFixed(2)}ms`);
        return result;
    }
}
```

### Memory Optimization
```javascript
class ComponentWithCleanup {
    constructor() {
        this.eventListeners = [];
        this.timers = [];
    }
    
    addEventListener(element, event, handler) {
        element.addEventListener(event, handler);
        this.eventListeners.push({ element, event, handler });
    }
    
    setTimeout(callback, delay) {
        const id = setTimeout(callback, delay);
        this.timers.push(id);
        return id;
    }
    
    destroy() {
        // Clean up event listeners
        this.eventListeners.forEach(({ element, event, handler }) => {
            element.removeEventListener(event, handler);
        });
        
        // Clear timers
        this.timers.forEach(id => clearTimeout(id));
        
        // Clear references
        this.eventListeners = [];
        this.timers = [];
    }
}
```

## Deployment

### Production Build Checklist

1. **Minification**: Minify CSS and JavaScript
2. **Compression**: Enable gzip compression
3. **Caching**: Set appropriate cache headers
4. **HTTPS**: Ensure secure connection for microphone access
5. **Error Tracking**: Implement error logging

### Browser Compatibility

#### Supported Browsers
- Chrome 25+ (Full support)
- Edge 79+ (Full support)
- Safari 14+ (Partial voice support)
- Firefox 55+ (Limited voice support)

#### Feature Detection
```javascript
function checkBrowserSupport() {
    const support = {
        speechRecognition: !!(window.SpeechRecognition || window.webkitSpeechRecognition),
        speechSynthesis: !!(window.speechSynthesis),
        localStorage: !!window.localStorage,
        mediaDevices: !!(navigator.mediaDevices)
    };
    
    return support;
}
```

### Deployment Configuration

#### Web Server Configuration
```nginx
# Nginx configuration
location / {
    # Enable compression
    gzip on;
    gzip_types text/css application/javascript;
    
    # Set cache headers
    expires 1d;
    add_header Cache-Control "public, immutable";
}

# Ensure HTTPS for microphone access
server {
    listen 443 ssl;
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
}
```

## Contributing

### Development Setup

1. **Fork the repository**
2. **Create feature branch**
```bash
git checkout -b feature/new-feature
```

3. **Make changes with tests**
4. **Run test suite**
```bash
# Open test suite and verify all tests pass
open tests/comprehensive-test-suite.html
```

5. **Submit pull request**

### Code Review Checklist

- [ ] Code follows style guidelines
- [ ] All tests pass
- [ ] New features have tests
- [ ] Documentation updated
- [ ] Accessibility considered
- [ ] Performance impact assessed
- [ ] Browser compatibility verified

### Issue Reporting

When reporting issues, include:
- Browser and version
- Steps to reproduce
- Expected vs actual behavior
- Console errors
- Test results if applicable

---

*This developer guide provides comprehensive information for contributing to and maintaining the Voice Shopping Assistant project.*