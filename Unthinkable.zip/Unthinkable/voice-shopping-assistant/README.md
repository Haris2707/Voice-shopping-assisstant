# 🛒 Voice Shopping Assistant

A modern, accessible web application that lets you manage your shopping lists using voice commands and natural language processing.

![Voice Shopping Assistant](https://img.shields.io/badge/Voice-Enabled-blue.svg)
![Browser Support](https://img.shields.io/badge/browsers-Chrome%20%7C%20Edge%20%7C%20Safari-orange.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

[![Tests](https://img.shields.io/badge/tests-passing-brightgreen.svg)](tests/comprehensive-test-suite.html)
[![Accessibility](https://img.shields.io/badge/accessibility-WCAG%202.1-blue.svg)](docs/user-guide.md#accessibility)
[![Browser Support](https://img.shields.io/badge/browsers-Chrome%20%7C%20Edge%20%7C%20Safari-orange.svg)](docs/user-guide.md#browser-compatibility)

## ✨ Features

### 🎤 Voice Control
- **Natural Language Commands**: "Add 2 gallons of milk" or "Remove bread from my list"
- **Multi-language Support**: English, Spanish, French, German, Italian, Portuguese
- **Voice Feedback**: Audio confirmations and error messages
- **Fallback Text Input**: Works without voice support

### 🧠 Smart Intelligence
- **Automatic Categorization**: Items sorted into dairy, produce, meat, etc.
- **Intelligent Suggestions**: Based on shopping history and seasonal items
- **Product Substitutes**: "What can I use instead of milk?"
- **Search Functionality**: "Find organic apples under $5"

### 📱 Modern Experience
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Offline Support**: Functions without internet connection
- **Accessibility First**: Screen reader compatible, keyboard navigation
- **Fast Performance**: Optimized for speed and low memory usage

## 🚀 Quick Start

### Try It Now
1. Open `index.html` in a modern web browser
2. Allow microphone access when prompted
3. Click the microphone button and say "Add milk"
4. Watch your shopping list update automatically!

### Voice Commands Examples
```
"Add 2 gallons of milk"
"I need bread and eggs"
"Remove apples from my list"
"Find organic chicken under $10"
"What do you suggest I buy?"
"Mark milk as done"
```

## 📋 Table of Contents

- [Installation](#installation)
- [Usage](#usage)
- [Documentation](#documentation)
- [Testing](#testing)
- [Browser Support](#browser-support)
- [Contributing](#contributing)
- [License](#license)

## 💻 Installation

### Prerequisites
- Modern web browser (Chrome 25+, Edge 79+, Safari 14+, Firefox 55+)
- Local web server for development
- Microphone access for voice features

### Local Development
```bash
# Clone the repository
git clone <repository-url>
cd voice-shopping-assistant

# Start a local web server
python -m http.server 8000
# OR
npx http-server
# OR
php -S localhost:8000

# Open in browser
open http://localhost:8000
```

### Project Structure
```
voice-shopping-assistant/
├── 📄 index.html              # Main application
├── 🎨 styles.css              # Styling
├── ⚙️ app.js                  # Application entry point
├── 📁 models/                 # Business logic
│   ├── ShoppingListManager.js
│   ├── VoiceProcessor.js
│   ├── NLPParser.js
│   └── ...
├── 📁 ui/                     # User interface
│   └── UIController.js
├── 📁 tests/                  # Test suite
│   ├── comprehensive-test-suite.html
│   ├── e2e-workflows.test.js
│   ├── performance.test.js
│   └── ...
└── 📁 docs/                   # Documentation
    ├── user-guide.md
    ├── api-documentation.md
    └── developer-guide.md
```

## 🎯 Usage

### Basic Operations

#### Adding Items
```javascript
// Voice: "Add 2 gallons of milk"
// Programmatic:
listManager.addItem('milk', '2 gallons', 'dairy');
```

#### Removing Items
```javascript
// Voice: "Remove bread from my list"
// Programmatic:
listManager.removeItem('bread');
```

#### Searching Products
```javascript
// Voice: "Find organic apples under $5"
// Programmatic:
const results = searchEngine.search('organic apples', { maxPrice: 5 });
```

### Advanced Features

#### Multi-language Support
```javascript
// Switch to Spanish
voiceProcessor.setLanguage('es-ES');
// Voice: "Agregar dos litros de leche"
```

#### Smart Suggestions
```javascript
// Get personalized recommendations
const suggestions = suggestionEngine.getRecommendations();
// Voice: "What should I buy?"
```

#### Accessibility Features
- Full keyboard navigation
- Screen reader support
- High contrast mode
- Voice-only operation

## 📚 Documentation

### User Documentation
- **[User Guide](docs/user-guide.md)** - Complete user manual with voice commands
- **[Browser Compatibility](docs/user-guide.md#browser-compatibility)** - Supported browsers and features
- **[Troubleshooting](docs/user-guide.md#troubleshooting)** - Common issues and solutions

### Developer Documentation
- **[API Documentation](docs/api-documentation.md)** - Complete API reference
- **[Developer Guide](docs/developer-guide.md)** - Architecture and development workflow
- **[Contributing Guidelines](#contributing)** - How to contribute to the project

### Key APIs

#### ShoppingListManager
```javascript
const listManager = new ShoppingListManager();

// Add items
listManager.addItem('milk', '2 gallons', 'dairy');

// Remove items
listManager.removeItem('milk');

// Get list
const list = listManager.getList();
console.log(`${list.getItemCount()} items in list`);
```

#### VoiceProcessor
```javascript
const voiceProcessor = new VoiceProcessor(
    (command) => console.log('Command:', command),
    (error) => console.error('Error:', error)
);

// Start listening
voiceProcessor.startListening();

// Set language
voiceProcessor.setLanguage('es-ES');
```

#### NLPParser
```javascript
const parser = new NLPParser();

// Parse add commands
const result = parser.parseAddCommand('Add 2 gallons of milk');
console.log(result.items[0]); // { name: 'milk', quantity: '2 gallons' }

// Parse search commands
const search = parser.parseSearchCommand('Find organic apples under $5');
console.log(search.query); // 'organic apples'
console.log(search.filters.maxPrice); // 5
```

## 🧪 Testing

### Comprehensive Test Suite

Open the interactive test suite:
```bash
open tests/comprehensive-test-suite.html
```

### Test Categories

#### 🔧 Unit Tests
- Individual component testing
- Data model validation
- Business logic verification

#### 🎯 End-to-End Tests
- Complete user workflows
- Voice command processing
- Multi-language support

#### ⚡ Performance Tests
- Voice recognition speed
- Memory usage monitoring
- Stress testing

#### 🌐 Cross-Browser Tests
- Browser compatibility
- Feature detection
- Fallback functionality

#### ♿ Accessibility Tests
- ARIA compliance
- Keyboard navigation
- Screen reader support

### Running Tests Programmatically

```javascript
// Import test modules
import { E2EWorkflowTests } from './tests/e2e-workflows.test.js';
import { PerformanceTests } from './tests/performance.test.js';

// Run specific test suites
await E2EWorkflowTests.runAll();
await PerformanceTests.runAll();

// Run performance benchmarks
const results = await PerformanceBenchmark.runBenchmarks();
console.log('Performance Results:', results);
```

### Test Results Example
```
🧪 Running tests...

✅ ShoppingItem creation and validation
✅ Voice command parsing
✅ Multi-language support
✅ Performance benchmarks
✅ Cross-browser compatibility
✅ Accessibility compliance

📊 Test Results:
   Total: 67
   Passed: 65
   Failed: 2
   Success Rate: 97.01%

🎉 Test suite completed!
```

## 🌐 Browser Support

### Full Support ✅
- **Chrome 25+** - All features including voice recognition
- **Edge 79+** - All features including voice recognition

### Partial Support ⚠️
- **Safari 14+** - Limited voice recognition, full core functionality
- **Firefox 55+** - No voice recognition, full core functionality with text input

### Feature Matrix

| Feature | Chrome | Edge | Safari | Firefox |
|---------|--------|------|--------|---------|
| Voice Recognition | ✅ | ✅ | ⚠️ | ❌ |
| Speech Synthesis | ✅ | ✅ | ✅ | ✅ |
| Local Storage | ✅ | ✅ | ✅ | ✅ |
| Responsive Design | ✅ | ✅ | ✅ | ✅ |
| Accessibility | ✅ | ✅ | ✅ | ✅ |
| Offline Mode | ✅ | ✅ | ✅ | ✅ |

### Mobile Support
- **iOS Safari** - Core functionality, limited voice features
- **Chrome Mobile** - Full support on Android
- **Samsung Internet** - Partial support

## 🔧 Configuration

### Environment Variables
```javascript
// app.js configuration
const config = {
    defaultLanguage: 'en-US',
    voiceTimeout: 5000,
    maxItems: 1000,
    autoSave: true,
    debugMode: false
};
```

### Customization Options
```javascript
// Customize categories
categoryManager.addCustomCategory('Baby Items', ['diapers', 'formula', 'wipes']);

// Customize voice settings
voiceProcessor.setLanguage('es-ES');
speechSynthesizer.setVoice('Spanish Female');

// Customize UI theme
uiController.setTheme('dark');
```

## 🚀 Performance

### Benchmarks
- **Voice Recognition**: < 200ms response time
- **NLP Processing**: < 50ms per command
- **List Operations**: < 10ms for 1000 items
- **Storage Operations**: < 100ms save/load
- **Memory Usage**: < 5MB for typical usage

### Optimization Features
- Lazy loading of components
- Debounced voice processing
- Efficient DOM updates
- Memory leak prevention
- Offline caching

## ♿ Accessibility

### WCAG 2.1 Compliance
- **Level AA** compliance achieved
- Screen reader compatible
- Keyboard navigation support
- High contrast mode
- Focus management
- Alternative text for all images

### Accessibility Features
```html
<!-- Semantic HTML structure -->
<main role="main" aria-label="Shopping List Application">
  <section aria-label="Voice Controls">
    <button aria-pressed="false" aria-label="Start voice recognition">
      🎤 Start Listening
    </button>
  </section>
  
  <section aria-label="Shopping List" aria-live="polite">
    <ul role="list">
      <li role="listitem" aria-label="Milk, 2 gallons, dairy category">
        <!-- Item content -->
      </li>
    </ul>
  </section>
</main>
```

## 🔒 Privacy & Security

### Data Privacy
- **Local Storage Only** - No data sent to external servers
- **No Tracking** - No analytics or user tracking
- **Microphone Access** - Only used for voice recognition, not recorded
- **Offline Capable** - Works without internet connection

### Security Features
- Input sanitization and validation
- XSS prevention
- Content Security Policy headers
- Secure HTTPS requirement for voice features

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guidelines](docs/developer-guide.md#contributing) for details.

### Quick Contribution Steps
1. **Fork** the repository
2. **Create** a feature branch: `git checkout -b feature/amazing-feature`
3. **Make** your changes with tests
4. **Run** the test suite: Open `tests/comprehensive-test-suite.html`
5. **Commit** your changes: `git commit -m 'Add amazing feature'`
6. **Push** to the branch: `git push origin feature/amazing-feature`
7. **Submit** a pull request

### Development Setup
```bash
# Clone your fork
git clone https://github.com/yourusername/voice-shopping-assistant.git
cd voice-shopping-assistant

# Start development server
python -m http.server 8000

# Run tests
open tests/comprehensive-test-suite.html

# Make changes and test
# Submit pull request
```

### Code Style
- ES6+ JavaScript features
- Comprehensive JSDoc comments
- Modular architecture
- Test-driven development
- Accessibility-first design

## 📈 Roadmap

### Upcoming Features
- [ ] **Cloud Sync** - Optional cloud storage for lists
- [ ] **Meal Planning** - Integration with recipe suggestions
- [ ] **Price Tracking** - Historical price data and alerts
- [ ] **Barcode Scanning** - Add items by scanning barcodes
- [ ] **Smart Home Integration** - Alexa/Google Assistant support
- [ ] **Collaborative Lists** - Share lists with family members

### Version History
- **v1.0.0** - Initial release with core voice features
- **v1.1.0** - Multi-language support and accessibility improvements
- **v1.2.0** - Performance optimizations and mobile enhancements
- **v1.3.0** - Advanced search and suggestion features

## 🐛 Known Issues

### Current Limitations
- Voice recognition accuracy varies by accent and environment
- Safari voice support is limited on iOS
- Firefox requires text input fallback
- Offline mode doesn't sync suggestions

### Workarounds
- Use text input in unsupported browsers
- Speak clearly in quiet environments
- Update to latest browser versions
- Check microphone permissions

## 📞 Support

### Getting Help
- **Documentation**: Check the [User Guide](docs/user-guide.md)
- **Issues**: Report bugs via GitHub Issues
- **Discussions**: Join community discussions
- **Email**: Contact support team

### Troubleshooting
1. **Voice not working**: Check browser support and microphone permissions
2. **Items not saving**: Verify localStorage is enabled
3. **Poor recognition**: Reduce background noise and speak clearly
4. **Mobile issues**: Ensure latest browser version

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Web Speech API** - For voice recognition capabilities
- **Modern Browser Teams** - For implementing web standards
- **Accessibility Community** - For guidance on inclusive design
- **Open Source Contributors** - For inspiration and best practices

---

**Made with ❤️ for accessible, voice-controlled shopping**

*Last updated: December 2023*